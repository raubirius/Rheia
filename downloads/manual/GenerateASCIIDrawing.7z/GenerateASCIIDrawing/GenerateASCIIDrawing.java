
import knižnica.*;
import static knižnica.Svet.*;
import java.awt.Shape;
import java.awt.geom.Line2D;

public class GenerateASCIIDrawing extends GRobot
{
	public final static int WI = 14; // 14
	public final static int HE = 24; // 20
	public final static int OFS1 = 6;
	public final static int OFS2 = 14;
	public final static int RDC = 8;

	public final static String[] controlCharactersTable = {
	// Preklad názvu: tabuľka riadiacich znakov
		"NUL", "␀", "SOH", "␁", "STX", "␂", "ETX", "␃",
		"EOT", "␄", "ENQ", "␅", "ACK", "␆", "BEL", "␇",
		"BS",  "␈", "HT",  "␉", "LF",  "␊", "VT",  "␋",
		"FF",  "␌", "CR",  "␍", "SO",  "␎", "SI",  "␏",
		"DLE", "␐", "DC1", "␑", "DC2", "␒", "DC3", "␓",
		"DC4", "␔", "NAK", "␕", "SYN", "␖", "ETB", "␗",
		"CAN", "␘", "EM",  "␙", "SUB", "␚", "ESC", "␛",
		"FS",  "␜", "GS",  "␝", "RS",  "␞", "US",  "␟",
	};

	private final static Písmo smallFont =
		new Písmo("Monospace", Písmo.OBYČAJNÉ, 8);
	private final static Písmo mediumFont =
		new Písmo("Monospace", Písmo.OBYČAJNÉ, 10);
	private final static Písmo bigFont =
		new Písmo("Monospace", Písmo.OBYČAJNÉ, 20);
	private void smallFont() { písmo(smallFont); }
	private void mediumFont() { písmo(mediumFont); }
	private void bigFont() { písmo(bigFont); }

	private double x0, y0, x1, y1;

	private void savePos()
	// Preklad názvu: ulož pol(ohu)
	{
		x0 = x1 = prepočítajX(polohaX());
		y0 = y1 = prepočítajY(polohaY());
	}

	private void addLineSeg()
	// Preklad názvu: pridaj úseč(ku)
	{
		x0 = x1; x1 = prepočítajX(polohaX());
		y0 = y1; y1 = prepočítajY(polohaY());

		svgPodpora.pridaj(new Line2D.Double(x0, y0, x1, y1));
		svgPodpora.hrúbkaČiary(-1, hrúbkaČiary());
		svgPodpora.farbaČiary(-1, farba());
	}

	@Override public Shape obdĺžnik(double š, double v)
	{
		Shape obdĺžnik = super.obdĺžnik(š, v);
		svgPodpora.pridaj(obdĺžnik);
		svgPodpora.hrúbkaČiary(-1, hrúbkaČiary());
		svgPodpora.farbaČiary(-1, farba());
		svgPodpora.farbaVýplne(-1, žiadna);
		return obdĺžnik;

		/*
		TODO
		urobiť metódu
			pridaj(Shape, GRobot, String...)
		ako je text(…)
		robot si musí pamätať ID naposledy kresleného tvaru (dôležité je, aby sa dalo určiť, či bol vypĺňaný alebo obrysový; rozmery, orientácia atď. sa dajú určiť zo samotnej inštancie Shape)
		ak nasledujú za sebou presne dva rovnaké tvary, ale jeden vyplnený a druhý obrysový (presne v tomto poradí, inak by výsledok bol iný), tak ich SVGPodpora môže spojiť…
		*/
	}

	@Override public Shape text(String text)
	{
		svgPodpora.pridajText(text);
		return super.text(text);
	}

	private void drawControlCharacter(char ch)
	// Preklad názvu: nakresli riadiaci znak
	{
		String controlCharacterString;
		// Preklad názvu: reťazec riadiaceho znaku

		if (ch >= 32)
		{
			if (32 == ch)
				controlCharacterString = "SP";
			else if (127 == ch)
				controlCharacterString = "DEL";
			else
				controlCharacterString = "???";
		}
		else
			controlCharacterString = controlCharactersTable[ch * 2];

		farba(čierna);
		obdĺžnik(WI - 2, HE - 2);

		mediumFont(); farba(tmavošedá);
		skoč(-3 * (controlCharacterString.length() - 1),
			4 * (controlCharacterString.length() - 1) + OFS1);
		for (int i = 0; i < controlCharacterString.length(); ++i)
		{
			text(Character.toString(controlCharacterString.charAt(i)));
			skoč(6, -8);
		}
		skoč(-3 * (controlCharacterString.length() + 1),
			4 * (controlCharacterString.length() + 1) - OFS1 - OFS2);

		smallFont();
		farba(tmavočervená);
		text(Integer.toString((int)ch));
		skoč(0, OFS2);
	}
	private void drawControlCharacter(int ch)
	{ drawControlCharacter((char)ch); }

	private void drawASCIICharacter(char ch)
	// Preklad názvu: nakresli znak ASCII
	{
		bigFont();
		farba(čierna);
		obdĺžnik(WI - 2, HE - 2);

		if (ch >= '0' && ch <= '9')
			farba(tmavotyrkysová);
		else if (ch >= 'A' && ch <= 'Z')
			farba(tmavomodrá);
		else if (ch >= 'a' && ch <= 'z')
			farba(svetlomodrá);
		else
			farba(tmavopurpurová);

		skoč(0, OFS1);
		text(Character.toString(ch));
		skoč(0, -OFS1 - OFS2);

		smallFont();
		farba(tmavočervená);
		text(Integer.toString((int)ch));
		skoč(0, OFS2);
	}
	private void drawASCIICharacter(int ch)
	{ drawASCIICharacter((char)ch); }

	private GenerateASCIIDrawing()
	// Preklad názvu: generuj kresbu ASCII (tabuľky)
	{
		super(WI * 36, HE * 20 - 3 * RDC);
		zbaľ();

		skoč(-WI * 15, HE * 9 - RDC);

		bigFont(); farba(červená);
		for (int i = 0; i < 16; ++i)
		{
			if (i < 10)
				text(Character.toString((char)('0' + i)));
			else
				text(Character.toString((char)('A' - 10 + i)));
			skoč(2 * WI, 0);
		}

		skoč(-2 * WI * 17, -2 * HE + RDC);

		for (int i = 0; i < 32; ++i)
		{
			if (0 == i % 16)
			{
				bigFont();
				farba(červená);
				text(Character.toString((char)('0' + (i / 16))));
				skoč(2 * WI, 0);
			}

			drawControlCharacter(i);

			if (0 == (i + 1) % 16)
			{
				skoč(2 * WI, 0);
				bigFont();
				farba(červená);
				text(Character.toString((char)('0' + (i / 16))));

				skoč(-2 * WI * 17, -2 * HE);
			}
			else
				skoč(2 * WI, 0);
		}

		for (int i = 32; i < 128; ++i)
		{
			if (0 == i % 16)
			{
				bigFont();
				farba(červená);
				text(Character.toString((char)('0' + (i / 16))));
				skoč(2 * WI, 0);
			}

			if (32 == i || 127 == i)
				drawControlCharacter(i);
			else
				drawASCIICharacter(i);

			if (0 == (i + 1) % 16)
			{
				skoč(2 * WI, 0);
				bigFont();
				farba(červená);
				text(Character.toString((char)('0' + (i / 16))));

				skoč(-2 * WI * 17, -2 * HE);
			}
			else
				skoč(2 * WI, 0);
		}

		skoč(2 * WI, RDC);

		bigFont(); farba(červená);
		for (int i = 0; i < 16; ++i)
		{
			if (i < 10)
				text(Character.toString((char)('0' + i)));
			else
				text(Character.toString((char)('A' - 10 + i)));
			skoč(2 * WI, 0);
		}

		skry();
		// podlaha.uložObrázok("ASCII-table.png", true);
		vypíš(svgPodpora.zapíš("ASCII-table.svg", null, true));
	}

	@Override public void kresliTvar()
	{
		kruh(5);
	}

	public static void main(String[] args)
	{
		nekresli();
		new GenerateASCIIDrawing();
		kresli();
	}
}
