/*
 * Upozornenie! Toto je redukovaný zdrojový kód skupiny tried grafického robota!
 * (GRobot) Filtrom z neho boli odstránené všetky komentáre (nerátajúc tento
 * komentár), prázdne riadky a medzery na začiatkoch a na koncoch riadkov.
 * Krátke riadky boli pripojené na koniec predchádzajúcich riadkov. Tým všetkým
 * bola dosiahnutá výrazná úspora priestoru (keďže kópia triedy sa vyskytne
 * v každom vygenerovanom projekte)… Samozrejme, že žiadna z týcho zmien nemá
 * vplyv na výslednú funkčnosť žiadnej zo súčastí skupiny tried grafického
 * robota. (Jediným negatívnym dôsledkom je výrazné zníženie čitateľnosti
 * zdrojového kódu skupiny triedy grafického robota.)
 * 
 * Na stránke: http://cec.truni.sk/horvath/Robot/ je publikovaná aktuálna
 * úplná dokumentácia skupiny tried grafického robota (ISBN 978-80-8082-
 * 537-9).
 * 
 *  Počet odstránených riadkov: 31112
 *  Počet odstránených znakov: 893400
 *  Zmenšenie veľkosti v percentách: 70%
 *  Verzia GRobot: 1.40, (c) 2010 – 2013, Roman Horváth
 *  Verzia generátora: 1.2, (c) 2011 – 2013, Roman Horváth
 */

import java.awt.AlphaComposite;import java.awt.BasicStroke;import java.awt.BorderLayout;import java.awt.Component;import java.awt.Composite;import java.awt.Container;import java.awt.Color;import java.awt.Cursor;import java.awt.Dimension;import java.awt.FileDialog;import java.awt.Font;import java.awt.FontMetrics;import java.awt.Graphics2D;import java.awt.Image;import java.awt.Polygon;import java.awt.Point;import java.awt.Rectangle;
import java.awt.RenderingHints;import java.awt.Shape;import java.awt.TexturePaint;import java.awt.Toolkit;
import java.awt.color.ColorSpace;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.font.TextLayout;
import java.awt.geom.AffineTransform;import java.awt.geom.Arc2D;import java.awt.geom.Area;import java.awt.geom.Line2D;
import java.awt.geom.Ellipse2D;import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.DataBufferInt;
import java.awt.image.DirectColorModel;import java.awt.image.Kernel;
import java.awt.image.WritableRaster;import java.io.BufferedWriter;import java.io.BufferedReader;import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;import java.io.InputStream;
import java.io.InputStreamReader;import java.io.IOException;
import java.io.OutputStreamWriter;import java.net.URL;import java.util.Arrays;import java.util.Collection;import java.util.Enumeration;import java.util.Map;
import java.util.NoSuchElementException;import java.util.Random;import java.util.TreeMap;import java.util.Vector;import java.util.jar.JarEntry;import java.util.jar.JarFile;
import java.util.jar.JarInputStream;import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.swing.BorderFactory;import javax.swing.Icon;import javax.swing.ImageIcon;import javax.swing.JButton;
import javax.swing.JColorChooser;import javax.swing.JFrame;import javax.swing.JLabel;import javax.swing.JMenu;import javax.swing.JMenuBar;import javax.swing.JMenuItem;
import javax.swing.JOptionPane;import javax.swing.JPanel;
import javax.swing.JPasswordField;import javax.swing.JPopupMenu;import javax.swing.JTextField;import javax.swing.JWindow;import javax.swing.KeyStroke;
import javax.swing.OverlayLayout;
import javax.swing.SwingConstants;import javax.swing.Timer;import javax.swing.UIManager;
public class GRobot implements Poloha, Smer, Farebnosť, Priehľadnosť{
public final static int KRESLI_PRIAMO = 0;
public final static int KRESLI_NA_STRED = 1;
public final static int KRESLI_ROTOVANÉ = 2;
public final static int KRESLI_ROTOVANE = 2;
public final static int KRESLI_CENTROVANÉ = 1;
public final static int KRESLI_CENTROVANE = 1;
public final static int KRESLI_V_SMERE = 2;
public final static int ĽAVÉ = 1;
public final static int LAVE = 1;
public final static int STREDNÉ = 2;
public final static int STREDNE = 2;
public final static int PRAVÉ = 3;
public final static int PRAVE = 3;
public final static int majorVersion = 1;
public final static int minorVersion = 40;
public final static String years = "2010 – 2013";
public final static String mainDeveloper = "Roman Horváth";
public final static char riadok = '\n';
public final static int ZAVRETÉ = JOptionPane.CLOSED_OPTION;
public final static int ZAVRETE = JOptionPane.CLOSED_OPTION;
public final static int ZRUŠIŤ = JOptionPane.CANCEL_OPTION;
public final static int ZRUSIT = JOptionPane.CANCEL_OPTION;
public final static int ÁNO = JOptionPane.YES_OPTION;
public final static int ANO = JOptionPane.YES_OPTION;
public final static int NIE = JOptionPane.NO_OPTION;
private final static double predvolenýPolomerPera = 0.5;private double polomerPera;private BasicStroke čiara;
private final static Farba predvolenéPero         = čierna;
private final static Farba predvolenéPozadie      = biela;
private final static Farba predvolenáFarbaKonzoly = tmavomodrá;private Farba farbaPera;
private static Farba farbaPozadia;
private final static Písmo predvolenéPísmo = new Písmo("Helvetica", Písmo.PLAIN, 16);private Písmo aktuálnePísmo;
private final static Písmo predvolenéPísmoKonzoly = new Písmo("Lucida Console", Písmo.PLAIN, 18);private double domaX = 0;private double domaY = 0;private double uholDoma = 90;
private Boolean peroPoloženéDoma = null;
private Boolean viditeľnýDoma = null;private double aktuálneX;private double aktuálneY;private double aktuálnyUhol;
private boolean peroPoložené = true;
private boolean viditeľný = true;private double veľkosť = 10.0;
private Oblasť kolíznaOblasť = null;
private static boolean aspoňJedenAktívny;
private boolean aktívny = false;private double rýchlosť = 0.0;
private double uhlováRýchlosť = 0.0;
private double maximálnaRýchlosť = 0.0;
private double maximálnaUhlováRýchlosť = 0.0;
private double zrýchlenie = 0.0;
private double uhlovéZrýchlenie = 0.0;private int dobaAktivity = 0;
private boolean cieľAktívny = false;
private boolean zastavVCieli = false;
private boolean zastavPoSpomalení = false;private double cieľX = 0.0;private double cieľY = 0.0;
private final static Farba farbaPôsobiska =new Farba(0, 0, 100, 40);private double minimálneX;private double minimálneY;private double maximálneX;private double maximálneY;
private boolean kresliPôsobisko = false;
private boolean vyplnený = true;
private Image vlastnýTvarObrázok = null;
private VlastnýTvar vlastnýTvarKreslenie = null;
private boolean kreslímVlastnýTvar = false;
private final static VlastnýTvar použiPrekrytúMetóduKresli =
new VlastnýTvar() { @Override public void kresli(GRobot r){ r.kresliTvar(); }};private class Spojnica{GRobot cieľ;BasicStroke čiara;Farba farba;
Spojnica(Farba farba, BasicStroke čiara, GRobot cieľ){this.farba = farba;this.čiara = čiara;this.cieľ = cieľ;}
Spojnica(Color farba, BasicStroke čiara, GRobot cieľ){this.farba = new Farba(farba);this.čiara = čiara;this.cieľ = cieľ;}}
private final Vector<Spojnica> spojnice =new Vector<Spojnica>();private Plátno aktívnePlátno;
private BufferedImage obrázokAktívnehoPlátna;
private Graphics2D grafikaAktívnehoPlátna;
private BufferedImage obrázokZálohyPlátna = null;
private int[] zálohaPlátna = null;
private final Path2D.Double cesta = new Path2D.Double();
private boolean záznamCesty = false;
private boolean záznamCestyBezPolohyPera = true;
private Oblasť zamestnanýPre = null;
private int spôsobKreslenia = KRESLI_NA_STRED | KRESLI_ROTOVANÉ;
private boolean kresliTvary = true;
private static boolean konzolaPoužitá = false;
private float priehľadnosť = 1.0f;private int vrstva = 0;
private final static String titulokOkna = "GRobot " +
majorVersion + "." + minorVersion + ", " + mainDeveloper +", (c) " + years;
private static GRobot hlavnýRobot;
private static boolean inicializované = false;private final static String
predvolenýNázovKonfiguračnéhoSúboru = "grobot.cfg";
private static String názovKonfiguračnéhoSúboru = null;
private final static Súbor konfiguračnýSúbor = new Súbor();
private static void uložKonfiguráciu(){
if (null == názovKonfiguračnéhoSúboru) return;
if (počiatočnáŠírka == svet.getWidth() &&
počiatočnáVýška == svet.getHeight() &&
počiatočnéX == svet.getLocation().x &&
počiatočnéY == svet.getLocation().y &&(null == počúvadlo ||
(!počúvadlo.konfiguráciaZmenená() &&
!počúvadlo.konfiguraciaZmenena()))) return;try{
konfiguračnýSúbor.otvorNaZápis(názovKonfiguračnéhoSúboru);
konfiguračnýSúbor.zapíšVlastnosť(
"windowWidth", svet.getWidth());
konfiguračnýSúbor.zapíšVlastnosť(
"windowHeight", svet.getHeight());
konfiguračnýSúbor.zapíšVlastnosť(
"windowX", svet.getLocation().x);
konfiguračnýSúbor.zapíšVlastnosť(
"windowY", svet.getLocation().y);if (null != počúvadlo){
počúvadlo.zapíšKonfiguráciu(konfiguračnýSúbor);
počúvadlo.zapisKonfiguraciu(konfiguračnýSúbor);}}
catch (Exception e) { vypíšChybovéHlásenia(e); }
try { konfiguračnýSúbor.zavri(); }
catch (Exception e) { vypíšChybovéHlásenia(e); }}
private static void načítajVlastnúKonfiguráciu(){
if (null == názovKonfiguračnéhoSúboru ||null == počúvadlo) return;try{
konfiguračnýSúbor.otvorNaČítanie(názovKonfiguračnéhoSúboru);
počúvadlo.čítajKonfiguráciu(konfiguračnýSúbor);
počúvadlo.citajKonfiguraciu(konfiguračnýSúbor);}
catch (Exception e) { vypíšChybovéHlásenia(e); }
try { konfiguračnýSúbor.zavri(); }
catch (Exception e) { vypíšChybovéHlásenia(e); }}
private static int šírkaPlátna = 800, výškaPlátna = 600;
private static int počiatočnáŠírka = 600;
private static int počiatočnáVýška = 500;
private static int počiatočnéX = 25;
private static int počiatočnéY = 25;
private static boolean zobrazPriŠtarte = true;
private static JPanel hlavnýPanel = new JPanel() { @Override
public boolean isOptimizedDrawingEnabled() { return false; }};
private static PoložkaPonuky položkaVymazať = null;
private static PoložkaPonuky položkaPrekresliť = null;
private static PoložkaPonuky položkaSkončiť = null;
private static boolean ponukaVPôvodnomStave = true;
private static int aktuálnaPonuka = 0;
private static int aktuálnaPoložka = 0;
private static KontextováPoložka
poslednáKontextováPoložka = null;
private static BufferedImage obrázok = new
BufferedImage(šírkaPlátna, výškaPlátna,BufferedImage.TYPE_INT_ARGB);
private static Graphics2D grafika = obrázok.createGraphics();
private static BufferedImage vyrovnávaciaPamäťObrázka = new
BufferedImage(šírkaPlátna, výškaPlátna,BufferedImage.TYPE_INT_ARGB);
private static Graphics2D vyrovnávaciaPamäťGrafiky =
vyrovnávaciaPamäťObrázka.createGraphics();
private final static JMenuBar panelVstupnéhoRiadka =new JMenuBar();
private final static JLabel popisVstupnéhoRiadka =new JLabel();
private final static JTextField vstupnýRiadok =new JTextField();
private final static StringBuffer údajeVstupnéhoRiadka =new StringBuffer();
private final static StringBuffer zrušenéÚdajeVstupnéhoRiadka =new StringBuffer();
private final static String predvolenýTitulokOtázky = "Otázka";
private final static Object[] predvolenéOdpovedeOtázky = {"Áno", "Nie"};
private final static String predvolenýTitulokVstupu = "Vstup";
private final static String predvolenýTitulokHesla = "Heslo";
private final static RobotTextField textovýRiadok =new RobotTextField();
private final static RobotPasswordField riadokSHeslom =new RobotPasswordField();
private final static Object[] predvolenéOdpovedeZadania ={"OK", "Zrušiť"};
private static JWindow úvodnáObrazovka = null;
private final static Random generátor = new Random();
private static boolean zoznamZmenený1 = false;
private static boolean zoznamZmenený2 = false;
private static boolean zámokZoznamuRobotov1 = false;
private static boolean zámokZoznamuRobotov2 = false;
private final static Vector<GRobot> zoznamRobotov =new Vector<GRobot>();
private final static Vector<GRobot> záložnýZoznamRobotov =new Vector<GRobot>();
private final static TreeMap<Integer, Vrstva> zoznamVrstiev =
new TreeMap<Integer, Vrstva>();
private static String priečinokObrázkov = "";
private final static Vector<String> zoznamSúborovObrázkov =new Vector<String>();
private final static Vector<Image> zoznamObrázkov =new Vector<Image>();
private final static Vector<Icon> zoznamIkon =new Vector<Icon>();
private static String priečinokZvukov = "";
private final static Vector<String> zoznamSúborovZvukov =new Vector<String>();
private final static Vector<Zvuk> zoznamZvukov =new Vector<Zvuk>();
private final static Cursor prázdnyKurzor = Toolkit.
getDefaultToolkit().createCustomCursor(new
BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB),new Point(0, 0), "prázdny");
private final static Vector<Cursor> kurzory =new Vector<Cursor>();
private final static String[] anglickéNázvyKurzorov =
{"default", "crosshair", "text", "wait", "swResize",
"seResize", "nwResize", "neResize", "nResize", "sResize",
"wResize", "eResize", "hand", "move"};
private final static String[] slovenskéNázvyKurzorov =
{"predvolený", "mieridlo", "textový", "čakaj",
"jzZmeniťVeľkosť", "jvZmeniťVeľkosť", "szZmeniťVeľkosť",
"svZmeniťVeľkosť", "sZmeniťVeľkosť", "jZmeniťVeľkosť",
"zZmeniťVeľkosť", "vZmeniťVeľkosť", "ruka", "presunúť"};
private static Zvuk zvukNaPozadí = null;
private static boolean nekresli = false;
private static boolean pracujem = false;
private static boolean žiadamPrekresleniePoPráci = false;
private static boolean právePrekresľujem = false;
private static boolean vstupnýRiadokStáleViditeľný = false;
private static boolean vypíšChybovéHlásenia = false;
private static boolean viacnásobnáObsluhuUdalostíUmožnená = false;
private static ObsluhaUdalostí počúvadlo;
private final static Object zámokMyši = new Object();
private final static Object zámokKlávesnice = new Object();
private final static Object zámokAktivít = new Object();
private final static Object zámokUdalostí = new Object();
private static boolean tlačidloMyši1 = false;
private static boolean tlačidloMyši2 = false;
private static boolean tlačidloMyši3 = false;
private static int tlačidloMyši = 0;
private static double súradnicaMyšiX = 0;
private static double súradnicaMyšiY = 0;
private static int rolovanieKolieskomMyšiX = 0;
private static int rolovanieKolieskomMyšiY = 0;
private static ActionEvent poslednýTik = null;
private static ComponentEvent poslednáUdalosťOkna = null;
private static PoložkaPonuky poslednáPoložkaPonuky = null;
private static Tlačidlo poslednéTlačidlo = null;
private static KeyEvent poslednáUdalosťKlávesnice = null;
private static MouseEvent poslednáUdalosťMyši = null;
private static MouseWheelEvent poslednáUdalosťRolovania = null;
private static void inicializujGrafiku(GRobot ktorýRobot){if (inicializované) return;inicializované = true;
try { UIManager.setLookAndFeel(UIManager.
getSystemLookAndFeelClassName()); }
catch (Exception e) { vypíšChybovéHlásenia(e, true); }svet.vymaž();
RenderingHints hints = new RenderingHints(
RenderingHints.KEY_ANTIALIASING,
RenderingHints.VALUE_ANTIALIAS_ON);
hints.put(RenderingHints.KEY_RENDERING,
RenderingHints.VALUE_RENDER_QUALITY);
hints.put(RenderingHints.KEY_TEXT_ANTIALIASING,
RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
strop.vyrovnávaciaPamäťGrafikyPlátna.addRenderingHints(hints);
podlaha.vyrovnávaciaPamäťGrafikyPlátna.addRenderingHints(hints);
grafika.addRenderingHints(hints);
vyrovnávaciaPamäťGrafiky.addRenderingHints(hints);
ImageIcon ikona = new ImageIcon(obrázok);
final JLabel komponentIkony = new JLabel(ikona);
OverlayLayout overlay = new OverlayLayout(hlavnýPanel){
@Override public void layoutContainer(Container cieľ){
int x = 0, y = 0, šírka = cieľ.getWidth(),výška = cieľ.getHeight();
x = (šírka - komponentIkony.getSize().width) / 2;
y = (výška - komponentIkony.getSize().height) / 2;komponentIkony.setBounds(x, y,
komponentIkony.getPreferredSize().width,
komponentIkony.getPreferredSize().height);
Component komponenty[] = cieľ.getComponents();
if (šírka > šírkaPlátna) šírka = šírkaPlátna;
if (výška > výškaPlátna) výška = výškaPlátna;
for (Component komponent : komponenty)
if (komponent instanceof Tlačidlo)
((Tlačidlo)komponent).umiestni(x, y, šírka, výška);
if (konzolaPoužitá) svet.prekresli();}};
hlavnýPanel.setLayout(overlay);
hlavnýPanel.add(komponentIkony);
popisVstupnéhoRiadka.setBorder(BorderFactory.
createEmptyBorder(0, 4, 0, 8));
panelVstupnéhoRiadka.add(popisVstupnéhoRiadka);
panelVstupnéhoRiadka.add(vstupnýRiadok);
panelVstupnéhoRiadka.setVisible(false);
vstupnýRiadok.addKeyListener(new KeyListener(){
public void keyPressed(KeyEvent e){
if (e.getKeyChar() == e.VK_ENTER) potvrďVstup();
else if (e.getKeyChar() == e.VK_ESCAPE)zrušVstup();}
public void keyReleased(KeyEvent e) {}
public void keyTyped(KeyEvent e) {}});
svet.add(hlavnýPanel, BorderLayout.CENTER);
svet.add(panelVstupnéhoRiadka, BorderLayout.SOUTH);
hlavnýPanel.addMouseListener(udalostiOkna);
hlavnýPanel.addMouseMotionListener(udalostiOkna);
hlavnýPanel.addMouseWheelListener(udalostiOkna);
hlavnýPanel.addKeyListener(udalostiOkna);
hlavnýPanel.setFocusable(true);hlavnýPanel.doLayout();
svet.addComponentListener(udalostiOkna);
svet.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);svet.setTitle(titulokOkna);
svet.setJMenuBar(vytvorHlavnúPonuku());svet.pack();
svet.setSize(počiatočnáŠírka, počiatočnáVýška);
svet.setLocation(počiatočnéX, počiatočnéY);
svet.setVisible(zobrazPriŠtarte);svet.predvolenáFarbaPozadia();svet.zalamujTexty();
podlaha.predvolenáFarbaTextu();strop.predvolenáFarbaTextu();
Runtime.getRuntime().addShutdownHook(new Thread() {public void run(){uložKonfiguráciu();
for (GRobot tento : zoznamRobotov) try{tento.súbor.zavri();}catch (Exception e){vypíšChybovéHlásenia(e, true);}if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.ukončenie();počúvadlo.ukoncenie();}}});}
private void inicializujRobota(){if (null == hlavnýRobot)hlavnýRobot = this;kresliNaPodlahu();predvolenáHrúbkaPera();predvolenáFarba();predvolenéPísmo();predvolenýTvar();
if (zámokZoznamuRobotov1 || zámokZoznamuRobotov2)
záložnýZoznamRobotov.add(this);else{zoznamRobotov.add(this);Vrstva.vlož(this);
zoznamZmenený2 = zoznamZmenený1 = true;}domov();}
private static void zlúčiťZoznamy(){
if (záložnýZoznamRobotov.size() > 0 &&
!zámokZoznamuRobotov1 && !zámokZoznamuRobotov2){
zoznamRobotov.addAll(záložnýZoznamRobotov);
for (GRobot robot : záložnýZoznamRobotov)Vrstva.vlož(robot);záložnýZoznamRobotov.clear();automatickéPrekreslenie();}}
private static double prepočítajX(double x){
return (šírkaPlátna / 2.0) + x;}
private static double prepočítajY(double y){
return (výškaPlátna / 2.0) - y;}
private static double prepočítajSpäťX(double x){
return x - (šírkaPlátna / 2.0);}
private static double prepočítajSpäťY(double y){
return -y + (výškaPlátna / 2.0);}
private double rotovanéX(double x, double y, double α){if (0 == α) return x;
return (x * Math.cos(α)) - (y * Math.sin(α));}
private double rotovanéY(double x, double y, double α){if (0 == α) return y;
return (x * Math.sin(α)) + (y * Math.cos(α));}
private static double korekciaMyšiX(double x){
return x - (hlavnýPanel.getWidth() / 2.0);}
private static double korekciaMyšiY(double y){
return -y + (hlavnýPanel.getHeight() / 2.0);}
private static JMenuBar vytvorHlavnúPonuku(){
if (!inicializované) return null;
JMenuBar hlavnáPonuka = new JMenuBar();
JMenu položkaHlavnejPonuky = new JMenu("Ponuka");
položkaHlavnejPonuky.setMnemonic(KeyEvent.VK_P);
hlavnáPonuka.add(položkaHlavnejPonuky);
položkaHlavnejPonuky.add(položkaSkončiť = new PoložkaPonuky(
"Koniec", KeyEvent.VK_K, KeyEvent.VK_W));return hlavnáPonuka;}
private static void automatickéPrekreslenie(){if (nekresli) return;svet.prekresli();}
private void úsečka(double x0, double y0, double x1, double y1){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(new Line2D.Double(
prepočítajX(x0), prepočítajY(y0),
prepočítajX(x1), prepočítajY(y1)));automatickéPrekreslenie();}
private void kresliRobota(Graphics2D grafika){
boolean vráťKompozit = priehľadnosť < 1.0;Composite záloha = null;if (vráťKompozit){
záloha = grafika.getComposite();if (priehľadnosť > 0.0)
grafika.setComposite(AlphaComposite.getInstance(
AlphaComposite.SRC_OVER, priehľadnosť));else
grafika.setComposite(AlphaComposite.getInstance(
AlphaComposite.SRC_OVER, 0.0f));}
if (null == vlastnýTvarObrázok &&null == vlastnýTvarKreslenie){
final double[] c = { veľkosť * 0.4, veľkosť * 0.5,
veľkosť * 0.6, veľkosť * 1.2, veľkosť * 2.0 };final int[] fx = new int[7];final int[] fy = new int[7];double α = aktuálnyUhol;
double x = aktuálneX - Math.cos(Math.toRadians(α)) * c[1];
double y = aktuálneY - Math.sin(Math.toRadians(α)) * c[1];
fx[0] = (int)prepočítajX(x + Math.
cos(Math.toRadians(α)) * c[4]);
fy[0] = (int)prepočítajY(y + Math.
sin(Math.toRadians(α)) * c[4]);α += 20;
fx[1] = (int)prepočítajX(x + Math.
cos(Math.toRadians(α)) * c[2]);
fy[1] = (int)prepočítajY(y + Math.
sin(Math.toRadians(α)) * c[2]);α += 20;
fx[2] = (int)prepočítajX(x + Math.
cos(Math.toRadians(α)) * c[3]);
fy[2] = (int)prepočítajY(y + Math.
sin(Math.toRadians(α)) * c[3]);α += 50;
fx[3] = (int)prepočítajX(x + Math.
cos(Math.toRadians(α)) * c[0]);
fy[3] = (int)prepočítajY(y + Math.
sin(Math.toRadians(α)) * c[0]);α += 180;
fx[4] = (int)prepočítajX(x + Math.
cos(Math.toRadians(α)) * c[0]);
fy[4] = (int)prepočítajY(y + Math.
sin(Math.toRadians(α)) * c[0]);α += 50;
fx[5] = (int)prepočítajX(x + Math.
cos(Math.toRadians(α)) * c[3]);
fy[5] = (int)prepočítajY(y + Math.
sin(Math.toRadians(α)) * c[3]);α += 20;
fx[6] = (int)prepočítajX(x + Math.
cos(Math.toRadians(α)) * c[2]);
fy[6] = (int)prepočítajY(y + Math.
sin(Math.toRadians(α)) * c[2]);grafika.setColor(farbaPera);if (vyplnený){
grafika.fillPolygon(fx, fy, 7);}else{grafika.setStroke(čiara);
grafika.drawPolygon(fx, fy, 7);}}
else if (null == vlastnýTvarKreslenie){
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);
int šírkaObrázka = vlastnýTvarObrázok.getWidth(null);
int výškaObrázka = vlastnýTvarObrázok.getHeight(null);
if (šírkaObrázka < 0 || výškaObrázka < 0) return;if (90 == aktuálnyUhol){
if (vlastnýTvarObrázok instanceof Obrázok)((Obrázok)vlastnýTvarObrázok).
kresliNaStred((int)prepočítanéX,(int)prepočítanéY, grafika);else
grafika.drawImage(vlastnýTvarObrázok,
(int)(prepočítanéX - (šírkaObrázka / 2.0)),
(int)(prepočítanéY - (výškaObrázka / 2.0)), null);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
grafika.rotate(-α, prepočítanéX, prepočítanéY);
if (vlastnýTvarObrázok instanceof Obrázok)((Obrázok)vlastnýTvarObrázok).
kresliNaStred((int)prepočítanéX,(int)prepočítanéY, grafika);else
grafika.drawImage(vlastnýTvarObrázok,
(int)(prepočítanéX - (šírkaObrázka / 2.0)),
(int)(prepočítanéY - (výškaObrázka / 2.0)), null);
grafika.rotate(α, prepočítanéX, prepočítanéY);}}else{
Plátno aktívnePlátno_Záloha = aktívnePlátno;
BufferedImage obrázokAktívnehoPlátna_Záloha =obrázokAktívnehoPlátna;
Graphics2D grafikaAktívnehoPlátna_Záloha =grafikaAktívnehoPlátna;
boolean peroPoložené_Záloha = peroPoložené;
double aktuálneX_Záloha = aktuálneX;
double aktuálneY_Záloha = aktuálneY;
double aktuálnyUhol_Záloha = aktuálnyUhol;double domaX_Záloha = domaX;double domaY_Záloha = domaY;
double uholDoma_Záloha = uholDoma;
Písmo aktuálnePísmo_Záloha = aktuálnePísmo;
BasicStroke čiara_Záloha = čiara;
Farba farbaPera_Záloha = farbaPera;
double polomerPera_Záloha = polomerPera;aktívnePlátno = null;
obrázokAktívnehoPlátna = obrázok;
grafikaAktívnehoPlátna = grafika;peroPoložené = true;domaX = aktuálneX;domaY = aktuálneY;uholDoma = aktuálnyUhol;kreslímVlastnýTvar = true;
vlastnýTvarKreslenie.kresli(this);kreslímVlastnýTvar = false;
aktívnePlátno = aktívnePlátno_Záloha;
obrázokAktívnehoPlátna = obrázokAktívnehoPlátna_Záloha;
grafikaAktívnehoPlátna = grafikaAktívnehoPlátna_Záloha;
peroPoložené = peroPoložené_Záloha;aktuálneX = aktuálneX_Záloha;aktuálneY = aktuálneY_Záloha;
aktuálnyUhol = aktuálnyUhol_Záloha;domaX = domaX_Záloha;domaY = domaY_Záloha;uholDoma = uholDoma_Záloha;
aktuálnePísmo = aktuálnePísmo_Záloha;čiara = čiara_Záloha;farbaPera = farbaPera_Záloha;
polomerPera = polomerPera_Záloha;}
if (vráťKompozit) grafika.setComposite(záloha);}
private void kresliSpojnice(Graphics2D grafika){for (Spojnica s : spojnice){if (s.cieľ.viditeľný()){grafika.setColor(s.farba);grafika.setStroke(s.čiara);
grafika.draw(new Line2D.Double(
prepočítajX(aktuálneX), prepočítajY(aktuálneY),prepočítajX(s.cieľ.aktuálneX),
prepočítajY(s.cieľ.aktuálneY)));}}}private void vymažPôsobisko(){
minimálneX = maximálneX = aktuálneX;
minimálneY = maximálneY = aktuálneY;}
private void aktualizujPôsobisko(){
if ((aktuálneX - (polomerPera / 2)) < minimálneX) minimálneX = aktuálneX - (polomerPera / 2);
if ((aktuálneX + (polomerPera / 2)) > maximálneX) maximálneX = aktuálneX + (polomerPera / 2);
if ((aktuálneY - (polomerPera / 2)) < minimálneY) minimálneY = aktuálneY - (polomerPera / 2);
if ((aktuálneY + (polomerPera / 2)) > maximálneY) maximálneY = aktuálneY + (polomerPera / 2);}
private void aktualizujPôsobisko(double polomer){
if ((aktuálneX - polomer) < minimálneX) minimálneX = aktuálneX - polomer;
if ((aktuálneX + polomer) > maximálneX) maximálneX = aktuálneX + polomer;
if ((aktuálneY - polomer) < minimálneY) minimálneY = aktuálneY - polomer;
if ((aktuálneY + polomer) > maximálneY) maximálneY = aktuálneY + polomer;}
private void aktualizujPôsobisko(double x, double y){
if (x < minimálneX) minimálneX = x;
if (x > maximálneX) maximálneX = x;
if (y < minimálneY) minimálneY = y;
if (y > maximálneY) maximálneY = y;}
private void aktualizujPôsobisko(double novéMinX, double novéMinY, double novéMaxX, double novéMaxY){
if (novéMinX < minimálneX) minimálneX = novéMinX;
if (novéMaxX > maximálneX) maximálneX = novéMaxX;
if (novéMinY < minimálneY) minimálneY = novéMinY;
if (novéMaxY > maximálneY) maximálneY = novéMaxY;}
private void aktualizujPôsobisko(Rectangle2D rozsah){aktualizujPôsobisko(
prepočítajSpäťX(rozsah.getX()),
prepočítajSpäťY(rozsah.getY() + rozsah.getHeight()),
prepočítajSpäťX(rozsah.getX() + rozsah.getWidth()),
prepočítajSpäťY(rozsah.getY()));}
private void kresliPôsobisko(Graphics2D grafika){
grafika.setColor(farbaPôsobiska);grafika.fillRect((int)prepočítajX(minimálneX),
(int)(prepočítajY(minimálneY) -maximálneY + minimálneY),
(int)(maximálneX - minimálneX),
(int)(maximálneY - minimálneY));}
private static void potvrďVstup(){
údajeVstupnéhoRiadka.setLength(0);
údajeVstupnéhoRiadka.append(vstupnýRiadok.getText());
if (vstupnýRiadokStáleViditeľný)vstupnýRiadok.setText("");else{
panelVstupnéhoRiadka.setVisible(false);automatickéPrekreslenie();}if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.potvrdenieÚdajov();počúvadlo.potvrdenieUdajov();počúvadlo.potvrdenieVstupu();}}
private static void zrušVstup(){
zrušenéÚdajeVstupnéhoRiadka.setLength(0);
zrušenéÚdajeVstupnéhoRiadka.append(vstupnýRiadok.getText());
if (vstupnýRiadokStáleViditeľný)vstupnýRiadok.setText("");else{
panelVstupnéhoRiadka.setVisible(false);automatickéPrekreslenie();}if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.zrušenieÚdajov();počúvadlo.zrusenieUdajov();počúvadlo.zrušenieVstupu();počúvadlo.zrusenieVstupu();}}
private static Image súborNaObrázok(String súbor){int indexOf;
if (-1 != (indexOf = zoznamSúborovObrázkov.indexOf(súbor)))
return zoznamObrázkov.elementAt(indexOf);URL url = null;try{
File súborSObrázkom = new File(priečinokObrázkov + súbor);
if (súborSObrázkom.canRead()) url = súborSObrázkom.toURI().toURL();}catch (Exception e){
vypíšChybovéHlásenia(e, false);}if (null == url){try{url = new URL(súbor);}catch (Exception e){vypíšChybovéHlásenia(e);}}
if (null == url) url = GRobot.class.getResource(
(priečinokObrázkov + súbor).replace('\\', '/'));
if (null == url) throw new RuntimeException("Obrázok „" +súbor + "“ nebol nájdený!");BufferedImage obrázok = null;
try { obrázok = ImageIO.read(url); }
catch (Exception e) { vypíšChybovéHlásenia(e, true); return null; }
zoznamSúborovObrázkov.add(súbor);zoznamObrázkov.add(obrázok);zoznamIkon.add(null);return obrázok;}
private static Icon súborNaIkonu(String súbor){for (int i = 0; i < 2; ++i){int indexOf;
if (-1 != (indexOf = zoznamSúborovObrázkov.indexOf(súbor))){
if (null == zoznamIkon.elementAt(indexOf)){zoznamIkon.setElementAt(new ImageIcon(zoznamObrázkov.elementAt(indexOf)), indexOf);}
return zoznamIkon.elementAt(indexOf);}súborNaObrázok(súbor);}return null;}
private static Zvuk súborNaZvuk(String súbor){int indexOf;
if (-1 != (indexOf = zoznamSúborovZvukov.indexOf(súbor)))
return zoznamZvukov.elementAt(indexOf);URL url = null;try{
File zvukovýSúbor = new File(priečinokZvukov + súbor);
if (zvukovýSúbor.canRead()) url = zvukovýSúbor.toURI().toURL();}catch (Exception e){
vypíšChybovéHlásenia(e, false);}if (null == url){try{url = new URL(súbor);}catch (Exception e){vypíšChybovéHlásenia(e);}}
if (null == url) url = GRobot.class.getResource(
(priečinokZvukov + súbor).replace('\\', '/'));
if (null == url) throw new RuntimeException("Zvuk „" +súbor + "“ nebol nájdený!");Zvuk zvuk = Zvuk.načítaj(url);
if (null == zvuk) throw new RuntimeException
("Zvuk „" + súbor + "“ nie je možné načítať!");
zoznamSúborovZvukov.add(súbor);zoznamZvukov.add(zvuk);return zvuk;}
private static String upravLomky(String cesta,boolean lomkaNaKonci){if (null == cesta) return "";if (cesta.length() > 0){
if (lomkaNaKonci && cesta.charAt(cesta.length() - 1) != '/')return cesta + '/';}return cesta;}
private static String[] zoznamZJarSúboru(String názovJaru,
String cesta, boolean súbory, boolean priečinky){Vector<String> zoznam = null;JarFile súborJar = null;int indexOf1 = -1;if (null != cesta){
if (0 == cesta.length()) cesta = null; else{if (-1 != cesta.indexOf('\\')){
cesta = cesta.replace('\\', '/').toUpperCase() + '/';}else
cesta = cesta.toUpperCase() + '/';}}try{if (null == názovJaru)
súborJar = new JarFile(getJarPathName());else
súborJar = new JarFile(názovJaru);
Enumeration<JarEntry> položkyJaru = súborJar.entries();zoznam = new Vector<String>();
while (položkyJaru.hasMoreElements()){String názovPoložky =
položkyJaru.nextElement().getName();String názovPriečinka = null;String názovSúboru = null;int indexOf2 = -1;if (null != cesta){
if (!názovPoložky.toUpperCase().startsWith(cesta)) continue;názovPoložky = názovPoložky.substring(cesta.length(),názovPoložky.length());}
if (-1 != (indexOf1 = názovPoložky.indexOf("/"))){názovPriečinka = názovPoložky.substring(0, indexOf1);}else{
if (-1 == (indexOf2 = názovPoložky.indexOf("/", ++indexOf1))){názovSúboru = názovPoložky.substring(indexOf1,názovPoložky.length());}}
if (priečinky && null != názovPriečinka){
if (!zoznam.contains(názovPriečinka))zoznam.add(názovPriečinka);}
if (súbory && null != názovSúboru)zoznam.add(názovSúboru);}}catch (IOException e) { }
catch (NullPointerException e) { }finally{if (súborJar != null){try { súborJar.close(); }catch (IOException ioe) { }}}
if (null == zoznam) return null;
String výslednýZoznam[] = new String[zoznam.size()];
for (int i = 0; i < zoznam.size(); i++)
výslednýZoznam[i] = zoznam.get(i);return výslednýZoznam;}
private void kresli(Oblasť oblasť){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(oblasť);automatickéPrekreslenie();}
private void vyplň(Oblasť oblasť){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(oblasť);automatickéPrekreslenie();}
private void vyplň(Oblasť oblasť, String súbor){BufferedImage obrázok =
(BufferedImage)súborNaObrázok(súbor);grafikaAktívnehoPlátna.
setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(),obrázok.getHeight())));
grafikaAktívnehoPlátna.fill(oblasť);automatickéPrekreslenie();}
private void vyplň(Oblasť oblasť, BufferedImage obrázok){
float priehľadnosť = (obrázok instanceof Obrázok) ?
(float)((Obrázok)obrázok).priehľadnosť : 1.0f;if (priehľadnosť > 0){grafikaAktívnehoPlátna.
setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(null),obrázok.getHeight(null))));if (priehľadnosť < 1){Composite záloha =
grafikaAktívnehoPlátna.getComposite();
grafikaAktívnehoPlátna.setComposite(AlphaComposite.getInstance(
AlphaComposite.SRC_OVER, priehľadnosť));
grafikaAktívnehoPlátna.fill(oblasť);
grafikaAktívnehoPlátna.setComposite(záloha);}else
grafikaAktívnehoPlátna.fill(oblasť);automatickéPrekreslenie();}}
private static void vypíšChybovéHlásenia(Exception e){if (vypíšChybovéHlásenia){
System.err.println(e.getMessage());e.printStackTrace();}}
private static void vypíšChybovéHlásenia(Exception e,boolean vždyNikdy){if (vždyNikdy){
System.err.println(e.getMessage());e.printStackTrace();}}
private static class Vrstva extends TreeMap<Integer, GRobot>{
private static Vrstva daj(int číslo){
Vrstva vrstva = zoznamVrstiev.get(číslo);if (null == vrstva){vrstva = new Vrstva();
zoznamVrstiev.put(číslo, vrstva);}return vrstva;}
private static void vymaž(GRobot robot){
int index = zoznamRobotov.indexOf(robot);if (-1 != index){
Vrstva vrstva = zoznamVrstiev.get(robot.vrstva);if (null != vrstva){
if (robot == vrstva.get(index)){vrstva.remove(index);return;}
for (Map.Entry<Integer, GRobot>hľadaj : vrstva.entrySet()){
if (robot == hľadaj.getValue()){
vrstva.remove(hľadaj.getKey());return;}}}}}
private static void vymaž(int začiatok, int koniec){
if (0 <= začiatok && 0 <= koniec){if (začiatok > koniec){int a = začiatok;začiatok = koniec;koniec = a;}
for (int i = začiatok; i <= koniec; ++i)vymaž(zoznamRobotov.get(i));}}
private static void vlož(GRobot robot){
int index = zoznamRobotov.indexOf(robot);if (-1 != index){
Vrstva vrstva = daj(robot.vrstva);if (null != vrstva)vrstva.put(index, robot);}}
private static void vlož(int začiatok, int koniec){
if (0 <= začiatok && 0 <= koniec){if (začiatok > koniec){int a = začiatok;začiatok = koniec;koniec = a;}
for (int i = začiatok; i <= koniec; ++i)vlož(zoznamRobotov.get(i));}}
private static void preraď(GRobot robot, int vrstva){vymaž(robot);robot.vrstva = vrstva;vlož(robot);}}
private static class RobotTextField extends JTextField{public RobotTextField(){
addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
for (Component component = getParent();null != component; component =component.getParent()){
if (component instanceof JOptionPane){
JOptionPane pane = (JOptionPane)component;
pane.setValue(predvolenéOdpovedeZadania[0]);pane.setVisible(false);break;}}}});}}
private static class RobotPasswordField extends JPasswordField{public RobotPasswordField(){
addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
for (Component component = getParent();null != component; component =component.getParent()){
if (component instanceof JOptionPane){
JOptionPane pane = (JOptionPane)component;
pane.setValue(predvolenéOdpovedeZadania[0]);pane.setVisible(false);break;}}}});}}
private static class ČlánokKonzoly{public Farba farba = null;public Point2D poloha = null;
public StringBuffer článok = null;public String[] slová = null;}
private static class RiadokKonzoly extends Vector<ČlánokKonzoly> {}
private static class Časovač implements ActionListener{private Timer časovač;
private Časovač() { časovač = null; }
public void actionPerformed(ActionEvent evt){poslednýTik = evt;
žiadamPrekresleniePoPráci = false;pracujem =true;aspoňJedenAktívny = false;synchronized (zámokUdalostí){zoznamZmenený1 = false;if (zámokZoznamuRobotov1){System.err.println("Príliš " +"veľa požiadaviek časovača…");}else{zámokZoznamuRobotov1 = true;
for (GRobot tento : zoznamRobotov){tento.pracuj();if (zoznamZmenený1){System.err.println(
"Zoznam robotov bol počas práce " +
"zmenený, preto nie všetky roboty " +
"mohli v tomto pracovnom cykle " +"vykonať svoju činnosť!");break;}}zámokZoznamuRobotov1 = false;zlúčiťZoznamy();}
if (null != počúvadlo) počúvadlo.tik();}pracujem = false;
if (žiadamPrekresleniePoPráci) svet.prekresli();
else if (aspoňJedenAktívny) automatickéPrekreslenie();}public void spusti(int čas){if (null == časovač){
časovač = new Timer(čas, GRobot.časovač);časovač.start();}else{časovač.stop();časovač.setInitialDelay(čas);časovač.setDelay(čas);časovač.start();}}public void odlož(int čas){if (null == časovač){
časovač = new Timer(čas, GRobot.časovač);časovač.setInitialDelay(čas);časovač.setDelay(čas);časovač.start();}else{časovač.stop();časovač.setInitialDelay(čas);časovač.start();}}
public boolean aktívny() { return null != časovač && časovač.isRunning(); }public int interval()
{ return null == časovač ? 0 : časovač.getDelay(); }public void zastav(){
if (null != časovač) časovač.stop();}};
private final static Časovač časovač = new Časovač();
private static class UdalostiOkna implements MouseListener,
MouseMotionListener, MouseWheelListener, KeyListener,ComponentListener{
public void mouseClicked(MouseEvent e){synchronized (zámokMyši){poslednáUdalosťMyši = e;
hlavnýPanel.requestFocusInWindow();if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.klik();}}}
public void mouseEntered(MouseEvent e) {}
public void mouseExited(MouseEvent e) {}
public void mousePressed(MouseEvent e){synchronized (zámokMyši){
súradnicaMyšiX = korekciaMyšiX(e.getX());
súradnicaMyšiY = korekciaMyšiY(e.getY());
e.translatePoint((int)súradnicaMyšiX - e.getX(),
(int)súradnicaMyšiY - e.getY());
if (e.getButton() == e.BUTTON1){tlačidloMyši = 1;tlačidloMyši1 = true;}
else if (e.getButton() == e.BUTTON2){tlačidloMyši = 2;tlačidloMyši2 = true;}
else if (e.getButton() == e.BUTTON3){tlačidloMyši = 3;tlačidloMyši3 = true;}else tlačidloMyši = 0;poslednáUdalosťMyši = e;if (null != počúvadlo)synchronized (zámokUdalostí){
počúvadlo.stlačenieTlačidlaMyši();
počúvadlo.stlacenieTlacidlaMysi();}}}
public void mouseReleased(MouseEvent e){synchronized (zámokMyši){
súradnicaMyšiX = korekciaMyšiX(e.getX());
súradnicaMyšiY = korekciaMyšiY(e.getY());
e.translatePoint((int)súradnicaMyšiX - e.getX(),
(int)súradnicaMyšiY - e.getY());
if (e.getButton() == e.BUTTON1){tlačidloMyši = 1;tlačidloMyši1 = false;}
else if (e.getButton() == e.BUTTON2){tlačidloMyši = 2;tlačidloMyši2 = false;}
else if (e.getButton() == e.BUTTON3){tlačidloMyši = 3;tlačidloMyši3 = false;}else tlačidloMyši = 0;poslednáUdalosťMyši = e;if (null != počúvadlo)synchronized (zámokUdalostí){
počúvadlo.uvoľnenieTlačidlaMyši();
počúvadlo.uvolnenieTlacidlaMysi();}}}
public void mouseMoved(MouseEvent e){synchronized (zámokMyši){
súradnicaMyšiX = korekciaMyšiX(e.getX());
súradnicaMyšiY = korekciaMyšiY(e.getY());
e.translatePoint((int)súradnicaMyšiX - e.getX(),
(int)súradnicaMyšiY - e.getY());poslednáUdalosťMyši = e;if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.pohybMyši();počúvadlo.pohybMysi();}}}
public void mouseDragged(MouseEvent e){synchronized (zámokMyši){
súradnicaMyšiX = korekciaMyšiX(e.getX());
súradnicaMyšiY = korekciaMyšiY(e.getY());
e.translatePoint((int)súradnicaMyšiX - e.getX(),
(int)súradnicaMyšiY - e.getY());poslednáUdalosťMyši = e;if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.ťahanieMyšou();počúvadlo.tahanieMysou();}}}
public void mouseWheelMoved(MouseWheelEvent e){synchronized (zámokMyši){
súradnicaMyšiX = korekciaMyšiX(e.getX());
súradnicaMyšiY = korekciaMyšiY(e.getY());
e.translatePoint((int)súradnicaMyšiX - e.getX(),
(int)súradnicaMyšiY - e.getY());
poslednáUdalosťMyši = poslednáUdalosťRolovania = e;if (e.isShiftDown()){
rolovanieKolieskomMyšiX = e.getWheelRotation();rolovanieKolieskomMyšiY = 0;}else{rolovanieKolieskomMyšiX = 0;
rolovanieKolieskomMyšiY = -e.getWheelRotation();}if (null == počúvadlo)strop.rolujTexty();else synchronized (zámokUdalostí){
počúvadlo.rolovanieKolieskomMyši();
počúvadlo.rolovanieKolieskomMysi();}}}
public void keyPressed(KeyEvent e){synchronized (zámokKlávesnice){poslednáUdalosťKlávesnice = e;if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.stlačenieKlávesu();počúvadlo.stlacenieKlavesu();}}}
public void keyReleased(KeyEvent e){synchronized (zámokKlávesnice){poslednáUdalosťKlávesnice = e;if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.uvoľnenieKlávesu();počúvadlo.uvolnenieKlavesu();}}}
public void keyTyped(KeyEvent e){synchronized (zámokKlávesnice){poslednáUdalosťKlávesnice = e;if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.zadanieZnaku();}}}
public void componentHidden(ComponentEvent e) {}
public void componentShown(ComponentEvent e) {}
public void componentMoved(ComponentEvent e){poslednáUdalosťOkna = e;if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.presunutieOkna();}}
public void componentResized(ComponentEvent e){poslednáUdalosťOkna = e;if (null != počúvadlo){synchronized (zámokUdalostí){počúvadlo.zmenaVeľkostiOkna();počúvadlo.zmenaVelkostiOkna();
if (konzolaPoužitá) automatickéPrekreslenie();}}
else if (konzolaPoužitá) svet.prekresli();}}
private final static UdalostiOkna udalostiOkna = new UdalostiOkna();
private static class VykonajVObrázku{
private final static float[][] maticeRozmazania = {{0.070f, 0.120f, 0.070f,0.120f, 0.240f, 0.120f,0.070f, 0.120f, 0.070f},
{0.006f, 0.027f, 0.036f, 0.027f, 0.006f,
0.027f, 0.056f, 0.071f, 0.056f, 0.027f,
0.036f, 0.071f, 0.107f, 0.071f, 0.036f,
0.027f, 0.056f, 0.071f, 0.056f, 0.027f,
0.006f, 0.027f, 0.036f, 0.027f, 0.006f},
{0.000f, 0.006f, 0.013f, 0.015f, 0.013f, 0.006f, 0.000f,
0.006f, 0.017f, 0.026f, 0.030f, 0.026f, 0.017f, 0.006f,
0.013f, 0.026f, 0.039f, 0.045f, 0.039f, 0.026f, 0.013f,
0.015f, 0.030f, 0.045f, 0.060f, 0.045f, 0.030f, 0.015f,
0.013f, 0.026f, 0.039f, 0.045f, 0.039f, 0.026f, 0.013f,
0.006f, 0.017f, 0.026f, 0.030f, 0.026f, 0.017f, 0.006f,
0.000f, 0.006f, 0.013f, 0.015f, 0.013f, 0.006f, 0.000f},
{0.000f, 0.000f, 0.004f, 0.007f, 0.008f, 0.007f, 0.004f, 0.000f, 0.000f,
0.000f, 0.006f, 0.011f, 0.014f, 0.015f, 0.014f, 0.011f, 0.006f, 0.000f,
0.004f, 0.011f, 0.017f, 0.021f, 0.023f, 0.021f, 0.017f, 0.011f, 0.004f,
0.007f, 0.014f, 0.021f, 0.028f, 0.031f, 0.028f, 0.021f, 0.014f, 0.007f,
0.008f, 0.015f, 0.023f, 0.031f, 0.038f, 0.031f, 0.023f, 0.015f, 0.008f,
0.007f, 0.014f, 0.021f, 0.028f, 0.031f, 0.028f, 0.021f, 0.014f, 0.007f,
0.004f, 0.011f, 0.017f, 0.021f, 0.023f, 0.021f, 0.017f, 0.011f, 0.004f,
0.000f, 0.006f, 0.011f, 0.014f, 0.015f, 0.014f, 0.011f, 0.006f, 0.000f,
0.000f, 0.000f, 0.004f, 0.007f, 0.008f, 0.007f, 0.004f, 0.000f, 0.000f},
{0.000f, 0.000f, 0.001f, 0.003f, 0.004f, 0.005f, 0.004f, 0.003f, 0.001f, 0.000f, 0.000f,
0.000f, 0.002f, 0.005f, 0.007f, 0.009f, 0.010f, 0.009f, 0.007f, 0.005f, 0.002f, 0.000f,
0.001f, 0.005f, 0.008f, 0.011f, 0.014f, 0.014f, 0.014f, 0.011f, 0.008f, 0.005f, 0.001f,
0.003f, 0.007f, 0.011f, 0.015f, 0.018f, 0.019f, 0.018f, 0.015f, 0.011f, 0.007f, 0.003f,
0.004f, 0.009f, 0.014f, 0.018f, 0.022f, 0.024f, 0.022f, 0.018f, 0.014f, 0.009f, 0.004f,
0.005f, 0.010f, 0.014f, 0.019f, 0.024f, 0.029f, 0.024f, 0.019f, 0.014f, 0.010f, 0.005f,
0.004f, 0.009f, 0.014f, 0.018f, 0.022f, 0.024f, 0.022f, 0.018f, 0.014f, 0.009f, 0.004f,
0.003f, 0.007f, 0.011f, 0.015f, 0.018f, 0.019f, 0.018f, 0.015f, 0.011f, 0.007f, 0.003f,
0.001f, 0.005f, 0.008f, 0.011f, 0.014f, 0.014f, 0.014f, 0.011f, 0.008f, 0.005f, 0.001f,
0.000f, 0.002f, 0.005f, 0.007f, 0.009f, 0.010f, 0.009f, 0.007f, 0.005f, 0.002f, 0.000f,
0.000f, 0.000f, 0.001f, 0.003f, 0.004f, 0.005f, 0.004f, 0.003f, 0.001f, 0.000f, 0.000f},};
private final static ConvolveOp rozmazanie[] = {
new ConvolveOp(new Kernel(3, 3, maticeRozmazania[0]),ConvolveOp.EDGE_NO_OP, null),
new ConvolveOp(new Kernel(5, 5, maticeRozmazania[1]),ConvolveOp.EDGE_NO_OP, null),
new ConvolveOp(new Kernel(7, 7, maticeRozmazania[2]),ConvolveOp.EDGE_NO_OP, null),
new ConvolveOp(new Kernel(9, 9, maticeRozmazania[3]),ConvolveOp.EDGE_NO_OP, null),
new ConvolveOp(new Kernel(11, 11, maticeRozmazania[4]),ConvolveOp.EDGE_NO_OP, null),};private static int x = 0;private static int y = 0;private static int index = 0;
private final static int počiatočnáVeľkosťZásobníka = 300000;
private static int[] zásobníkX = new int[počiatočnáVeľkosťZásobníka];
private static int[] zásobníkY = new int[počiatočnáVeľkosťZásobníka];
private static int[] zásobníkIndexov = new int[počiatočnáVeľkosťZásobníka];
private static int ukazovateľZásobníka = -1;
private static int[] údajeObrázka = null;
private static int[] údajeMasky = null;private static int šírka = 0;private static int výška = 0;
private static int aktuálnaFarba = 0;
private static int podkladováFarba = 0;
private static int A = 0, R = 0, G = 0, B = 0;
private static void zväčšiZásobník(){
zásobníkX = Arrays.copyOf(zásobníkX, zásobníkX.length * 2);
zásobníkY = Arrays.copyOf(zásobníkY, zásobníkY.length * 2);
zásobníkIndexov = Arrays.copyOf(zásobníkIndexov, zásobníkIndexov.length * 2);}
private static boolean vyberZoZásobníka(){if (ukazovateľZásobníka >= 0){
x = zásobníkX[ukazovateľZásobníka];
y = zásobníkY[ukazovateľZásobníka];
index = zásobníkIndexov[ukazovateľZásobníka];--ukazovateľZásobníka;return true;}return false;}
private static void vložDoZásobníka(int x, int index){
while (ukazovateľZásobníka >= zásobníkX.length)zväčšiZásobník();++ukazovateľZásobníka;
zásobníkX[ukazovateľZásobníka] = x;
zásobníkY[ukazovateľZásobníka] = y;
zásobníkIndexov[ukazovateľZásobníka] = index;}
private static void vyprázdniZásobník(){ukazovateľZásobníka = -1;}
private static void riešAlias(){
int xs = (x > 0) ? (x - 1) : 0;
int xh = (x + 1 < šírka) ? (x + 1) : x;
int ys = (y > 0) ? (y - 1) : 0;
int yh = (y + 1 < výška) ? (y + 1) : y;for (int i = 0; i < 4; ++i){
int xx = (i % 2 == 0) ? xs : xh;
int yy = (i / 2 == 0) ? ys : yh;{
int farba = údajeObrázka[xx + yy * šírka];
if (farba != podkladováFarba && farba != aktuálnaFarba){int a = (farba >> 24) & 0xff;if (a < 255){if (a == 0){
údajeObrázka[xx + yy * šírka] = aktuálnaFarba;}else{int r = (farba >> 16) & 0xff;int g = (farba >>  8) & 0xff;int b  = farba        & 0xff;
int ax = 65535 - ((255 - a) * (255 - A));
int rx = (r * a * 255) + (R * A * (255 - a));
int gx = (g * a * 255) + (G * A * (255 - a));
int bx = (b * a * 255) + (B * A * (255 - a));rx /= ax; gx /= ax; bx /= ax;
údajeObrázka[xx + yy * šírka] =
(((((ax << 8) | rx) << 8) | gx) << 8) | bx;}}}}}}
public static void negatív(BufferedImage obrázok){
údajeObrázka = ((DataBufferInt)obrázok.getRaster().getDataBuffer()).getData();
for (int i = 0; i < údajeObrázka.length; ++i)údajeObrázka[i] ^= 0xffffff;}
public static boolean použiMasku(BufferedImage obrázok,BufferedImage maska){
if (obrázok.getWidth() != maska.getWidth() ||
obrázok.getHeight() != maska.getHeight()) return false;
údajeObrázka = ((DataBufferInt)obrázok.getRaster().getDataBuffer()).getData();
údajeMasky = ((DataBufferInt)maska.getRaster().getDataBuffer()).getData();
for (int i = 0; i < údajeObrázka.length; ++i){aktuálnaFarba = údajeMasky[i];
A = (aktuálnaFarba >> 24) & 0xff;
int a = (údajeObrázka[i] >> 24) & 0xff;
if (A == 0 || a == 0) aktuálnaFarba = 0; else{
R = (aktuálnaFarba >> 16) & 0xff;
G = (aktuálnaFarba >>  8) & 0xff;
B =  aktuálnaFarba        & 0xff;
aktuálnaFarba = ((765 - R - G - B) * A * a) / 0x2fa03;}
údajeObrázka[i] = (údajeObrázka[i] & 0xffffff) |(aktuálnaFarba << 24);}return true;}
public static BufferedImage vyrobMasku(BufferedImage obrázok,BufferedImage nováMaska){
if (null == nováMaska) nováMaska = new BufferedImage(
obrázok.getWidth(), obrázok.getHeight(),BufferedImage.TYPE_INT_ARGB);
else if (obrázok.getWidth() != nováMaska.getWidth() ||
obrázok.getHeight() != nováMaska.getHeight()) return null;
údajeObrázka = ((DataBufferInt)obrázok.getRaster().getDataBuffer()).getData();
údajeMasky = ((DataBufferInt)nováMaska.getRaster().getDataBuffer()).getData();
for (int i = 0; i < údajeObrázka.length; ++i){
údajeMasky[i] = údajeObrázka[i] & 0xff000000;}return nováMaska;}
public static void rozmaž(BufferedImage obrázok, Graphics2D
grafika, int opakovanie, int rozsah, Color farbaPozadia){
if (rozsah < 1 || opakovanie < 1) return;
if (--rozsah >= rozmazanie.length)
rozsah = rozmazanie.length - 1;
BufferedImage naRozmazanie = new
BufferedImage(obrázok.getWidth() + (rozsah + 1) * 2,
obrázok.getHeight() + (rozsah + 1) * 2,BufferedImage.TYPE_INT_ARGB);
naRozmazanie.createGraphics().drawImage(obrázok,rozsah + 1, rozsah + 1, null);
údajeObrázka = ((DataBufferInt)naRozmazanie.getRaster().getDataBuffer()).getData();
aktuálnaFarba = farbaPozadia.getRGB() & 0xffffff;
for (int i = 0; i < údajeObrázka.length; ++i){
if (0 == ((údajeObrázka[i] >> 24) & 255))
údajeObrázka[i] = aktuálnaFarba;}
for (int i = 0; i < opakovanie; ++i)
naRozmazanie = rozmazanie[rozsah].filter(naRozmazanie, null);
Arrays.fill(((DataBufferInt)obrázok.getRaster().
getDataBuffer()).getData(), 0);
grafika.drawImage(naRozmazanie,
-rozsah - 1, -rozsah - 1, null);}
public static void vylejFarbu(BufferedImage obrázok, double x0,double y0, Color farba){šírka = obrázok.getWidth();výška = obrázok.getHeight();x = (int)((šírka / 2.0) + x0);y = (int)((výška / 2.0) - y0);
if (x < 0 || x >= šírka || y < 0 || y >= výška) return;
údajeObrázka = ((DataBufferInt)obrázok.getRaster().getDataBuffer()).getData();
aktuálnaFarba = farba.getRGB();index = x + y * šírka;
podkladováFarba = údajeObrázka[index];
if (podkladováFarba == aktuálnaFarba) return;
A = (aktuálnaFarba >> 24) & 0xff;
R = (aktuálnaFarba >> 16) & 0xff;
G = (aktuálnaFarba >>  8) & 0xff;
B =  aktuálnaFarba        & 0xff;
boolean ľaváZarážka, praváZarážka;vyprázdniZásobník();vložDoZásobníka(x, index);while (vyberZoZásobníka()){while (y >= 0 &&
údajeObrázka[index] == podkladováFarba){ --y; index -= šírka; }++y; index += šírka;
ľaváZarážka = praváZarážka = false;while (y < výška &&
údajeObrázka[index] == podkladováFarba){
údajeObrázka[index] = aktuálnaFarba;riešAlias();if (!ľaváZarážka && x > 0 &&
údajeObrázka[index - 1] == podkladováFarba){
vložDoZásobníka(x - 1, index - 1);ľaváZarážka = true;}
else if (ľaváZarážka && x > 0 &&
údajeObrázka[index - 1] != podkladováFarba){ľaváZarážka = false;}
if (!praváZarážka && x < šírka - 1 &&
údajeObrázka[index + 1] == podkladováFarba){
vložDoZásobníka(x + 1, index + 1);praváZarážka = true;}
else if (praváZarážka && x < šírka - 1 &&
údajeObrázka[index + 1] != podkladováFarba){praváZarážka = false;}++y; index += šírka;}}}
public static void roluj(BufferedImage obrázok, int Δx, int Δy){
if (Δx == 0 && Δy == 0) return;Δy = -Δy;
údajeObrázka = ((DataBufferInt)obrázok.getRaster().getDataBuffer()).getData();šírka = obrázok.getWidth();výška = obrázok.getHeight();
if (Δx >= šírka || Δx <= -šírka ||Δy >= výška || Δy <= -výška){Arrays.fill(údajeObrázka, 0);return;}
int spodnáZarážka, vrchnáZarážka,
zarážkaRiadkov, zarážkaStĺpcov;if (Δy <= 0){spodnáZarážka = 0;
vrchnáZarážka = šírka * -Δy - Δx;zarážkaRiadkov = výška + Δy;if (Δx <= 0){zarážkaStĺpcov = šírka + Δx;
for (int i = 0; i < zarážkaRiadkov; ++i){int j = 0;
for (; j < zarážkaStĺpcov; ++j)
údajeObrázka[spodnáZarážka + j] =
údajeObrázka[vrchnáZarážka + j];for (; j < šírka; ++j)
údajeObrázka[spodnáZarážka + j] = 0;spodnáZarážka += šírka;vrchnáZarážka += šírka;}}else{zarážkaStĺpcov = Δx;
for (int i = 0; i < zarážkaRiadkov; ++i){int j = šírka - 1;
for (; j >= zarážkaStĺpcov; --j)
údajeObrázka[spodnáZarážka + j] =
údajeObrázka[vrchnáZarážka + j];for (; j >= 0; --j)
údajeObrázka[spodnáZarážka + j] = 0;spodnáZarážka += šírka;vrchnáZarážka += šírka;}}vrchnáZarážka = šírka * výška;
while (spodnáZarážka < vrchnáZarážka){
údajeObrázka[spodnáZarážka] = 0;++spodnáZarážka;}}else{
spodnáZarážka = -Δx + šírka * (výška - 1 - Δy);
vrchnáZarážka = šírka * (výška - 1);zarážkaRiadkov = Δy;if (Δx <= 0){zarážkaStĺpcov = šírka + Δx;
for (int i = výška - 1; i >= zarážkaRiadkov; --i){int j = 0;
for (; j < zarážkaStĺpcov; ++j)
údajeObrázka[vrchnáZarážka + j] =
údajeObrázka[spodnáZarážka + j];for (; j < šírka; ++j)
údajeObrázka[vrchnáZarážka + j] = 0;spodnáZarážka -= šírka;vrchnáZarážka -= šírka;}}else{zarážkaStĺpcov = Δx;
for (int i = výška - 1; i >= zarážkaRiadkov; --i){int j = šírka - 1;
for (; j >= zarážkaStĺpcov; --j)
údajeObrázka[vrchnáZarážka + j] =
údajeObrázka[spodnáZarážka + j];for (; j >= 0; --j)
údajeObrázka[vrchnáZarážka + j] = 0;spodnáZarážka -= šírka;vrchnáZarážka -= šírka;}}
vrchnáZarážka = (šírka * Δy) - 1;while (vrchnáZarážka >= 0){
údajeObrázka[vrchnáZarážka] = 0;--vrchnáZarážka;}}}
public static void pretoč(BufferedImage obrázok, int Δx, int Δy){
if (Δx == 0 && Δy == 0) return;Δy = -Δy;
údajeObrázka = ((DataBufferInt)obrázok.getRaster().getDataBuffer()).getData();
údajeMasky = new int[údajeObrázka.length];
System.arraycopy(údajeObrázka, 0,
údajeMasky, 0, údajeObrázka.length);šírka = obrázok.getWidth();výška = obrázok.getHeight();while (Δx < 0) Δx += šírka;
while (Δx >= šírka) Δx -= šírka;while (Δy < 0) Δy += výška;
while (Δy >= výška) Δy -= výška;
int index1 = 0, index2 = šírka * (výška + 1 - Δy) - Δx;for (int i = Δy; i > 0; --i){for (int j = Δx; j > 0; --j){údajeObrázka[index1++] =údajeMasky[index2++];}index2 -= šírka;
for (int j = šírka - Δx; j > 0; --j){údajeObrázka[index1++] =údajeMasky[index2++];}index2 += šírka;}index2 = šírka - Δx;
for (int i = výška - Δy; i > 0; --i){for (int j = Δx; j > 0; --j){údajeObrázka[index1++] =údajeMasky[index2++];}index2 -= šírka;
for (int j = šírka - Δx; j > 0; --j){údajeObrázka[index1++] =údajeMasky[index2++];}index2 += šírka;}}}
private static String getJarPathName(){
StringBuffer jarName = new StringBuffer(GRobot.class.
getProtectionDomain().getCodeSource().getLocation().getPath());int indexOf;
if (-1 != (indexOf = jarName.lastIndexOf("/")))
jarName.delete(0, 1 + indexOf);
if (0 == jarName.length()) return null;
jarName.insert(0, System.getProperty("user.dir") +File.separator);return jarName.toString();}public GRobot(){inicializujGrafiku(this);inicializujRobota();}
public GRobot(String novýTitulok){inicializujGrafiku(this);svet.setTitle(novýTitulok);inicializujRobota();}
public GRobot(int nováMaximálnaŠírka, int nováMaximálnaVýška){if (inicializované)
throw new RuntimeException("Svet už jestvuje!");
šírkaPlátna = nováMaximálnaŠírka;
výškaPlátna = nováMaximálnaVýška;
podlaha.vytvorNovéPlátno(šírkaPlátna, výškaPlátna);
strop.vytvorNovéPlátno(šírkaPlátna, výškaPlátna);
obrázok = new BufferedImage(šírkaPlátna, výškaPlátna,BufferedImage.TYPE_INT_ARGB);
grafika = obrázok.createGraphics();
vyrovnávaciaPamäťObrázka = new BufferedImage(šírkaPlátna,
výškaPlátna, BufferedImage.TYPE_INT_ARGB);vyrovnávaciaPamäťGrafiky =
vyrovnávaciaPamäťObrázka.createGraphics();inicializujGrafiku(this);inicializujRobota();}
public GRobot(int nováMaximálnaŠírka, int nováMaximálnaVýška,String novýTitulok){if (inicializované)
throw new RuntimeException("Svet už jestvuje!");
šírkaPlátna = nováMaximálnaŠírka;
výškaPlátna = nováMaximálnaVýška;
podlaha.vytvorNovéPlátno(šírkaPlátna, výškaPlátna);
strop.vytvorNovéPlátno(šírkaPlátna, výškaPlátna);
obrázok = new BufferedImage(šírkaPlátna, výškaPlátna,BufferedImage.TYPE_INT_ARGB);
grafika = obrázok.createGraphics();
vyrovnávaciaPamäťObrázka = new BufferedImage(šírkaPlátna,
výškaPlátna, BufferedImage.TYPE_INT_ARGB);vyrovnávaciaPamäťGrafiky =
vyrovnávaciaPamäťObrázka.createGraphics();inicializujGrafiku(this);svet.setTitle(novýTitulok);inicializujRobota();}
public double hrúbkaPera() { return polomerPera; }
public double hrubkaPera() { return polomerPera; }
public double hrúbkaČiary() { return polomerPera; }
public double hrubkaCiary() { return polomerPera; }
public void hrúbkaPera(double nováHrúbka){
if (nováHrúbka < 0) throw new RuntimeException("Hrúbka čiary pera nesmie byť záporná!");polomerPera = nováHrúbka;
čiara = new BasicStroke((float)polomerPera,
BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
if (viditeľný && null == vlastnýTvarObrázok &&
null == vlastnýTvarKreslenie && !vyplnený)automatickéPrekreslenie();}
public void hrubkaPera(double nováHrúbka) { hrúbkaPera(nováHrúbka); }
public void hrúbkaČiary(double nováHrúbka){
if (nováHrúbka < 0) throw new RuntimeException("Hrúbka čiary pera nesmie byť záporná!");polomerPera = nováHrúbka;
čiara = new BasicStroke((float)polomerPera,
BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
if (viditeľný && null == vlastnýTvarObrázok &&
(null != vlastnýTvarKreslenie || !vyplnený))automatickéPrekreslenie();}
public void hrubkaCiary(double nováHrúbka) { hrúbkaČiary(nováHrúbka); }
public void predvolenáHrúbkaPera() { hrúbkaPera(predvolenýPolomerPera); }
public void predvolenaHrubkaPera() { hrúbkaPera(predvolenýPolomerPera); }
public void predvolenáHrúbkaČiary() { hrúbkaPera(predvolenýPolomerPera); }
public void predvolenaHrubkaCiary() { hrúbkaPera(predvolenýPolomerPera); }
public Farba farba() { return farbaPera; }
public void farba(Color nováFarba){
if (nováFarba instanceof Farba)farbaPera = (Farba)nováFarba;else
farbaPera = new Farba(nováFarba);
if (viditeľný) automatickéPrekreslenie();}
public void farba(Farebnosť podľaObjektu)
{ farba(podľaObjektu.farba()); }
public Farba farba(int r, int g, int b){
farbaPera = new Farba(r, g, b);
if (viditeľný) automatickéPrekreslenie();return farbaPera;}
public Farba farba(int r, int g, int b, int a){
farbaPera = new Farba(r, g, b, a);
if (viditeľný) automatickéPrekreslenie();return farbaPera;}public void predvolenáFarba(){farbaPera = predvolenéPero;
if (viditeľný) automatickéPrekreslenie();}
public void predvolenaFarba() { predvolenáFarba(); }
public boolean polohaPera() { return peroPoložené; }
public boolean peroZdvihnuté() { return !peroPoložené; }
public boolean peroZdvihnute() { return !peroPoložené; }
public boolean peroPoložené() { return peroPoložené; }
public boolean peroPolozene() { return peroPoložené; }
public void polohaPera(boolean polož) { peroPoložené = polož; }
public void zdvihniPero() { peroPoložené = false; }
public void položPero() { peroPoložené = true; }
public void polozPero() { peroPoložené = true; }
public boolean viditeľný() { return viditeľný; }
public boolean viditelny() { return viditeľný; }
public boolean zobrazený() { return viditeľný; }
public boolean zobrazeny() { return viditeľný; }
public boolean skrytý() { return !viditeľný; }
public boolean skryty() { return !viditeľný; }public void ukáž(){viditeľný = true;automatickéPrekreslenie();}public void ukaz() { ukáž(); }public void zobraz(){viditeľný = true;automatickéPrekreslenie();}public void skry(){viditeľný = false;automatickéPrekreslenie();}
public double priehľadnosť() { return priehľadnosť; }
public double priehladnost() { return priehľadnosť; }
public void priehľadnosť(double priehľadnosť){
this.priehľadnosť = (float)priehľadnosť;automatickéPrekreslenie();}
public void priehladnost(double priehľadnosť)
{ priehľadnosť(priehľadnosť); }
public void priehľadnosť(Priehľadnosť objekt){
this.priehľadnosť = (float)objekt.priehľadnosť();automatickéPrekreslenie();}
public void priehladnost(Priehľadnosť objekt){ priehľadnosť(objekt); }
public void upravPriehľadnosť(double zmena){
if (0 == priehľadnosť) priehľadnosť = 0.1f;
else priehľadnosť *= (float)zmena;automatickéPrekreslenie();}
public void upravPriehladnost(double zmena){ upravPriehľadnosť(zmena); }
public Písmo písmo() { return aktuálnePísmo; }
public Pismo pismo() { return new Pismo(aktuálnePísmo); }
public void písmo(Písmo novéPísmo) { aktuálnePísmo = novéPísmo; }
public void pismo(Písmo novéPísmo) { aktuálnePísmo = novéPísmo; }
public void písmo(Object novéPísmo){
if (novéPísmo instanceof Písmo) písmo((Písmo)novéPísmo);}
public void pismo(Object novéPísmo) { písmo(novéPísmo); }
public Písmo písmo(String názov, int veľkosť){
return aktuálnePísmo = new Písmo(názov, Písmo.PLAIN, veľkosť);}
public Pismo pismo(String názov, int veľkosť)
{ return new Pismo(písmo(názov, veľkosť)); }
public void predvolenéPísmo() { písmo(predvolenéPísmo); }
public void predvolenePismo() { písmo(predvolenéPísmo); }
public double polohaX() { return aktuálneX; }
public double polohaY() { return aktuálneY; }
public double súradnicaX() { return aktuálneX; }
public double suradnicaX() { return aktuálneX; }
public double súradnicaY() { return aktuálneY; }
public double suradnicaY() { return aktuálneY; }
public void polohaX(double novéX){aktuálneX = novéX;if (záznamCesty){if (záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(novéX),prepočítajY(aktuálneY));else cesta.moveTo(prepočítajX(novéX),prepočítajY(aktuálneY));}
if (viditeľný) automatickéPrekreslenie();}
public void polohaY(double novéY){aktuálneY = novéY;if (záznamCesty){if (záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(aktuálneX),prepočítajY(novéY));else cesta.moveTo(prepočítajX(aktuálneX),prepočítajY(novéY));}
if (viditeľný) automatickéPrekreslenie();}
public void súradnicaX(double novéX) { polohaX(novéX); }
public void suradnicaX(double novéX) { polohaX(novéX); }
public void súradnicaY(double novéY) { polohaY(novéY); }
public void suradnicaY(double novéY) { polohaY(novéY); }public Point2D.Double poloha(){
return new Point2D.Double(aktuálneX, aktuálneY);}
public void poloha(Point2D poloha){aktuálneX = poloha.getX();aktuálneY = poloha.getY();if (záznamCesty){if (záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(aktuálneX),prepočítajY(aktuálneY));else cesta.moveTo(prepočítajX(aktuálneX),prepočítajY(aktuálneY));}
if (viditeľný) automatickéPrekreslenie();}
public double uhol() { return aktuálnyUhol; }
public double smer() { return aktuálnyUhol; }public void uhol(double uhol){aktuálnyUhol = uhol;aktuálnyUhol %= 360;
if (aktuálnyUhol < 0) aktuálnyUhol += 360;
if (viditeľný) automatickéPrekreslenie();}public void smer(double uhol){aktuálnyUhol = uhol;aktuálnyUhol %= 360;
if (aktuálnyUhol < 0) aktuálnyUhol += 360;
if (viditeľný) automatickéPrekreslenie();}public void otoč(double uhol){aktuálnyUhol = uhol;aktuálnyUhol %= 360;
if (aktuálnyUhol < 0) aktuálnyUhol += 360;
if (viditeľný) automatickéPrekreslenie();}
public void otoc(double uhol) { otoč(uhol); }public void náhodnáPoloha(){skočNa(svet.náhodnéCeléČíslo(
(long)svet.najmenšieX(), (long)svet.najväčšieX()),svet.náhodnéCeléČíslo(
(long)svet.najmenšieY(), (long)svet.najväčšieY()));}
public void nahodnaPoloha() { náhodnáPoloha(); }
public void náhodnáPozícia() { náhodnáPoloha(); }
public void nahodnaPozicia() { náhodnáPoloha(); }public void náhodnýSmer(){
smer(svet.náhodnéCeléČíslo(0, 360));}
public void nahodnySmer() { náhodnýSmer(); }
public void náhodnýUhol() { náhodnýSmer(); }
public void nahodnyUhol() { náhodnýSmer(); }public void domov(){aktuálneX = domaX;aktuálneY = domaY;aktuálnyUhol = uholDoma;
if (kreslímVlastnýTvar) return;vymažPôsobisko();zrušCestu();if (null != peroPoloženéDoma)
peroPoložené = peroPoloženéDoma.booleanValue();if (null != viditeľnýDoma)
viditeľný = viditeľnýDoma.booleanValue();
if (viditeľný || (null != viditeľnýDoma))automatickéPrekreslenie();}
public void domov(double novýUholDoma){aktuálneX = domaX;aktuálneY = domaY;novýUholDoma %= 360;
if (novýUholDoma < 0) novýUholDoma += 360;
aktuálnyUhol = uholDoma = novýUholDoma;
if (kreslímVlastnýTvar) return;vymažPôsobisko();zrušCestu();if (null != peroPoloženéDoma)
peroPoložené = peroPoloženéDoma.booleanValue();if (null != viditeľnýDoma)
viditeľný = viditeľnýDoma.booleanValue();
if (viditeľný || (null != viditeľnýDoma))automatickéPrekreslenie();}
public void domov(double novéXDoma, double novéYDoma){aktuálneX = domaX = novéXDoma;aktuálneY = domaY = novéYDoma;aktuálnyUhol = uholDoma;
if (kreslímVlastnýTvar) return;vymažPôsobisko();zrušCestu();if (null != peroPoloženéDoma)
peroPoložené = peroPoloženéDoma.booleanValue();if (null != viditeľnýDoma)
viditeľný = viditeľnýDoma.booleanValue();
if (viditeľný || (null != viditeľnýDoma))automatickéPrekreslenie();}
public void domov(double novéXDoma, double novéYDoma, double novýUholDoma){aktuálneX = domaX = novéXDoma;aktuálneY = domaY = novéYDoma;novýUholDoma %= 360;
if (novýUholDoma < 0) novýUholDoma += 360;
aktuálnyUhol = uholDoma = novýUholDoma;
if (kreslímVlastnýTvar) return;vymažPôsobisko();zrušCestu();if (null != peroPoloženéDoma)
peroPoložené = peroPoloženéDoma.booleanValue();if (null != viditeľnýDoma)
viditeľný = viditeľnýDoma.booleanValue();
if (viditeľný || (null != viditeľnýDoma))automatickéPrekreslenie();}
public void domov(Point2D nováPolohaDoma){
aktuálneX = domaX = nováPolohaDoma.getX();
aktuálneY = domaY = nováPolohaDoma.getY();aktuálnyUhol = uholDoma;
if (kreslímVlastnýTvar) return;vymažPôsobisko();zrušCestu();if (null != peroPoloženéDoma)
peroPoložené = peroPoloženéDoma.booleanValue();if (null != viditeľnýDoma)
viditeľný = viditeľnýDoma.booleanValue();
if (viditeľný || (null != viditeľnýDoma))automatickéPrekreslenie();}
public void domov(Point2D nováPolohaDoma, double novýUholDoma){
aktuálneX = domaX = nováPolohaDoma.getX();
aktuálneY = domaY = nováPolohaDoma.getY();novýUholDoma %= 360;
if (novýUholDoma < 0) novýUholDoma += 360;
aktuálnyUhol = uholDoma = novýUholDoma;
if (kreslímVlastnýTvar) return;vymažPôsobisko();zrušCestu();
if (null != peroPoloženéDoma) peroPoložené = peroPoloženéDoma.booleanValue();
if (null != viditeľnýDoma) viditeľný = viditeľnýDoma.booleanValue();
if (viditeľný || (null != viditeľnýDoma)) automatickéPrekreslenie();}public void domov(GRobot iný){aktuálneX = domaX = iný.domaX;aktuálneY = domaY = iný.domaY;
aktuálnyUhol = uholDoma = iný.uholDoma;
if (kreslímVlastnýTvar) return;vymažPôsobisko();zrušCestu();
peroPoloženéDoma = iný.viditeľnýDoma;
viditeľnýDoma = iný.viditeľnýDoma;
if (null != peroPoloženéDoma) peroPoložené = peroPoloženéDoma.booleanValue();
if (null != viditeľnýDoma) viditeľný = viditeľnýDoma.booleanValue();
if (viditeľný || (null != viditeľnýDoma)) automatickéPrekreslenie();}public void novýDomov(){domaX = aktuálneX;domaY = aktuálneY;uholDoma = aktuálnyUhol;}
public void novyDomov() { novýDomov(); }
public void novýDomov(double novýUholDoma){uholDoma = novýUholDoma;uholDoma %= 360;
if (uholDoma < 0) uholDoma += 360;}
public void novyDomov(double novýUholDoma) { novýDomov(novýUholDoma); }
public void novýDomov(double novéXDoma, double novéYDoma){domaX = novéXDoma;domaY = novéYDoma;}
public void novyDomov(double novéXDoma, double novéYDoma)
{ novýDomov(novéXDoma, novéYDoma); }
public void novýDomov(double novéXDoma, double novéYDoma, double novýUholDoma){domaX = novéXDoma;domaY = novéYDoma;uholDoma = novýUholDoma;uholDoma %= 360;
if (uholDoma < 0) uholDoma += 360;}
public void novyDomov(double novéXDoma, double novéYDoma,double novýUholDoma)
{ novýDomov(novéXDoma, novéYDoma, novýUholDoma); }
public void novýDomov(Point2D nováPolohaDoma){domaX = nováPolohaDoma.getX();domaY = nováPolohaDoma.getY();}
public void novyDomov(Point2D nováPolohaDoma){ novýDomov(nováPolohaDoma); }
public void novýDomov(Point2D nováPolohaDoma, double novýUholDoma){domaX = nováPolohaDoma.getX();domaY = nováPolohaDoma.getY();uholDoma = novýUholDoma;uholDoma %= 360;
if (uholDoma < 0) uholDoma += 360;}
public void novyDomov(Point2D nováPolohaDoma,double novýUholDoma)
{ novýDomov(nováPolohaDoma, novýUholDoma); }
public void novýDomov(GRobot iný){domaX = iný.domaX;domaY = iný.domaY;uholDoma = iný.uholDoma;
peroPoloženéDoma = iný.viditeľnýDoma;
viditeľnýDoma = iný.viditeľnýDoma;}
public void novyDomov(GRobot iný) { novýDomov(iný); }
public double domaX() { return domaX; }
public double domaY() { return domaY; }
public double uholDoma() { return uholDoma; }
public double smerDoma() { return uholDoma; }
public void domaX(double x) { domaX = x; }
public void domaY(double y) { domaY = y; }
public void uholDoma(double uhol) { uholDoma = uhol; }
public void smerDoma(double uhol) { uholDoma = uhol; }
public Boolean polohaPeraDoma() { return peroPoloženéDoma; }
public Boolean peroZdvihnutéDoma(){
if (null == peroPoloženéDoma) return null;
return peroPoloženéDoma.booleanValue() ?Boolean.FALSE : Boolean.TRUE;}
public Boolean peroZdvihnuteDoma()
{ return peroZdvihnutéDoma(); }
public Boolean peroPoloženéDoma() { return peroPoloženéDoma; }
public Boolean peroPolozeneDoma(){ return peroPoloženéDoma(); }
public void polohaPeraDoma(Boolean položené)
{ peroPoloženéDoma = položené; }
public void zdvihniPeroDoma() { peroPoloženéDoma = Boolean.FALSE; }
public void položPeroDoma() { peroPoloženéDoma = Boolean.TRUE; }
public void polozPeroDoma() { peroPoloženéDoma = Boolean.TRUE; }
public void zachovajPeroDoma() { peroPoloženéDoma = null; }
public Boolean viditeľnýDoma() { return viditeľnýDoma; }
public Boolean viditelnyDoma() { return viditeľnýDoma; }
public Boolean zobrazenýDoma() { return viditeľnýDoma; }
public Boolean zobrazenyDoma() { return viditeľnýDoma; }public Boolean skrytýDoma(){
if (null == viditeľnýDoma) return null;
return viditeľnýDoma.booleanValue() ?Boolean.FALSE : Boolean.TRUE;}
public Boolean skrytyDoma() { return skrytýDoma(); }
public void ukážDoma() { viditeľnýDoma = Boolean.TRUE; }
public void ukazDoma() { viditeľnýDoma = Boolean.TRUE; }
public void zobrazDoma() { viditeľnýDoma = Boolean.TRUE; }
public void skryDoma() { viditeľnýDoma = Boolean.FALSE; }
public void zachovajViditeľnosťDoma() { viditeľnýDoma = null; }
public void zachovajViditelnostDoma() { viditeľnýDoma = null; }
public int spôsobKreslenia() { return spôsobKreslenia; }
public int sposobKreslenia() { return spôsobKreslenia; }
public void spôsobKreslenia(int novýSpôsobKreslenia)
{ spôsobKreslenia = novýSpôsobKreslenia; }
public void sposobKreslenia(int novýSpôsobKreslenia)
{ spôsobKreslenia = novýSpôsobKreslenia; }
public void dopredu(double dĺžka){
double novéX = aktuálneX + Math.cos(Math.toRadians(aktuálnyUhol)) * dĺžka;
double novéY = aktuálneY + Math.sin(Math.toRadians(aktuálnyUhol)) * dĺžka;if (peroPoložené){
úsečka(aktuálneX, aktuálneY, novéX, novéY);aktualizujPôsobisko();aktuálneX = novéX;aktuálneY = novéY;aktualizujPôsobisko();}else{aktuálneX = novéX;aktuálneY = novéY;}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(novéX),prepočítajY(novéY));else cesta.moveTo(prepočítajX(novéX),prepočítajY(novéY));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void vpred(double dĺžka) { dopredu(dĺžka); }
public void vzad(double dĺžka) { dopredu(-dĺžka); }
public void dozadu(double dĺžka) { dopredu(-dĺžka); }
public void vpravo(double uhol){aktuálnyUhol -= uhol;aktuálnyUhol %= 360;
if (aktuálnyUhol < 0) aktuálnyUhol += 360;
if (viditeľný) automatickéPrekreslenie();}
public void doprava(double uhol) { vpravo(uhol); }public void vľavo(double uhol){aktuálnyUhol += uhol;aktuálnyUhol %= 360;
if (aktuálnyUhol < 0) aktuálnyUhol += 360;
if (viditeľný) automatickéPrekreslenie();}
public void vlavo(double uhol) { vľavo(uhol); }
public void doľava(double uhol) { vľavo(uhol); }
public void dolava(double uhol) { vľavo(uhol); }public void otočO(double uhol){aktuálnyUhol += uhol;aktuálnyUhol %= 360;
if (aktuálnyUhol < 0) aktuálnyUhol += 360;
if (viditeľný) automatickéPrekreslenie();}
public void otocO(double uhol) { otočO(uhol); }
public void posuňVpravo(double dĺžka){
double novéX = aktuálneX + Math.cos(Math.toRadians(aktuálnyUhol - 90)) * dĺžka;
double novéY = aktuálneY + Math.sin(Math.toRadians(aktuálnyUhol - 90)) * dĺžka;if (peroPoložené){
úsečka(aktuálneX, aktuálneY, novéX, novéY);aktualizujPôsobisko();aktuálneX = novéX;aktuálneY = novéY;aktualizujPôsobisko();}else{aktuálneX = novéX;aktuálneY = novéY;}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(novéX),prepočítajY(novéY));else cesta.moveTo(prepočítajX(novéX),prepočítajY(novéY));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void posunVpravo(double dĺžka) { posuňVpravo(dĺžka); }
public void posuňDoprava(double dĺžka) { posuňVpravo(dĺžka); }
public void posunDoprava(double dĺžka) { posuňVpravo(dĺžka); }
public void posuňVľavo(double dĺžka){
double novéX = aktuálneX + Math.cos(Math.toRadians(aktuálnyUhol + 90)) * dĺžka;
double novéY = aktuálneY + Math.sin(Math.toRadians(aktuálnyUhol + 90)) * dĺžka;if (peroPoložené){
úsečka(aktuálneX, aktuálneY, novéX, novéY);aktualizujPôsobisko();aktuálneX = novéX;aktuálneY = novéY;aktualizujPôsobisko();}else{aktuálneX = novéX;aktuálneY = novéY;}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(novéX),prepočítajY(novéY));else cesta.moveTo(prepočítajX(novéX),prepočítajY(novéY));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void posunVlavo(double dĺžka) { posuňVľavo(dĺžka); }
public void posuňDoľava(double dĺžka) { posuňVľavo(dĺžka); }
public void posunDolava(double dĺžka) { posuňVľavo(dĺžka); }
public void posuňVSmere(double smer, double dĺžka){
double novéX = aktuálneX + Math.cos(Math.toRadians(smer)) * dĺžka;
double novéY = aktuálneY + Math.sin(Math.toRadians(smer)) * dĺžka;if (peroPoložené){
úsečka(aktuálneX, aktuálneY, novéX, novéY);aktualizujPôsobisko();aktuálneX = novéX;aktuálneY = novéY;aktualizujPôsobisko();}else{aktuálneX = novéX;aktuálneY = novéY;}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(novéX),prepočítajY(novéY));else cesta.moveTo(prepočítajX(novéX),prepočítajY(novéY));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void posunVSmere(double smer, double dĺžka){ posuňVSmere(smer, dĺžka); }
public double smerNa(double x, double y){double Δx = x - aktuálneX;double Δy = y - aktuálneY;
if (Δx == 0 && Δy == 0) return 360;
double α = Math.toDegrees(Math.atan2(Δy, Δx));if (α < 0) return 360 + α;return α;}
public double uholNa(double x, double y) { return smerNa(x, y); }
public double smerNa(Point2D bod){
double Δx = bod.getX() - aktuálneX;
double Δy = bod.getY() - aktuálneY;
if (Δx == 0 && Δy == 0) return 360;
double α = Math.toDegrees(Math.atan2(Δy, Δx));if (α < 0) return 360 + α;return α;}
public double uholNa(Point2D bod) { return smerNa(bod); }
public double smerNa(Poloha objekt){
double Δx = objekt.polohaX() - aktuálneX;
double Δy = objekt.polohaY() - aktuálneY;
if (Δx == 0 && Δy == 0) return 360;
double α = Math.toDegrees(Math.atan2(Δy, Δx));if (α < 0) return 360 + α;return α;}
public double uholNa(Poloha objekt) { return smerNa(objekt); }
public double smerNa(Shape tvar){
Rectangle2D hranice = tvar.getBounds2D();
double Δx = (prepočítajSpäťX(hranice.getX()) +
hranice.getWidth() / 2) - aktuálneX;
double Δy = (prepočítajSpäťY(hranice.getY()) -
hranice.getHeight() / 2) - aktuálneY;
if (Δx == 0 && Δy == 0) return 360;
double α = Math.toDegrees(Math.atan2(Δy, Δx));if (α < 0) return 360 + α;return α;}
public double uholNa(Shape tvar) { return smerNa(tvar); }public double smerNaMyš(){
double Δx = súradnicaMyšiX - aktuálneX;
double Δy = súradnicaMyšiY - aktuálneY;
if (Δx == 0 && Δy == 0) return 360;
double α = Math.toDegrees(Math.atan2(Δy, Δx));if (α < 0) return 360 + α;return α;}
public double smerNaMys() { return smerNaMyš(); }
public double uholNaMyš() { return smerNaMyš(); }
public double uholNaMys() { return smerNaMyš(); }
public double smer(double Δx, double Δy){
if (Δx == 0 && Δy == 0) return 360;
double α = Math.toDegrees(Math.atan2(Δy, Δx));if (α < 0) return 360 + α;return α;}
public double uhol(double Δx, double Δy) { return smer(Δx, Δy); }
public void otočNa(double x, double y){double Δx = x - aktuálneX;double Δy = y - aktuálneY;
if (Δx == 0 && Δy == 0) return;else{
aktuálnyUhol = Math.toDegrees(Math.atan2(Δy, Δx));
if (aktuálnyUhol < 0) aktuálnyUhol += 360;}
if (viditeľný) automatickéPrekreslenie();}
public void otocNa(double x, double y) { otočNa(x, y); }
public void otočNa(double x, double y, double najviacO){double α = smerNa(x, y);if (α == 360) return;
if (najviacO < 0) najviacO = -najviacO;α -= aktuálnyUhol;if (α > 180) α -= 360;if (α < -180) α += 360;
if (α > 0 && α > najviacO) α = najviacO;
if (α < 0 && α < -najviacO) α = -najviacO;vľavo(α);}
public void otocNa(double x, double y, double najviacO){ otočNa(x, y, najviacO); }
public void otočNa(Point2D bod){
double Δx = bod.getX() - aktuálneX;
double Δy = bod.getY() - aktuálneY;
if (Δx == 0 && Δy == 0) return;else{
aktuálnyUhol = Math.toDegrees(Math.atan2(Δy, Δx));
if (aktuálnyUhol < 0) aktuálnyUhol += 360;}
if (viditeľný) automatickéPrekreslenie();}
public void otocNa(Point2D bod) { otočNa(bod); }
public void otočNa(Point2D bod, double najviacO){double α = smerNa(bod);if (α == 360) return;
if (najviacO < 0) najviacO = -najviacO;α -= aktuálnyUhol;if (α > 180) α -= 360;if (α < -180) α += 360;
if (α > 0 && α > najviacO) α = najviacO;
if (α < 0 && α < -najviacO) α = -najviacO;vľavo(α);}
public void otocNa(Point2D bod, double najviacO){ otočNa(bod, najviacO); }
public void otočNa(Poloha objekt){
double Δx = objekt.polohaX() - aktuálneX;
double Δy = objekt.polohaY() - aktuálneY;
if (Δx == 0 && Δy == 0) return;else{
aktuálnyUhol = Math.toDegrees(Math.atan2(Δy, Δx));
if (aktuálnyUhol < 0) aktuálnyUhol += 360;}
if (viditeľný) automatickéPrekreslenie();}
public void otocNa(Poloha objekt) { otočNa(objekt); }
public void otočNa(Poloha objekt, double najviacO){double α = smerNa(objekt);if (α == 360) return;
if (najviacO < 0) najviacO = -najviacO;α -= aktuálnyUhol;if (α > 180) α -= 360;if (α < -180) α += 360;
if (α > 0 && α > najviacO) α = najviacO;
if (α < 0 && α < -najviacO) α = -najviacO;vľavo(α);}
public void otocNa(Poloha objekt, double najviacO){ otočNa(objekt, najviacO); }public void otočNa(Shape tvar){
Rectangle2D hranice = tvar.getBounds2D();
double Δx = (prepočítajSpäťX(hranice.getX()) +
hranice.getWidth() / 2) - aktuálneX;
double Δy = (prepočítajSpäťY(hranice.getY()) -
hranice.getHeight() / 2) - aktuálneY;
if (Δx == 0 && Δy == 0) return;else{
aktuálnyUhol = Math.toDegrees(Math.atan2(Δy, Δx));
if (aktuálnyUhol < 0) aktuálnyUhol += 360;}
if (viditeľný) automatickéPrekreslenie();}
public void otocNa(Shape tvar) { otočNa(tvar); }
public void otočNa(Shape tvar, double najviacO){double α = smerNa(tvar);if (α == 360) return;
if (najviacO < 0) najviacO = -najviacO;α -= aktuálnyUhol;if (α > 180) α -= 360;if (α < -180) α += 360;
if (α > 0 && α > najviacO) α = najviacO;
if (α < 0 && α < -najviacO) α = -najviacO;vľavo(α);}
public void otocNa(Shape tvar, double najviacO){ otočNa(tvar, najviacO); }public void otočNaMyš(){
double Δx = súradnicaMyšiX - aktuálneX;
double Δy = súradnicaMyšiY - aktuálneY;
if (Δx == 0 && Δy == 0) return;else{
aktuálnyUhol = Math.toDegrees(Math.atan2(Δy, Δx));
if (aktuálnyUhol < 0) aktuálnyUhol += 360;}
if (viditeľný) automatickéPrekreslenie();}
public void otocNaMys() { otočNaMyš(); }
public void otočNaMyš(double najviacO){double α = smerNaMyš();if (α == 360) return;
if (najviacO < 0) najviacO = -najviacO;α -= aktuálnyUhol;if (α > 180) α -= 360;if (α < -180) α += 360;
if (α > 0 && α > najviacO) α = najviacO;
if (α < 0 && α < -najviacO) α = -najviacO;vľavo(α);}
public void otocNaMys(double najviacO) { otočNaMyš(najviacO); }
public void otoč(double Δx, double Δy){
if (Δx == 0 && Δy == 0) return;else{
aktuálnyUhol = Math.toDegrees(Math.atan2(Δy, Δx));
if (aktuálnyUhol < 0) aktuálnyUhol += 360;}
if (viditeľný) automatickéPrekreslenie();}
public void otoc(double Δx, double Δy) { otoč(Δx, Δy); }
public void otoč(double Δx, double Δy, double najviacO){double α = smer(Δx, Δy);if (α == 360) return;
if (najviacO < 0) najviacO = -najviacO;α -= aktuálnyUhol;if (α > 180) α -= 360;if (α < -180) α += 360;
if (α > 0 && α > najviacO) α = najviacO;
if (α < 0 && α < -najviacO) α = -najviacO;vľavo(α);}
public void otoc(double Δx, double Δy, double najviacO){ otoč(Δx, Δy, najviacO); }public void otoč(Smer objekt){aktuálnyUhol = objekt.smer();
if (viditeľný) automatickéPrekreslenie();}
public void otoc(Smer objekt) { otoč(objekt); }
public void otoč(Smer objekt, double najviacO){double α = objekt.smer();
if (najviacO < 0) najviacO = -najviacO;α -= aktuálnyUhol;if (α > 180) α -= 360;if (α < -180) α += 360;
if (α > 0 && α > najviacO) α = najviacO;
if (α < 0 && α < -najviacO) α = -najviacO;vľavo(α);}
public void otoc(Smer objekt, double najviacO){ otoč(objekt, najviacO); }
public void choďNa(double novéX, double novéY){if (peroPoložené){
úsečka(aktuálneX, aktuálneY, novéX, novéY);aktualizujPôsobisko();aktuálneX = novéX;aktuálneY = novéY;aktualizujPôsobisko();}else{aktuálneX = novéX;aktuálneY = novéY;}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(novéX),prepočítajY(novéY));else cesta.moveTo(prepočítajX(novéX),prepočítajY(novéY));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void chodNa(double novéX, double novéY) { choďNa(novéX, novéY); }
public void choďNa(Point2D nováPoloha){if (peroPoložené){úsečka(aktuálneX, aktuálneY,
nováPoloha.getX(), nováPoloha.getY());aktualizujPôsobisko();aktuálneX = nováPoloha.getX();aktuálneY = nováPoloha.getY();aktualizujPôsobisko();}else{aktuálneX = nováPoloha.getX();aktuálneY = nováPoloha.getY();}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(
prepočítajX(nováPoloha.getX()),
prepočítajY(nováPoloha.getY()));else cesta.moveTo(
prepočítajX(nováPoloha.getX()),
prepočítajY(nováPoloha.getY()));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void chodNa(Point2D nováPoloha) { choďNa(nováPoloha); }
public void choďNa(Poloha objekt){if (peroPoložené){úsečka(aktuálneX, aktuálneY,
objekt.polohaX(), objekt.polohaY());aktualizujPôsobisko();aktuálneX = objekt.polohaX();aktuálneY = objekt.polohaY();aktualizujPôsobisko();}else{aktuálneX = objekt.polohaX();aktuálneY = objekt.polohaY();}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(objekt.polohaX()),
prepočítajY(objekt.polohaY()));else cesta.moveTo(prepočítajX(objekt.polohaX()),
prepočítajY(objekt.polohaY()));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void chodNa(Poloha objekt) { choďNa(objekt); }public void choďNa(Shape tvar){
Rectangle2D hranice = tvar.getBounds2D();
double novéX = prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2;
double novéY = prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2;if (peroPoložené){
úsečka(aktuálneX, aktuálneY, novéX, novéY);aktualizujPôsobisko();aktuálneX = novéX;aktuálneY = novéY;aktualizujPôsobisko();}else{aktuálneX = novéX;aktuálneY = novéY;}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(novéX),prepočítajY(novéY));else cesta.moveTo(prepočítajX(novéX),prepočítajY(novéY));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void chodNa(Shape tvar) { choďNa(tvar); }public void choďNaMyš(){if (peroPoložené){
úsečka(aktuálneX, aktuálneY, súradnicaMyšiX, súradnicaMyšiY);aktualizujPôsobisko();aktuálneX = súradnicaMyšiX;aktuálneY = súradnicaMyšiY;aktualizujPôsobisko();}else{aktuálneX = súradnicaMyšiX;aktuálneY = súradnicaMyšiY;}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(súradnicaMyšiX),prepočítajY(súradnicaMyšiY));else cesta.moveTo(prepočítajX(súradnicaMyšiX),prepočítajY(súradnicaMyšiY));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void chodNaMys() { choďNaMyš(); }
public void choď(double Δx, double Δy){if (peroPoložené){
úsečka(aktuálneX, aktuálneY, aktuálneX + Δx, aktuálneY + Δy);aktualizujPôsobisko();aktuálneX += Δx;aktuálneY += Δy;aktualizujPôsobisko();}else{aktuálneX += Δx;aktuálneY += Δy;}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(aktuálneX),prepočítajY(aktuálneY));else cesta.moveTo(prepočítajX(aktuálneX),prepočítajY(aktuálneY));}
if (viditeľný || peroPoložené) automatickéPrekreslenie();}
public void chod(double Δx, double Δy) { choď(Δx, Δy); }
public void skočNa(double novéX, double novéY){aktuálneX = novéX;aktuálneY = novéY;if (záznamCesty){if (záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(novéX),prepočítajY(novéY));else cesta.moveTo(prepočítajX(novéX),prepočítajY(novéY));}
if (viditeľný) automatickéPrekreslenie();}
public void skocNa(double novéX, double novéY) { skočNa(novéX, novéY); }
public void skočNa(Point2D nováPoloha){aktuálneX = nováPoloha.getX();aktuálneY = nováPoloha.getY();if (záznamCesty){if (záznamCestyBezPolohyPera)cesta.lineTo(
prepočítajX(nováPoloha.getX()),
prepočítajY(nováPoloha.getY()));else cesta.moveTo(
prepočítajX(nováPoloha.getX()),
prepočítajY(nováPoloha.getY()));}
if (viditeľný) automatickéPrekreslenie();}
public void skocNa(Point2D nováPoloha) { skočNa(nováPoloha); }
public void skočNa(Poloha objekt){aktuálneX = objekt.polohaX();aktuálneY = objekt.polohaY();if (záznamCesty){if (záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(objekt.polohaX()),
prepočítajY(objekt.polohaY()));else cesta.moveTo(prepočítajX(objekt.polohaX()),
prepočítajY(objekt.polohaY()));}
if (viditeľný) automatickéPrekreslenie();}
public void skocNa(Poloha objekt) { skočNa(objekt); }public void skočNa(Shape tvar){
Rectangle2D hranice = tvar.getBounds2D();
double novéX = prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2;
double novéY = prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2;aktuálneX = novéX;aktuálneY = novéY;if (záznamCesty){if (záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(novéX),prepočítajY(novéY));else cesta.moveTo(prepočítajX(novéX),prepočítajY(novéY));}
if (viditeľný) automatickéPrekreslenie();}
public void skocNa(Shape tvar) { skočNa(tvar); }public void skočNaMyš(){aktuálneX = súradnicaMyšiX;aktuálneY = súradnicaMyšiY;if (záznamCesty){if (záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(súradnicaMyšiX),prepočítajY(súradnicaMyšiY));else cesta.moveTo(prepočítajX(súradnicaMyšiX),prepočítajY(súradnicaMyšiY));}
if (viditeľný) automatickéPrekreslenie();}
public void skocNaMys() { skočNaMyš(); }
public void skoč(double Δx, double Δy){aktuálneX += Δx;aktuálneY += Δy;if (záznamCesty){if (záznamCestyBezPolohyPera)cesta.lineTo(prepočítajX(aktuálneX),prepočítajY(aktuálneY));else cesta.moveTo(prepočítajX(aktuálneX),prepočítajY(aktuálneY));}
if (viditeľný) automatickéPrekreslenie();}
public void skoc(double Δx, double Δy) { skoč(Δx, Δy); }
public void choďPoOblúku(double uhol, double polomer){
if (0 == uhol || 0 == polomer) return;
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);double priemer;Arc2D.Double oblúk;if (polomer < 0){polomer = -polomer;priemer = 2 * polomer;
prepočítanéX -= polomer * (1 - Math.cos(Math.toRadians(aktuálnyUhol + 90)));
prepočítanéY -= polomer * (1 + Math.sin(Math.toRadians(aktuálnyUhol + 90)));
oblúk = new Arc2D.Double(prepočítanéX, prepočítanéY,
priemer, priemer, aktuálnyUhol + 270, uhol,Arc2D.OPEN);
aktuálneX += Math.cos(Math.toRadians(aktuálnyUhol + 90)) * polomer;
aktuálneY += Math.sin(Math.toRadians(aktuálnyUhol + 90)) * polomer;aktuálnyUhol += uhol;aktuálnyUhol %= 360;
if (aktuálnyUhol < 0) aktuálnyUhol += 360;
aktuálneX += Math.cos(Math.toRadians(aktuálnyUhol - 90)) * polomer;
aktuálneY += Math.sin(Math.toRadians(aktuálnyUhol - 90)) * polomer;}else{priemer = 2 * polomer;
prepočítanéX -= polomer * (1 - Math.cos(Math.toRadians(aktuálnyUhol - 90)));
prepočítanéY -= polomer * (1 + Math.sin(Math.toRadians(aktuálnyUhol - 90)));
oblúk = new Arc2D.Double(prepočítanéX, prepočítanéY,
priemer, priemer, aktuálnyUhol + 90, -uhol,Arc2D.OPEN);
aktuálneX += Math.cos(Math.toRadians(aktuálnyUhol - 90)) * polomer;
aktuálneY += Math.sin(Math.toRadians(aktuálnyUhol - 90)) * polomer;aktuálnyUhol -= uhol;aktuálnyUhol %= 360;
if (aktuálnyUhol < 0) aktuálnyUhol += 360;
aktuálneX += Math.cos(Math.toRadians(aktuálnyUhol + 90)) * polomer;
aktuálneY += Math.sin(Math.toRadians(aktuálnyUhol + 90)) * polomer;}if (záznamCesty){
if (peroPoložené || záznamCestyBezPolohyPera)
cesta.append(oblúk.getPathIterator(null), true);else cesta.moveTo(prepočítajX(aktuálneX),prepočítajY(aktuálneY));}if (peroPoložené){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(oblúk);
aktualizujPôsobisko(oblúk.getBounds2D());automatickéPrekreslenie();}
else if (viditeľný) automatickéPrekreslenie();}
public void chodPoObluku(double uhol, double polomer)
{ choďPoOblúku(uhol, polomer); }
public boolean aktívny() { return aktívny; }
public boolean aktivny() { return aktívny; }
public boolean neaktívny() { return !aktívny; }
public boolean neaktivny() { return !aktívny; }
public void aktivuj() { aktivuj(0, true); }
public void aktivuj(int dobaAktivity) { aktivuj(dobaAktivity, true); }
public void aktivuj(boolean ajČasovač) { aktivuj(0, ajČasovač); }
public void aktivuj(int dobaAktivity, boolean ajČasovač){synchronized (zámokAktivít){aktívny = true;
this.dobaAktivity = dobaAktivity;}if (ajČasovač){svet.spustiČasovač();}aktivácia();aktivacia();}public void deaktivuj(){synchronized (zámokAktivít){aktívny = false;}deaktivácia();deaktivacia();}
public void spusti() { spusti(0, true); }
public void spusti(int dobaAktivity) { spusti(dobaAktivity, true); }
public void spusti(boolean ajČasovač) { spusti(0, ajČasovač); }
public void spusti(int dobaAktivity, boolean ajČasovač){synchronized (zámokAktivít){aktívny = true;
this.dobaAktivity = dobaAktivity;}if (ajČasovač){svet.spustiČasovač();}spustenie();
if (cieľAktívny) overDosiahnutieCieľa();}public void zastav(){synchronized (zámokAktivít){aktívny = false;cieľAktívny = false;
if (zrýchlenie != 0.0) rýchlosť = 0.0;
if (uhlovéZrýchlenie != 0.0) uhlováRýchlosť = 0.0;}zastavenie();}
public double rýchlosť() { return rýchlosť; }
public double rychlost() { return rýchlosť; }
public void rýchlosť(double rýchlosť){ rýchlosť(rýchlosť, true); }
public void rychlost(double rýchlosť){ rýchlosť(rýchlosť, true); }
public void rýchlosť(double rýchlosť, boolean aktivuj){synchronized (zámokAktivít){this.rýchlosť = rýchlosť;if (maximálnaRýchlosť != 0.0){
if (this.rýchlosť > maximálnaRýchlosť)
this.rýchlosť = maximálnaRýchlosť;
else if (this.rýchlosť < -maximálnaRýchlosť)
this.rýchlosť = -maximálnaRýchlosť;}}
if (aktivuj && this.rýchlosť != 0.0) aktivuj();}
public void rychlost(double rýchlosť, boolean aktivuj)
{ rýchlosť(rýchlosť, aktivuj); }
public double maximálnaRýchlosť() { return maximálnaRýchlosť; }
public double maximalnaRychlost() { return maximálnaRýchlosť; }
public void maximálnaRýchlosť(double maximálnaRýchlosť){synchronized (zámokAktivít){if (maximálnaRýchlosť < 0.0)
this.maximálnaRýchlosť = -maximálnaRýchlosť;else
this.maximálnaRýchlosť = maximálnaRýchlosť;
if (this.maximálnaRýchlosť != 0.0){
if (rýchlosť > this.maximálnaRýchlosť)
rýchlosť = this.maximálnaRýchlosť;
else if (rýchlosť < -this.maximálnaRýchlosť)
rýchlosť = -this.maximálnaRýchlosť;}}}
public void maximalnaRychlost(double maximálnaRýchlosť)
{ maximálnaRýchlosť(maximálnaRýchlosť); }
public double uhlováRýchlosť() { return uhlováRýchlosť; }
public double uhlovaRychlost() { return uhlováRýchlosť; }
public double rýchlosťOtáčania() { return uhlováRýchlosť; }
public double rychlostOtacania() { return uhlováRýchlosť; }
public void uhlováRýchlosť(double uhlováRýchlosť)
{ uhlováRýchlosť(uhlováRýchlosť, true); }
public void uhlovaRychlost(double uhlováRýchlosť)
{ uhlováRýchlosť(uhlováRýchlosť, true); }
public void rýchlosťOtáčania(double uhlováRýchlosť)
{ uhlováRýchlosť(uhlováRýchlosť, true); }
public void rychlostOtacania(double uhlováRýchlosť)
{ uhlováRýchlosť(uhlováRýchlosť, true); }
public void uhlováRýchlosť(double uhlováRýchlosť,boolean aktivuj){synchronized (zámokAktivít){
this.uhlováRýchlosť = uhlováRýchlosť;
if (maximálnaUhlováRýchlosť != 0.0){if (this.uhlováRýchlosť >maximálnaUhlováRýchlosť)this.uhlováRýchlosť =maximálnaUhlováRýchlosť;else if (this.uhlováRýchlosť <-maximálnaUhlováRýchlosť)this.uhlováRýchlosť =-maximálnaUhlováRýchlosť;}}
if (aktivuj && this.uhlováRýchlosť != 0.0) aktivuj();}
public void uhlovaRychlost(double uhlováRýchlosť, boolean aktivuj)
{ uhlováRýchlosť(uhlováRýchlosť, aktivuj); }
public void rýchlosťOtáčania(double uhlováRýchlosť, boolean aktivuj)
{ uhlováRýchlosť(uhlováRýchlosť, aktivuj); }
public void rychlostOtacania(double uhlováRýchlosť, boolean aktivuj)
{ uhlováRýchlosť(uhlováRýchlosť, aktivuj); }
public double maximálnaUhlováRýchlosť() { return maximálnaUhlováRýchlosť; }
public double maximalnaUhlovaRychlost() { return maximálnaUhlováRýchlosť; }
public double maximálnaRýchlosťOtáčania() { return maximálnaUhlováRýchlosť; }
public double maximalnaRychlostOtacania() { return maximálnaUhlováRýchlosť; }
public void maximálnaUhlováRýchlosť(
double maximálnaUhlováRýchlosť){synchronized (zámokAktivít){
if (maximálnaUhlováRýchlosť < 0.0)this.maximálnaUhlováRýchlosť =-maximálnaUhlováRýchlosť;else this.maximálnaUhlováRýchlosť =maximálnaUhlováRýchlosť;
if (this.maximálnaUhlováRýchlosť != 0.0){if (uhlováRýchlosť >this.maximálnaUhlováRýchlosť)uhlováRýchlosť =this.maximálnaUhlováRýchlosť;else if (uhlováRýchlosť <-this.maximálnaUhlováRýchlosť)uhlováRýchlosť =-this.maximálnaUhlováRýchlosť;}}}
public void maximalnaUhlovaRychlost(double maximálnaUhlováRýchlosť)
{ maximálnaUhlováRýchlosť(maximálnaUhlováRýchlosť); }
public void maximálnaRýchlosťOtáčania(double maximálnaUhlováRýchlosť)
{ maximálnaUhlováRýchlosť(maximálnaUhlováRýchlosť); }
public void maximalnaRychlostOtacania(double maximálnaUhlováRýchlosť)
{ maximálnaUhlováRýchlosť(maximálnaUhlováRýchlosť); }
public double zrýchlenie() { return zrýchlenie; }
public double zrychlenie() { return zrýchlenie; }
public void zrýchlenie(double zrýchlenie)
{ zrýchlenie(zrýchlenie, true); }
public void zrychlenie(double zrýchlenie)
{ zrýchlenie(zrýchlenie, true); }
public void zrýchlenie(double zrýchlenie, boolean aktivuj){synchronized (zámokAktivít){this.zrýchlenie = zrýchlenie;}
if (aktivuj && zrýchlenie != 0.0) aktivuj();}
public void zrychlenie(double zrýchlenie, boolean aktivuj)
{ zrýchlenie(zrýchlenie, aktivuj); }
public double uhlovéZrýchlenie() { return uhlovéZrýchlenie; }
public double uhloveZrychlenie() { return uhlovéZrýchlenie; }
public double zrýchlenieOtáčania() { return uhlovéZrýchlenie; }
public double zrychlenieOtacania() { return uhlovéZrýchlenie; }
public void uhlovéZrýchlenie(double uhlovéZrýchlenie)
{ uhlovéZrýchlenie(uhlovéZrýchlenie, true); }
public void uhloveZrychlenie(double uhlovéZrýchlenie)
{ uhlovéZrýchlenie(uhlovéZrýchlenie, true); }
public void zrýchlenieOtáčania(double uhlovéZrýchlenie)
{ uhlovéZrýchlenie(uhlovéZrýchlenie, true); }
public void zrychlenieOtacania(double uhlovéZrýchlenie)
{ uhlovéZrýchlenie(uhlovéZrýchlenie, true); }
public void uhlovéZrýchlenie(double uhlovéZrýchlenie, boolean aktivuj){synchronized (zámokAktivít){
this.uhlovéZrýchlenie = uhlovéZrýchlenie;}
if (aktivuj && uhlovéZrýchlenie != 0.0) aktivuj();}
public void uhloveZrychlenie(double uhlovéZrýchlenie, boolean aktivuj)
{ uhlovéZrýchlenie(uhlovéZrýchlenie, aktivuj); }
public void zrýchlenieOtáčania(double uhlovéZrýchlenie, boolean aktivuj)
{ uhlovéZrýchlenie(uhlovéZrýchlenie, aktivuj); }
public void zrychlenieOtacania(double uhlovéZrýchlenie, boolean aktivuj)
{ uhlovéZrýchlenie(uhlovéZrýchlenie, aktivuj); }public void rozbehniSa(){if (zrýchlenie != 0.0){if (zrýchlenie < 0.0)zrýchlenie = -zrýchlenie;aktivuj();}}public void začniCúvať(){if (zrýchlenie != 0.0){if (zrýchlenie > 0.0)zrýchlenie = -zrýchlenie;aktivuj();}}
public void zacniCuvat() { začniCúvať(); }
public void rozbehniSa(double zrýchlenie){zrýchlenie(zrýchlenie);}
public void rozbehniSa(double zrýchlenie, double maximálnaRýchlosť){zrýchlenie(zrýchlenie);
maximálnaRýchlosť(maximálnaRýchlosť);}
public void rozbehniSa(double zrýchlenie, boolean aktivuj){
zrýchlenie(zrýchlenie, aktivuj);}
public void rozbehniSa(double zrýchlenie, double maximálnaRýchlosť, boolean aktivuj){
zrýchlenie(zrýchlenie, aktivuj);
maximálnaRýchlosť(maximálnaRýchlosť);}public void zabrzdi(){
if (!aktívny || zrýchlenie == 0.0) return;if (rýchlosť == 0.0){synchronized (zámokAktivít){zastavPoSpomalení = false;}zastav();return;}synchronized (zámokAktivít){zastavPoSpomalení = true;
if (rýchlosť > 0.0 && zrýchlenie > 0.0)zrýchlenie = -zrýchlenie;
else if (rýchlosť < 0.0 && zrýchlenie < 0.0)zrýchlenie = -zrýchlenie;}}
public void zabrzdi(double zrýchlenie){
if (!aktívny || zrýchlenie == 0.0) return;if (rýchlosť == 0.0){synchronized (zámokAktivít){zastavPoSpomalení = false;}zastav();return;}synchronized (zámokAktivít){zastavPoSpomalení = true;
if (rýchlosť > 0.0 && zrýchlenie > 0.0)zrýchlenie = -zrýchlenie;
else if (rýchlosť < 0.0 && zrýchlenie < 0.0)zrýchlenie = -zrýchlenie;this.zrýchlenie = zrýchlenie;}}
public boolean zastavíPoSpomalení() { return zastavPoSpomalení; }
public boolean zastaviPoSpomaleni() { return zastavPoSpomalení; }
public void zastavPoSpomalení(){synchronized (zámokAktivít){zastavPoSpomalení = true;}}
public void zastavPoSpomaleni() { zastavPoSpomalení(); }
public boolean cieľAktívny() { return cieľAktívny; }
public boolean cielAktivny() { return cieľAktívny; }
public boolean smerujeDoCieľa() { return cieľAktívny; }
public boolean smerujeDoCiela() { return cieľAktívny; }
public double cieľX() { return cieľX; }
public double cielX() { return cieľX; }
public double cieľY() { return cieľY; }
public double cielY() { return cieľY; }
public boolean zastavíVCieli() { return zastavVCieli; }
public boolean zastaviVCieli() { return zastavVCieli; }public void zrušCieľ(){synchronized (zámokAktivít){cieľAktívny = false;zastavVCieli = false;}zastav();}
public void zrusCiel() { zrušCieľ(); }
public void zrušSledovanieCieľa() { zrušCieľ(); }
public void zrusSledovanieCiela() { zrušCieľ(); }
public void zrušCieľ(boolean zastav){synchronized (zámokAktivít){cieľAktívny = false;zastavVCieli = false;}if (zastav) zastav();}
public void zrusCiel(boolean zastav) { zrušCieľ(zastav); }
public void zrušSledovanieCieľa(boolean zastav) { zrušCieľ(zastav); }
public void zrusSledovanieCiela(boolean zastav) { zrušCieľ(zastav); }
private boolean overDosiahnutieCieľa(){
if (Math.hypot(cieľX - aktuálneX,
cieľY - aktuálneY) <= rýchlosť){
if (maximálnaUhlováRýchlosť != 0.0){
double β = smerNa(cieľX, cieľY);
if (Math.abs(aktuálnyUhol - β) <= 0.05 ||
Math.abs(360 + aktuálnyUhol - β) <=0.05) aktuálnyUhol = β;else return true;}choďNa(cieľX, cieľY);cieľAktívny = false;if (zastavVCieli){if (zrýchlenie != 0){if ((rýchlosť > 0.0 &&zrýchlenie < 0.0) ||rýchlosť < 0.0){zrýchlenie = -zrýchlenie;}rýchlosť = 0.0;}zastav();}dosiahnutieCieľa();dosiahnutieCiela();return false;}return true;}
public void cieľ(double x, double y){synchronized (zámokAktivít){cieľAktívny = true;cieľX = x;cieľY = y;zastavVCieli = true;}spusti();}
public void ciel(double x, double y) { cieľ(x, y); }
public void cieľ(double x, double y, boolean spusti){synchronized (zámokAktivít){cieľAktívny = true;cieľX = x;cieľY = y;zastavVCieli = spusti;}if (spusti){spusti();}}
public void ciel(double x, double y, boolean spusti) { cieľ(x, y, spusti); }
public void cieľ(double x, double y, boolean spusti, boolean zastavVCieli){synchronized (zámokAktivít){cieľAktívny = true;cieľX = x;cieľY = y;
this.zastavVCieli = zastavVCieli;}if (spusti){spusti();}}
public void ciel(double x, double y, boolean spusti, boolean zastavVCieli)
{ cieľ(x, y, spusti, zastavVCieli); }public void cieľ(Point2D bod){synchronized (zámokAktivít){cieľAktívny = true;cieľX = bod.getX();cieľY = bod.getY();zastavVCieli = true;}spusti();}
public void ciel(Point2D bod) { cieľ(bod); }
public void cieľ(Point2D bod, boolean spusti){synchronized (zámokAktivít){cieľAktívny = true;cieľX = bod.getX();cieľY = bod.getY();zastavVCieli = spusti;}if (spusti){spusti();}}
public void ciel(Point2D bod, boolean spusti) { cieľ(bod, spusti); }
public void cieľ(Point2D bod, boolean spusti, boolean zastavVCieli){synchronized (zámokAktivít){cieľAktívny = true;cieľX = bod.getX();cieľY = bod.getY();
this.zastavVCieli = zastavVCieli;}if (spusti){spusti();}}
public void ciel(Point2D bod, boolean spusti, boolean zastavVCieli)
{ cieľ(bod, spusti, zastavVCieli); }
public void cieľ(Poloha objekt){if (null == objekt){zrušCieľ();return;}synchronized (zámokAktivít){cieľAktívny = true;cieľX = objekt.polohaX();cieľY = objekt.polohaY();zastavVCieli = true;}spusti();}
public void ciel(Poloha objekt) { cieľ(objekt); }
public void cieľ(Poloha objekt, boolean spusti){if (null == objekt){zrušCieľ();return;}synchronized (zámokAktivít){cieľAktívny = true;cieľX = objekt.polohaX();cieľY = objekt.polohaY();zastavVCieli = spusti;}if (spusti){spusti();}}
public void ciel(Poloha objekt, boolean spusti) { cieľ(objekt, spusti); }
public void cieľ(Poloha objekt, boolean spusti, boolean zastavVCieli){if (null == objekt){zrušCieľ();return;}synchronized (zámokAktivít){cieľAktívny = true;cieľX = objekt.polohaX();cieľY = objekt.polohaY();
this.zastavVCieli = zastavVCieli;}if (spusti){spusti();}}
public void ciel(Poloha objekt, boolean spusti, boolean zastavVCieli)
{ cieľ(objekt, spusti, zastavVCieli); }public void cieľ(Shape tvar){if (null == tvar){zrušCieľ();return;}synchronized (zámokAktivít){
Rectangle2D hranice = tvar.getBounds2D();cieľAktívny = true;
cieľX = prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2;
cieľY = prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2;zastavVCieli = true;}spusti();}
public void ciel(Shape tvar) { cieľ(tvar); }
public void cieľ(Shape tvar, boolean spusti){if (null == tvar){zrušCieľ();return;}synchronized (zámokAktivít){
Rectangle2D hranice = tvar.getBounds2D();cieľAktívny = true;
cieľX = prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2;
cieľY = prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2;zastavVCieli = spusti;}if (spusti){spusti();}}
public void ciel(Shape tvar, boolean spusti) { cieľ(tvar, spusti); }
public void cieľ(Shape tvar, boolean spusti, boolean zastavVCieli){if (null == tvar){zrušCieľ();return;}synchronized (zámokAktivít){
Rectangle2D hranice = tvar.getBounds2D();cieľAktívny = true;
cieľX = prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2;
cieľY = prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2;
this.zastavVCieli = zastavVCieli;}if (spusti){spusti();}}
public void ciel(Shape tvar, boolean spusti, boolean zastavVCieli)
{ cieľ(tvar, spusti, zastavVCieli); }public void cieľNaMyš(){synchronized (zámokAktivít){cieľAktívny = true;cieľX = súradnicaMyšiX;cieľY = súradnicaMyšiY;zastavVCieli = true;}spusti();}
public void cielNaMys() { cieľNaMyš(); }
public void cieľNaMyš(boolean spusti){synchronized (zámokAktivít){cieľAktívny = true;cieľX = súradnicaMyšiX;cieľY = súradnicaMyšiY;zastavVCieli = spusti;}if (spusti){spusti();}}
public void cielNaMys(boolean spusti) { cieľNaMyš(spusti); }
public void cieľNaMyš(boolean spusti, boolean zastavVCieli){synchronized (zámokAktivít){cieľAktívny = true;cieľX = súradnicaMyšiX;cieľY = súradnicaMyšiY;
this.zastavVCieli = zastavVCieli;}if (spusti){spusti();}}
public void cielNaMys(boolean spusti, boolean zastavVCieli)
{ cieľNaMyš(spusti, zastavVCieli); }
public void upravCieľ(double x, double y){if (cieľAktívny){synchronized (zámokAktivít){cieľX = x;cieľY = y;}overDosiahnutieCieľa();}else cieľ(x, y);}
public void upravCiel(double x, double y) { upravCieľ(x, y); }
public void upravCieľ(double x, double y, boolean spusti){if (cieľAktívny){synchronized (zámokAktivít){cieľX = x;cieľY = y;}overDosiahnutieCieľa();}else cieľ(x, y, spusti);}
public void upravCiel(double x, double y, boolean spusti){ upravCieľ(x, y, spusti); }
public void upravCieľ(Point2D bod){if (cieľAktívny){synchronized (zámokAktivít){cieľX = bod.getX();cieľY = bod.getY();}overDosiahnutieCieľa();}else cieľ(bod);}
public void upravCiel(Point2D bod) { upravCieľ(bod); }
public void upravCieľ(Point2D bod, boolean spusti){if (cieľAktívny){synchronized (zámokAktivít){cieľX = bod.getX();cieľY = bod.getY();}overDosiahnutieCieľa();}else cieľ(bod, spusti);}
public void upravCiel(Point2D bod, boolean spusti){ upravCieľ(bod, spusti); }
public void upravCieľ(Poloha objekt){
if (null != objekt && cieľAktívny){synchronized (zámokAktivít){cieľX = objekt.polohaX();cieľY = objekt.polohaY();}overDosiahnutieCieľa();}else cieľ(objekt);}
public void upravCiel(Poloha objekt) { upravCieľ(objekt); }
public void upravCieľ(Poloha objekt, boolean spusti){
if (null != objekt && cieľAktívny){synchronized (zámokAktivít){cieľX = objekt.polohaX();cieľY = objekt.polohaY();}overDosiahnutieCieľa();}else cieľ(objekt, spusti);}
public void upravCiel(Poloha objekt, boolean spusti){ upravCieľ(objekt, spusti); }
public void upravCieľ(Shape tvar){
if (null != tvar && cieľAktívny){synchronized (zámokAktivít){
Rectangle2D hranice = tvar.getBounds2D();
cieľX = prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2;
cieľY = prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2;}overDosiahnutieCieľa();}else cieľ(tvar);}
public void upravCiel(Shape tvar) { upravCieľ(tvar); }
public void upravCieľ(Shape tvar, boolean spusti){
if (null != tvar && cieľAktívny){synchronized (zámokAktivít){
Rectangle2D hranice = tvar.getBounds2D();
cieľX = prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2;
cieľY = prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2;}overDosiahnutieCieľa();}else cieľ(tvar, spusti);}
public void upravCiel(Shape tvar, boolean spusti){ upravCieľ(tvar, spusti); }public void upravCieľNaMyš(){if (cieľAktívny){synchronized (zámokAktivít){cieľX = súradnicaMyšiX;cieľY = súradnicaMyšiY;}overDosiahnutieCieľa();}else cieľNaMyš();}
public void upravCielNaMys() { upravCieľNaMyš(); }
public void upravCieľNaMyš(boolean spusti){if (cieľAktívny){synchronized (zámokAktivít){cieľX = súradnicaMyšiX;cieľY = súradnicaMyšiY;}overDosiahnutieCieľa();}else cieľNaMyš(spusti);}
public void upravCielNaMys(boolean spusti) { upravCieľNaMyš(spusti); }public void pracuj(){synchronized (zámokAktivít){if (aktívny){aspoňJedenAktívny = true;
if (dobaAktivity > 0 && --dobaAktivity == 0){deaktivuj();}if (cieľAktívny){
uhlováRýchlosť += uhlovéZrýchlenie;
if (maximálnaUhlováRýchlosť != 0.0){if (uhlováRýchlosť >maximálnaUhlováRýchlosť){uhlováRýchlosť =maximálnaUhlováRýchlosť;}else if (uhlováRýchlosť <-maximálnaUhlováRýchlosť){uhlováRýchlosť =-maximálnaUhlováRýchlosť;}}if (uhlováRýchlosť != 0.0){
otočNa(cieľX, cieľY, uhlováRýchlosť);}else{if (uhlovéZrýchlenie == 0.0){otočNa(cieľX, cieľY);}}if (zrýchlenie != 0.0){rýchlosť += zrýchlenie;if (maximálnaRýchlosť != 0.0){
if (rýchlosť > maximálnaRýchlosť)rýchlosť = maximálnaRýchlosť;
else if (rýchlosť < -maximálnaRýchlosť)rýchlosť = -maximálnaRýchlosť;}
if ((rýchlosť > 0.0 && zrýchlenie > 0.0) ||
(rýchlosť < 0.0 && zrýchlenie < 0.0)){double brzdnáDráha =(rýchlosť * rýchlosť) /(2 * zrýchlenie);
if (Math.hypot(cieľX - aktuálneX,
cieľY - aktuálneY) < brzdnáDráha){zrýchlenie = -zrýchlenie;}}}overDosiahnutieCieľa();if (cieľAktívny){dopredu(rýchlosť);if (zrýchlenie != 0.0){if (zastavPoSpomalení){if (zrýchlenie > 0.0){if (rýchlosť >= 0.0){rýchlosť = 0.0;zastavPoSpomalení = false;zastav();}}else{if (rýchlosť <= 0.0){rýchlosť = 0.0;zastavPoSpomalení = false;zastav();}}}else if (zrýchlenie < 0.0 &&rýchlosť <= 0.0)zrýchlenie = -zrýchlenie;}}}
else if (rýchlosť != 0.0 || uhlováRýchlosť != 0.0
|| zrýchlenie != 0.0 || uhlovéZrýchlenie !=0.0){rýchlosť += zrýchlenie;if (maximálnaRýchlosť != 0.0){
if (rýchlosť > maximálnaRýchlosť)rýchlosť = maximálnaRýchlosť;
else if (rýchlosť < -maximálnaRýchlosť)rýchlosť = -maximálnaRýchlosť;}
uhlováRýchlosť += uhlovéZrýchlenie;
if (maximálnaUhlováRýchlosť != 0.0){if (uhlováRýchlosť >maximálnaUhlováRýchlosť){uhlováRýchlosť =maximálnaUhlováRýchlosť;}else if (uhlováRýchlosť <-maximálnaUhlováRýchlosť){uhlováRýchlosť =-maximálnaUhlováRýchlosť;}}dopredu(rýchlosť);doľava(uhlováRýchlosť);
if (zastavPoSpomalení && zrýchlenie != 0.0){if (zrýchlenie > 0.0){if (rýchlosť >= 0.0){rýchlosť = 0.0;zastavPoSpomalení = false;zastav();}}else{if (rýchlosť <= 0.0){rýchlosť = 0.0;zastavPoSpomalení = false;zastav();}}}}aktivita();}else{pasivita();}}}public void vyzviRobotov(){if (zámokZoznamuRobotov2){
System.err.println("Zdvojená " +"výzva bola zamietnutá!");}else{zámokZoznamuRobotov2 = true;boolean reštart;do {zoznamZmenený2 = false;reštart = false;
for (GRobot tento : zoznamRobotov){tento.prijatieVýzvy(this, -1);tento.prijatieVyzvy(this, -1);if (zoznamZmenený2){reštart = true;break;}}} while (reštart);zámokZoznamuRobotov2 = false;zlúčiťZoznamy();}}
public void vyzviRobotov(int kľúč){if (zámokZoznamuRobotov2){
System.err.println("Zdvojená " +"výzva bola zamietnutá!");}else{zámokZoznamuRobotov2 = true;boolean reštart;do {zoznamZmenený2 = false;reštart = false;
for (GRobot tento : zoznamRobotov){
tento.prijatieVýzvy(this, kľúč);
tento.prijatieVyzvy(this, kľúč);if (zoznamZmenený2){reštart = true;break;}}} while (reštart);zámokZoznamuRobotov2 = false;zlúčiťZoznamy();}}
public void vyzviRobotov(int kľúč, boolean obrátene){if (zámokZoznamuRobotov2){
System.err.println("Zdvojená " +"výzva bola zamietnutá!");}else{zámokZoznamuRobotov2 = true;if (obrátene){boolean reštart;do {zoznamZmenený2 = false;reštart = false;
for (int i = zoznamRobotov.size() - 1;i >= 0; --i){
GRobot tento = zoznamRobotov.get(i);
tento.prijatieVýzvy(this, kľúč);
tento.prijatieVyzvy(this, kľúč);if (zoznamZmenený2){reštart = true;break;}}} while (reštart);}else{boolean reštart;do {zoznamZmenený2 = false;reštart = false;
for (GRobot tento : zoznamRobotov){
tento.prijatieVýzvy(this, kľúč);
tento.prijatieVyzvy(this, kľúč);if (zoznamZmenený2){reštart = true;break;}}} while (reštart);}zámokZoznamuRobotov2 = false;zlúčiťZoznamy();}}public void aktivita() {}public void pasivita() {}public void aktivácia() {}public void aktivacia() {}public void deaktivácia() {}public void deaktivacia() {}public void spustenie() {}public void zastavenie() {}
public void dosiahnutieCieľa() {}
public void dosiahnutieCiela() {}
public void prijatieVýzvy(GRobot autor, int kľúč) {}
public void prijatieVyzvy(GRobot autor, int kľúč) {}public void kresliPôsobisko(){kresliPôsobisko = true;automatickéPrekreslenie();}
public void kresliPosobisko() { kresliPôsobisko(); }
public void nekresliPôsobisko(){kresliPôsobisko = false;automatickéPrekreslenie();}
public void nekresliPosobisko() { nekresliPôsobisko(); }
public boolean bodVPôsobisku(double súradnicaBoduX, double súradnicaBoduY){
return ((súradnicaBoduX >= minimálneX) && (súradnicaBoduX <= maximálneX) &&
(súradnicaBoduY >= minimálneY) && (súradnicaBoduY <= maximálneY));}
public boolean bodVPosobisku(double súradnicaBoduX, double súradnicaBoduY)
{ return bodVPôsobisku(súradnicaBoduX, súradnicaBoduY); }
public boolean bodVPôsobisku(Point2D bod){
return ((bod.getX() >= minimálneX) && (bod.getX() <= maximálneX) &&
(bod.getY() >= minimálneY) && (bod.getY() <= maximálneY));}
public boolean bodVPosobisku(Point2D bod){ return bodVPôsobisku(bod); }
public boolean bodVPôsobisku(Poloha objekt){
return ((objekt.polohaX() >= minimálneX) &&
(objekt.polohaX() <= maximálneX) &&
(objekt.polohaY() >= minimálneY) &&
(objekt.polohaY() <= maximálneY));}
public boolean bodVPosobisku(Poloha objekt) { return bodVPôsobisku(objekt); }public boolean myšVPôsobisku(){
return ((súradnicaMyšiX >= minimálneX) &&
(súradnicaMyšiX <= maximálneX) &&
(súradnicaMyšiY >= minimálneY) &&
(súradnicaMyšiY <= maximálneY));}
public boolean mysVPosobisku() { return myšVPôsobisku(); }public Farba farbaBodu(){if (null == aktívnePlátno){
if (obrázokAktívnehoPlátna instanceof Obrázok)
return ((Obrázok)obrázokAktívnehoPlátna).
farbaBodu((int)aktuálneX, (int)aktuálneY);return čierna;}
int x = (int)prepočítajX(aktuálneX);
int y = (int)prepočítajY(aktuálneY);
if (x < 0 || x >= šírkaPlátna ||
y < 0 || y >= výškaPlátna) return čierna;
return new Farba(obrázokAktívnehoPlátna.getRGB(x, y), true);}
public boolean farbaBodu(Color farba){if (null == aktívnePlátno){
if (obrázokAktívnehoPlátna instanceof Obrázok)
return ((Obrázok)obrázokAktívnehoPlátna).
farbaBodu((int)aktuálneX, (int)aktuálneY, farba);return false;}
int x = (int)prepočítajX(aktuálneX);
int y = (int)prepočítajY(aktuálneY);
if (x < 0 || x >= šírkaPlátna ||
y < 0 || y >= výškaPlátna) return false;
return (farba.getRGB() & 0xffffffff) ==
(obrázokAktívnehoPlátna.getRGB(x, y) & 0xffffffff);}
public boolean farbaBodu(Farebnosť objekt){
return farbaBodu(objekt.farba());}public Farba farbaNaMyši(){if (null == aktívnePlátno){
if (obrázokAktívnehoPlátna instanceof Obrázok)
return ((Obrázok)obrázokAktívnehoPlátna).
farbaBodu((int)súradnicaMyšiX, (int)súradnicaMyšiY);return čierna;}
int x = (int)prepočítajX(súradnicaMyšiX);
int y = (int)prepočítajY(súradnicaMyšiY);
if (x < 0 || x >= šírkaPlátna ||
y < 0 || y >= výškaPlátna) return čierna;
return new Farba(obrázokAktívnehoPlátna.getRGB(x, y), true);}
public Farba farbaNaMysi() { return farbaNaMyši(); }
public boolean farbaNaMyši(Color farba){if (null == aktívnePlátno){
if (obrázokAktívnehoPlátna instanceof Obrázok)
return ((Obrázok)obrázokAktívnehoPlátna).
farbaBodu((int)súradnicaMyšiX, (int)súradnicaMyšiY, farba);return false;}
int x = (int)prepočítajX(súradnicaMyšiX);
int y = (int)prepočítajY(súradnicaMyšiY);
if (x < 0 || x >= šírkaPlátna ||
y < 0 || y >= výškaPlátna) return false;
return (farba.getRGB() & 0xffffffff) ==
(obrázokAktívnehoPlátna.getRGB(x, y) & 0xffffffff);}
public boolean farbaNaMysi(Color farba) { return farbaNaMyši(farba); }
public boolean farbaNaMyši(Farebnosť objekt)
{ return farbaNaMyši(objekt.farba()); }
public boolean farbaNaMysi(Farebnosť objekt) { return farbaNaMyši(objekt); }public void vylejFarbu(){
VykonajVObrázku.vylejFarbu(obrázokAktívnehoPlátna,
aktuálneX, aktuálneY, farbaPera);if (právePrekresľujem) return;automatickéPrekreslenie();}public void kresliNaPodlahu(){aktívnePlátno = podlaha;obrázokAktívnehoPlátna =
podlaha.vyrovnávaciaPamäťObrázkaPlátna;grafikaAktívnehoPlátna =
podlaha.vyrovnávaciaPamäťGrafikyPlátna;}public void kresliNaStrop(){aktívnePlátno = strop;
obrázokAktívnehoPlátna = strop.vyrovnávaciaPamäťObrázkaPlátna;
grafikaAktívnehoPlátna = strop.vyrovnávaciaPamäťGrafikyPlátna;}
public boolean kreslímNaPodlahu()
{ return aktívnePlátno == podlaha; }
public boolean kreslimNaPodlahu()
{ return aktívnePlátno == podlaha; }
public boolean kreslímNaStrop() { return aktívnePlátno == strop; }
public boolean kreslimNaStrop() { return aktívnePlátno == strop; }public void vyplň(){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fillRect(0, 0,
obrázokAktívnehoPlátna.getWidth(),
obrázokAktívnehoPlátna.getHeight());automatickéPrekreslenie();}
public void vypln() { vyplň(); }
public void kresliNaObrázok(Obrázok obrázok){aktívnePlátno = null;
obrázokAktívnehoPlátna = obrázok;
grafikaAktívnehoPlátna = obrázok.grafika;}
public void kresliNaObrazok(Obrázok obrázok){ kresliNaObrázok(obrázok); }
public void kresliDoObrázka(Obrázok obrázok){ kresliNaObrázok(obrázok); }
public void kresliDoObrazka(Obrázok obrázok){ kresliNaObrázok(obrázok); }
public boolean kreslímNaObrázok(Obrázok obrázok){
return (obrázokAktívnehoPlátna instanceof Obrázok) &&
(obrázokAktívnehoPlátna == obrázok);}
public boolean kreslimNaObrazok(Obrázok obrázok)
{ return kreslímNaObrázok(obrázok); }
public boolean kreslímDoObrázka(Obrázok obrázok)
{ return kreslímNaObrázok(obrázok); }
public boolean kreslimDoObrazka(Obrázok obrázok)
{ return kreslímNaObrázok(obrázok); }public void bod(){
grafikaAktívnehoPlátna.setColor(farbaPera);aktualizujPôsobisko();if (polomerPera < 2)
grafikaAktívnehoPlátna.fillRect((int)prepočítajX(aktuálneX),
(int)prepočítajY(aktuálneY), 1, 1);else
grafikaAktívnehoPlátna.fill(new Ellipse2D.Double(
prepočítajX(aktuálneX) - (polomerPera / 2),
prepočítajY(aktuálneY) - (polomerPera / 2),polomerPera, polomerPera));automatickéPrekreslenie();}public void prepíšBod(){
obrázokAktívnehoPlátna.setRGB((int)prepočítajX(aktuálneX),
(int)prepočítajY(aktuálneY), farbaPera.getRGB());automatickéPrekreslenie();}
public void prepisBod() { prepíšBod(); }
public Shape kružnica(double polomer){
if (polomer < 0) throw new RuntimeException("Polomer kružnice nesmie byť záporný!");
Shape kružnica = new Ellipse2D.Double(
prepočítajX(aktuálneX) - polomer,
prepočítajY(aktuálneY) - polomer,2 * polomer, 2 * polomer);if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(kružnica);aktualizujPôsobisko(polomer);automatickéPrekreslenie();}return kružnica;}
public Shape kruznica(double polomer) { return kružnica(polomer); }
public Shape kružnicu(double polomer) { return kružnica(polomer); }
public Shape kruznicu(double polomer) { return kružnica(polomer); }
public Shape kružnice(double polomer) { return kružnica(polomer); }
public Shape kruznice(double polomer) { return kružnica(polomer); }
public Shape kruh(double polomer){
if (polomer < 0) throw new RuntimeException("Polomer kruhu nesmie byť záporný!");
Shape kruh = new Ellipse2D.Double(
prepočítajX(aktuálneX) - polomer,
prepočítajY(aktuálneY) - polomer,2 * polomer, 2 * polomer);if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(kruh);aktualizujPôsobisko(polomer);automatickéPrekreslenie();}return kruh;}
public Shape kruhu(double polomer) { return kruh(polomer); }
public Shape elipsa(double a, double b){
if (a < 0 || b < 0) throw new RuntimeException("Dĺžka poloosy elipsy nesmie byť záporná!");
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape elipsa;
if (90 == aktuálnyUhol || 270 == aktuálnyUhol){
elipsa = new Ellipse2D.Double(prepočítanéX - a,
prepočítanéY - b, 2 * a, 2 * b);}
else if (0 == aktuálnyUhol || 180 == aktuálnyUhol){
elipsa = new Ellipse2D.Double(prepočítanéX - b,
prepočítanéY - a, 2 * b, 2 * a);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
elipsa = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Ellipse2D.Double(prepočítanéX - a,
prepočítanéY - b, 2 * a, 2 * b));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(elipsa);
aktualizujPôsobisko(elipsa.getBounds2D());automatickéPrekreslenie();}return elipsa;}
public Shape elipsu(double a, double b) { return elipsa(a, b); }
public Shape elipsy(double a, double b) { return elipsa(a, b); }
public Shape vyplňElipsu(double a, double b){
if (a < 0 || b < 0) throw new RuntimeException("Dĺžka poloosy elipsy nesmie byť záporná!");
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape elipsa;
if (90 == aktuálnyUhol || 270 == aktuálnyUhol){
elipsa = new Ellipse2D.Double(prepočítanéX - a,
prepočítanéY - b, 2 * a, 2 * b);}
else if (0 == aktuálnyUhol || 180 == aktuálnyUhol){
elipsa = new Ellipse2D.Double(prepočítanéX - b,
prepočítanéY - a, 2 * b, 2 * a);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
elipsa = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Ellipse2D.Double(prepočítanéX - a,
prepočítanéY - b, 2 * a, 2 * b));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(elipsa);
aktualizujPôsobisko(elipsa.getBounds2D());automatickéPrekreslenie();}return elipsa;}
public Shape vyplnElipsu(double a, double b) { return vyplňElipsu(a, b); }
public Shape vyplnenáElipsa(double a, double b) { return vyplňElipsu(a, b); }
public Shape vyplnenaElipsa(double a, double b) { return vyplňElipsu(a, b); }
public Shape vyplnenúElipsu(double a, double b) { return vyplňElipsu(a, b); }
public Shape vyplnenuElipsu(double a, double b) { return vyplňElipsu(a, b); }
public Shape vyplnenejElipsy(double a, double b) { return vyplňElipsu(a, b); }
public Shape štvorec(double polomer){
if (polomer < 0) throw new RuntimeException("Polomer vpísanej kružnice nesmie byť záporný!");
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape štvorec;if (aktuálnyUhol % 90 == 0){štvorec = new
Rectangle2D.Double(prepočítanéX - polomer,
prepočítanéY - polomer, 2 * polomer, 2 * polomer);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
štvorec = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Rectangle2D.Double(prepočítanéX - polomer,
prepočítanéY - polomer, 2 * polomer, 2 * polomer));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(štvorec);
aktualizujPôsobisko(štvorec.getBounds2D());automatickéPrekreslenie();}return štvorec;}
public Shape stvorec(double polomer) { return štvorec(polomer); }
public Shape štvorca(double polomer) { return štvorec(polomer); }
public Shape stvorca(double polomer) { return štvorec(polomer); }
public Shape vyplňŠtvorec(double polomer){
if (polomer < 0) throw new RuntimeException("Polomer vpísanej kružnice nesmie byť záporný!");
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape štvorec;if (aktuálnyUhol % 90 == 0){štvorec = new
Rectangle2D.Double(prepočítanéX - polomer,
prepočítanéY - polomer, 2 * polomer, 2 * polomer);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
štvorec = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Rectangle2D.Double(prepočítanéX - polomer,
prepočítanéY - polomer, 2 * polomer, 2 * polomer));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(štvorec);
aktualizujPôsobisko(štvorec.getBounds2D());automatickéPrekreslenie();}return štvorec;}
public Shape vyplnStvorec(double polomer) { return vyplňŠtvorec(polomer); }
public Shape vyplnenýŠtvorec(double polomer) { return vyplňŠtvorec(polomer); }
public Shape vyplnenyStvorec(double polomer) { return vyplňŠtvorec(polomer); }
public Shape vyplnenéhoŠtvorca(double polomer) { return vyplňŠtvorec(polomer); }
public Shape vyplnenehoStvorca(double polomer) { return vyplňŠtvorec(polomer); }
public Shape obdĺžnik(double a, double b){
if (a < 0 || b < 0) throw new RuntimeException("Dĺžka poloosy vpísanej elipsy nesmie byť záporná!");
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape obdĺžnik;
if (90 == aktuálnyUhol || 270 == aktuálnyUhol){obdĺžnik = new
Rectangle2D.Double(prepočítanéX - a,
prepočítanéY - b, 2 * a, 2 * b);}
else if (0 == aktuálnyUhol || 180 == aktuálnyUhol){obdĺžnik = new
Rectangle2D.Double(prepočítanéX - b,
prepočítanéY - a, 2 * b, 2 * a);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
obdĺžnik = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Rectangle2D.Double(prepočítanéX - a,
prepočítanéY - b, 2 * a, 2 * b));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(obdĺžnik);
aktualizujPôsobisko(obdĺžnik.getBounds2D());automatickéPrekreslenie();}return obdĺžnik;}
public Shape obdlznik(double a, double b) { return obdĺžnik(a, b); }
public Shape obdĺžnika(double a, double b) { return obdĺžnik(a, b); }
public Shape obdlznika(double a, double b) { return obdĺžnik(a, b); }
public Shape vyplňObdĺžnik(double a, double b){
if (a < 0 || b < 0) throw new RuntimeException("Dĺžka poloosy vpísanej elipsy nesmie byť záporná!");
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape obdĺžnik;
if (90 == aktuálnyUhol || 270 == aktuálnyUhol){obdĺžnik = new
Rectangle2D.Double(prepočítanéX - a,
prepočítanéY - b, 2 * a, 2 * b);}
else if (0 == aktuálnyUhol || 180 == aktuálnyUhol){obdĺžnik = new
Rectangle2D.Double(prepočítanéX - b,
prepočítanéY - a, 2 * b, 2 * a);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
obdĺžnik = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Rectangle2D.Double(prepočítanéX - a,
prepočítanéY - b, 2 * a, 2 * b));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(obdĺžnik);
aktualizujPôsobisko(obdĺžnik.getBounds2D());automatickéPrekreslenie();}return obdĺžnik;}
public Shape vyplnObdlznik(double a, double b) { return vyplňObdĺžnik(a, b); }
public Shape vyplnenýObdĺžnik(double a, double b) { return vyplňObdĺžnik(a, b); }
public Shape vyplnenyObdlznik(double a, double b) { return vyplňObdĺžnik(a, b); }
public Shape vyplnenéhoObdĺžnika(double a, double b) { return vyplňObdĺžnik(a, b); }
public Shape vyplnenehoObdlznika(double a, double b) { return vyplňObdĺžnik(a, b); }public Shape kružnica(){
Shape kružnica = new Ellipse2D.Double(
prepočítajX(aktuálneX) - veľkosť,
prepočítajY(aktuálneY) - veľkosť,2 * veľkosť, 2 * veľkosť);if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(kružnica);aktualizujPôsobisko(veľkosť);automatickéPrekreslenie();}return kružnica;}
public Shape kruznica() { return kružnica(); }
public Shape kružnicu() { return kružnica(); }
public Shape kruznicu() { return kružnica(); }
public Shape kružnice() { return kružnica(); }
public Shape kruznice() { return kružnica(); }public Shape kruh(){
Shape kruh = new Ellipse2D.Double(
prepočítajX(aktuálneX) - veľkosť,
prepočítajY(aktuálneY) - veľkosť,2 * veľkosť, 2 * veľkosť);if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(kruh);aktualizujPôsobisko(veľkosť);automatickéPrekreslenie();}return kruh;}
public Shape kruhu() { return kruh(); }
public Shape elipsa(double pomer){
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape elipsa;
if (90 == aktuálnyUhol || 270 == aktuálnyUhol){
elipsa = new Ellipse2D.Double(prepočítanéX - veľkosť *
pomer, prepočítanéY - veľkosť, 2 * veľkosť * pomer,2 * veľkosť);}
else if (0 == aktuálnyUhol || 180 == aktuálnyUhol){
elipsa = new Ellipse2D.Double(prepočítanéX - veľkosť,
prepočítanéY - veľkosť * pomer, 2 * veľkosť,2 * veľkosť * pomer);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
elipsa = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Ellipse2D.Double(prepočítanéX - veľkosť * pomer,
prepočítanéY - veľkosť, 2 * veľkosť * pomer,2 * veľkosť));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(elipsa);
aktualizujPôsobisko(elipsa.getBounds2D());automatickéPrekreslenie();}return elipsa;}
public Shape elipsu(double pomer) { return elipsa(pomer); }
public Shape elipsy(double pomer) { return elipsa(pomer); }
public Shape vyplňElipsu(double pomer){
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape elipsa;
if (90 == aktuálnyUhol || 270 == aktuálnyUhol){
elipsa = new Ellipse2D.Double(prepočítanéX - veľkosť *
pomer, prepočítanéY - veľkosť, 2 * veľkosť * pomer,2 * veľkosť);}
else if (0 == aktuálnyUhol || 180 == aktuálnyUhol){
elipsa = new Ellipse2D.Double(prepočítanéX - veľkosť,
prepočítanéY - veľkosť * pomer, 2 * veľkosť,2 * veľkosť * pomer);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
elipsa = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Ellipse2D.Double(prepočítanéX - veľkosť * pomer,
prepočítanéY - veľkosť, 2 * veľkosť * pomer,2 * veľkosť));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(elipsa);
aktualizujPôsobisko(elipsa.getBounds2D());automatickéPrekreslenie();}return elipsa;}
public Shape vyplnElipsu(double pomer) { return vyplňElipsu(pomer); }
public Shape vyplnenáElipsa(double pomer) { return vyplňElipsu(pomer); }
public Shape vyplnenaElipsa(double pomer) { return vyplňElipsu(pomer); }
public Shape vyplnenúElipsu(double pomer) { return vyplňElipsu(pomer); }
public Shape vyplnenuElipsu(double pomer) { return vyplňElipsu(pomer); }
public Shape vyplnenejElipsy(double pomer) { return vyplňElipsu(pomer); }public Shape štvorec(){
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape štvorec;if (aktuálnyUhol % 90 == 0){štvorec = new
Rectangle2D.Double(prepočítanéX - veľkosť,
prepočítanéY - veľkosť, 2 * veľkosť, 2 * veľkosť);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
štvorec = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Rectangle2D.Double(prepočítanéX - veľkosť,
prepočítanéY - veľkosť, 2 * veľkosť, 2 * veľkosť));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(štvorec);
aktualizujPôsobisko(štvorec.getBounds2D());automatickéPrekreslenie();}return štvorec;}
public Shape stvorec() { return štvorec(); }
public Shape štvorca() { return štvorec(); }
public Shape stvorca() { return štvorec(); }public Shape vyplňŠtvorec(){
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape štvorec;if (aktuálnyUhol % 90 == 0){štvorec = new
Rectangle2D.Double(prepočítanéX - veľkosť,
prepočítanéY - veľkosť, 2 * veľkosť, 2 * veľkosť);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
štvorec = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Rectangle2D.Double(prepočítanéX - veľkosť,
prepočítanéY - veľkosť, 2 * veľkosť, 2 * veľkosť));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(štvorec);
aktualizujPôsobisko(štvorec.getBounds2D());automatickéPrekreslenie();}return štvorec;}
public Shape vyplnStvorec() { return vyplňŠtvorec(); }
public Shape vyplnenýŠtvorec() { return vyplňŠtvorec(); }
public Shape vyplnenyStvorec() { return vyplňŠtvorec(); }
public Shape vyplnenéhoŠtvorca() { return vyplňŠtvorec(); }
public Shape vyplnenehoStvorca() { return vyplňŠtvorec(); }
public Shape obdĺžnik(double pomer){
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape obdĺžnik;
if (90 == aktuálnyUhol || 270 == aktuálnyUhol){obdĺžnik = new
Rectangle2D.Double(prepočítanéX - veľkosť * pomer,
prepočítanéY - veľkosť, 2 * veľkosť * pomer,2 * veľkosť);}
else if (0 == aktuálnyUhol || 180 == aktuálnyUhol){obdĺžnik = new
Rectangle2D.Double(prepočítanéX - veľkosť,
prepočítanéY - veľkosť * pomer, 2 * veľkosť,2 * veľkosť * pomer);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
obdĺžnik = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Rectangle2D.Double(prepočítanéX - veľkosť * pomer,
prepočítanéY - veľkosť, 2 * veľkosť * pomer,2 * veľkosť));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(obdĺžnik);
aktualizujPôsobisko(obdĺžnik.getBounds2D());automatickéPrekreslenie();}return obdĺžnik;}
public Shape obdlznik(double pomer) { return obdĺžnik(pomer); }
public Shape obdĺžnika(double pomer) { return obdĺžnik(pomer); }
public Shape obdlznika(double pomer) { return obdĺžnik(pomer); }
public Shape vyplňObdĺžnik(double pomer){
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);Shape obdĺžnik;
if (90 == aktuálnyUhol || 270 == aktuálnyUhol){obdĺžnik = new
Rectangle2D.Double(prepočítanéX - veľkosť * pomer,
prepočítanéY - veľkosť, 2 * veľkosť * pomer,2 * veľkosť);}
else if (0 == aktuálnyUhol || 180 == aktuálnyUhol){obdĺžnik = new
Rectangle2D.Double(prepočítanéX - veľkosť,
prepočítanéY - veľkosť * pomer, 2 * veľkosť,2 * veľkosť * pomer);}else{
double α = Math.toRadians(aktuálnyUhol - 90);
obdĺžnik = AffineTransform.getRotateInstance(-α,prepočítanéX, prepočítanéY).createTransformedShape(new
Rectangle2D.Double(prepočítanéX - veľkosť * pomer,
prepočítanéY - veľkosť, 2 * veľkosť * pomer,2 * veľkosť));}if (kresliTvary){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(obdĺžnik);
aktualizujPôsobisko(obdĺžnik.getBounds2D());automatickéPrekreslenie();}return obdĺžnik;}
public Shape vyplnObdlznik(double pomer) { return vyplňObdĺžnik(pomer); }
public Shape vyplnenýObdĺžnik(double pomer) { return vyplňObdĺžnik(pomer); }
public Shape vyplnenyObdlznik(double pomer) { return vyplňObdĺžnik(pomer); }
public Shape vyplnenéhoObdĺžnika(double pomer) { return vyplňObdĺžnik(pomer); }
public Shape vyplnenehoObdlznika(double pomer) { return vyplňObdĺžnik(pomer); }
public boolean myšVKruhu(double polomer){
double Δx = súradnicaMyšiX - aktuálneX;
double Δy = súradnicaMyšiY - aktuálneY;
return (Δx * Δx + Δy * Δy) <= polomer * polomer;}
public boolean mysVKruhu(double polomer) { return myšVKruhu(polomer); }
public boolean myšVElipse(double a, double b){
double x0 = súradnicaMyšiX - aktuálneX;
double y0 = súradnicaMyšiY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
x1 /= a; y1 /= b; return (x1 * x1 + y1 * y1) <= 1;}
public boolean mysVElipse(double a, double b) { return myšVElipse(a, b); }
public boolean myšVoŠtvorci(double polomer){if (aktuálnyUhol % 90 == 0)
return súradnicaMyšiX >= aktuálneX - polomer && súradnicaMyšiX <= aktuálneX + polomer &&
súradnicaMyšiY >= aktuálneY - polomer && súradnicaMyšiY <= aktuálneY + polomer;
double x0 = súradnicaMyšiX - aktuálneX;
double y0 = súradnicaMyšiY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -polomer && y1 > -polomer && x1 < polomer && y1 < polomer;}
public boolean mysVoStvorci(double polomer) { return myšVoŠtvorci(polomer); }
public boolean myšVObdĺžniku(double a, double b){
if (90 == aktuálnyUhol || 270 == aktuálnyUhol)
return súradnicaMyšiX >= aktuálneX - a && súradnicaMyšiX <= aktuálneX + a &&
súradnicaMyšiY >= aktuálneY - b && súradnicaMyšiY <= aktuálneY + b;
if (0 == aktuálnyUhol || 180 == aktuálnyUhol)
return súradnicaMyšiX >= aktuálneX - b && súradnicaMyšiX <= aktuálneX + b &&
súradnicaMyšiY >= aktuálneY - a && súradnicaMyšiY <= aktuálneY + a;
double x0 = súradnicaMyšiX - aktuálneX;
double y0 = súradnicaMyšiY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -a && y1 > -b && x1 < a && y1 < b;}
public boolean mysVObdlzniku(double a, double b)
{ return myšVObdĺžniku(a, b); }
public boolean myšVOblasti(Oblasť oblasť){
if (aktuálnyUhol == 90 && aktuálneX == 0 && aktuálneY == 0)
return oblasť.contains(prepočítajX(súradnicaMyšiX),prepočítajY(súradnicaMyšiY));
AffineTransform at = new AffineTransform();
at.rotate(Math.toRadians(aktuálnyUhol - 90));
at.translate(aktuálneX, -aktuálneY);
Area a = oblasť.createTransformedArea(at);
return oblasť.contains(prepočítajX(súradnicaMyšiX),prepočítajY(súradnicaMyšiY));}
public boolean mysVOblasti(Oblasť oblasť) { return myšVOblasti(oblasť); }public boolean myšVKruhu(){
double Δx = súradnicaMyšiX - aktuálneX;
double Δy = súradnicaMyšiY - aktuálneY;
return (Δx * Δx + Δy * Δy) <= veľkosť * veľkosť;}
public boolean mysVKruhu() { return myšVKruhu(); }
public boolean myšV() { return myšVKruhu(); }
public boolean mysV() { return myšVKruhu(); }
public boolean myšVElipse(double pomer){
double x0 = súradnicaMyšiX - aktuálneX;
double y0 = súradnicaMyšiY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);x1 /= (veľkosť * pomer);y1 /= veľkosť;
return (x1 * x1 + y1 * y1) <= 1;}
public boolean mysVElipse(double pomer) { return myšVElipse(pomer); }public boolean myšVoŠtvorci(){if (aktuálnyUhol % 90 == 0)
return súradnicaMyšiX >= aktuálneX - veľkosť &&
súradnicaMyšiX <= aktuálneX + veľkosť &&
súradnicaMyšiY >= aktuálneY - veľkosť &&
súradnicaMyšiY <= aktuálneY + veľkosť;
double x0 = súradnicaMyšiX - aktuálneX;
double y0 = súradnicaMyšiY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -veľkosť && y1 > -veľkosť &&x1 < veľkosť && y1 < veľkosť;}
public boolean mysVoStvorci() { return myšVoŠtvorci(); }
public boolean myšVObdĺžniku(double pomer){
if (90 == aktuálnyUhol || 270 == aktuálnyUhol)
return súradnicaMyšiX >= aktuálneX - (veľkosť * pomer) &&
súradnicaMyšiX <= aktuálneX + (veľkosť * pomer) &&
súradnicaMyšiY >= aktuálneY - veľkosť &&
súradnicaMyšiY <= aktuálneY + veľkosť;
if (0 == aktuálnyUhol || 180 == aktuálnyUhol)
return súradnicaMyšiX >= aktuálneX - veľkosť &&
súradnicaMyšiX <= aktuálneX + veľkosť &&
súradnicaMyšiY >= aktuálneY - (veľkosť * pomer) &&
súradnicaMyšiY <= aktuálneY + (veľkosť * pomer);
double x0 = súradnicaMyšiX - aktuálneX;
double y0 = súradnicaMyšiY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -(veľkosť * pomer) && y1 > -veľkosť &&
x1 < (veľkosť * pomer) && y1 < veľkosť;}
public boolean mysVObdlzniku(double pomer)
{ return myšVObdĺžniku(pomer); }
public boolean bodVKruhu(double súradnicaBoduX, double súradnicaBoduY, double polomer){
double Δx = súradnicaBoduX - aktuálneX;
double Δy = súradnicaBoduY - aktuálneY;
return (Δx * Δx + Δy * Δy) <= polomer * polomer;}
public boolean bodVKruhu(Point2D bod, double polomer){
double Δx = bod.getX() - aktuálneX;
double Δy = bod.getY() - aktuálneY;
return (Δx * Δx + Δy * Δy) <= polomer * polomer;}
public boolean bodVKruhu(Poloha objekt, double polomer){
double Δx = objekt.polohaX() - aktuálneX;
double Δy = objekt.polohaY() - aktuálneY;
return (Δx * Δx + Δy * Δy) <= polomer * polomer;}
public boolean bodVElipse(double súradnicaBoduX, double súradnicaBoduY, double a, double b){
double x0 = súradnicaBoduX - aktuálneX;
double y0 = súradnicaBoduY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
x1 /= a; y1 /= b; return (x1 * x1 + y1 * y1) <= 1;}
public boolean bodVElipse(Point2D bod, double a, double b){
double x0 = bod.getX() - aktuálneX;
double y0 = bod.getY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
x1 /= a; y1 /= b; return (x1 * x1 + y1 * y1) <= 1;}
public boolean bodVElipse(Poloha objekt, double a, double b){
double x0 = objekt.polohaX() - aktuálneX;
double y0 = objekt.polohaY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
x1 /= a; y1 /= b; return (x1 * x1 + y1 * y1) <= 1;}
public boolean bodVoŠtvorci(double súradnicaBoduX, double súradnicaBoduY, double polomer){if (aktuálnyUhol % 90 == 0)
return súradnicaBoduX >= aktuálneX - polomer && súradnicaBoduX <= aktuálneX + polomer &&
súradnicaBoduY >= aktuálneY - polomer && súradnicaBoduY <= aktuálneY + polomer;
double x0 = súradnicaBoduX - aktuálneX;
double y0 = súradnicaBoduY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -polomer && y1 > -polomer && x1 < polomer && y1 < polomer;}
public boolean bodVoStvorci(double súradnicaBoduX, double súradnicaBoduY, double polomer) { return bodVoŠtvorci(súradnicaBoduX, súradnicaBoduY, polomer); }
public boolean bodVoŠtvorci(Point2D bod, double polomer){if (aktuálnyUhol % 90 == 0)
return bod.getX() >= aktuálneX - polomer && bod.getX() <= aktuálneX + polomer &&
bod.getY() >= aktuálneY - polomer && bod.getY() <= aktuálneY + polomer;
double x0 = bod.getX() - aktuálneX;
double y0 = bod.getY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -polomer && y1 > -polomer && x1 < polomer && y1 < polomer;}
public boolean bodVoStvorci(Point2D bod, double polomer) { return bodVoŠtvorci(bod, polomer); }
public boolean bodVoŠtvorci(Poloha objekt, double polomer){if (aktuálnyUhol % 90 == 0)
return objekt.polohaX() >= aktuálneX - polomer &&
objekt.polohaX() <= aktuálneX + polomer &&
objekt.polohaY() >= aktuálneY - polomer &&
objekt.polohaY() <= aktuálneY + polomer;
double x0 = objekt.polohaX() - aktuálneX;
double y0 = objekt.polohaY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -polomer && y1 > -polomer && x1 < polomer && y1 < polomer;}
public boolean bodVoStvorci(Poloha objekt, double polomer) { return bodVoŠtvorci(objekt, polomer); }
public boolean bodVObdĺžniku(double súradnicaBoduX, double súradnicaBoduY, double a, double b){
if (90 == aktuálnyUhol || 270 == aktuálnyUhol)
return súradnicaBoduX >= aktuálneX - a && súradnicaBoduX <= aktuálneX + a &&
súradnicaBoduY >= aktuálneY - b && súradnicaBoduY <= aktuálneY + b;
if (0 == aktuálnyUhol || 180 == aktuálnyUhol)
return súradnicaBoduX >= aktuálneX - b && súradnicaBoduX <= aktuálneX + b &&
súradnicaBoduY >= aktuálneY - a && súradnicaBoduY <= aktuálneY + a;
double x0 = súradnicaBoduX - aktuálneX;
double y0 = súradnicaBoduY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -a && y1 > -b && x1 < a && y1 < b;}
public boolean bodVObdlzniku(double súradnicaBoduX, double súradnicaBoduY, double a, double b) { return bodVObdĺžniku(súradnicaBoduX, súradnicaBoduY, a, b); }
public boolean bodVObdĺžniku(Point2D bod, double a, double b){
if (90 == aktuálnyUhol || 270 == aktuálnyUhol)
return bod.getX() >= aktuálneX - a && bod.getX() <= aktuálneX + a &&
bod.getY() >= aktuálneY - b && bod.getY() <= aktuálneY + b;
if (0 == aktuálnyUhol || 180 == aktuálnyUhol)
return bod.getX() >= aktuálneX - b && bod.getX() <= aktuálneX + b &&
bod.getY() >= aktuálneY - a && bod.getY() <= aktuálneY + a;
double x0 = bod.getX() - aktuálneX;
double y0 = bod.getY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -a && y1 > -b && x1 < a && y1 < b;}
public boolean bodVObdlzniku(Point2D bod, double a, double b) { return bodVObdĺžniku(bod, a, b); }
public boolean bodVObdĺžniku(Poloha objekt, double a, double b){
if (90 == aktuálnyUhol || 270 == aktuálnyUhol)
return objekt.polohaX() >= aktuálneX - a &&
objekt.polohaX() <= aktuálneX + a &&
objekt.polohaY() >= aktuálneY - b &&
objekt.polohaY() <= aktuálneY + b;
if (0 == aktuálnyUhol || 180 == aktuálnyUhol)
return objekt.polohaX() >= aktuálneX - b &&
objekt.polohaX() <= aktuálneX + b &&
objekt.polohaY() >= aktuálneY - a &&
objekt.polohaY() <= aktuálneY + a;
double x0 = objekt.polohaX() - aktuálneX;
double y0 = objekt.polohaY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -a && y1 > -b && x1 < a && y1 < b;}
public boolean bodVObdlzniku(Poloha objekt, double a, double b) { return bodVObdĺžniku(objekt, a, b); }
public boolean bodVTvare(double súradnicaBoduX, double súradnicaBoduY, Shape tvar){
return tvar.contains(prepočítajX(súradnicaBoduX),prepočítajY(súradnicaBoduY));}
public boolean bodVTvare(Point2D bod, Shape tvar){
return tvar.contains(prepočítajX(bod.getX()),prepočítajY(bod.getY()));}
public boolean bodVTvare(Poloha objekt, Shape tvar){
return tvar.contains(prepočítajX(objekt.polohaX()),
prepočítajY(objekt.polohaY()));}
public boolean bodVKruhu(double súradnicaBoduX, double súradnicaBoduY){
double Δx = súradnicaBoduX - aktuálneX;
double Δy = súradnicaBoduY - aktuálneY;
return (Δx * Δx + Δy * Δy) <= veľkosť * veľkosť;}
public boolean bodVKruhu(Point2D bod){
double Δx = bod.getX() - aktuálneX;
double Δy = bod.getY() - aktuálneY;
return (Δx * Δx + Δy * Δy) <= veľkosť * veľkosť;}
public boolean bodVKruhu(Poloha objekt){
double Δx = objekt.polohaX() - aktuálneX;
double Δy = objekt.polohaY() - aktuálneY;
return (Δx * Δx + Δy * Δy) <= veľkosť * veľkosť;}
public boolean bodVElipse(double súradnicaBoduX, double súradnicaBoduY, double pomer){
double x0 = súradnicaBoduX - aktuálneX;
double y0 = súradnicaBoduY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);x1 /= (veľkosť * pomer);y1 /= veľkosť;
return (x1 * x1 + y1 * y1) <= 1;}
public boolean bodVElipse(Point2D bod, double pomer){
double x0 = bod.getX() - aktuálneX;
double y0 = bod.getY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);x1 /= (veľkosť * pomer);y1 /= veľkosť;
return (x1 * x1 + y1 * y1) <= 1;}
public boolean bodVElipse(Poloha objekt, double pomer){
double x0 = objekt.polohaX() - aktuálneX;
double y0 = objekt.polohaY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);x1 /= (veľkosť * pomer);y1 /= veľkosť;
return (x1 * x1 + y1 * y1) <= 1;}
public boolean bodVoŠtvorci(double súradnicaBoduX, double súradnicaBoduY){if (aktuálnyUhol % 90 == 0)
return súradnicaBoduX >= aktuálneX - veľkosť &&
súradnicaBoduX <= aktuálneX + veľkosť &&
súradnicaBoduY >= aktuálneY - veľkosť &&
súradnicaBoduY <= aktuálneY + veľkosť;
double x0 = súradnicaBoduX - aktuálneX;
double y0 = súradnicaBoduY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -veľkosť && y1 > -veľkosť && x1 < veľkosť && y1 < veľkosť;}
public boolean bodVoStvorci(double súradnicaBoduX, double súradnicaBoduY) { return bodVoŠtvorci(súradnicaBoduX, súradnicaBoduY); }
public boolean bodVoŠtvorci(Point2D bod){if (aktuálnyUhol % 90 == 0)
return bod.getX() >= aktuálneX - veľkosť &&
bod.getX() <= aktuálneX + veľkosť &&
bod.getY() >= aktuálneY - veľkosť &&
bod.getY() <= aktuálneY + veľkosť;
double x0 = bod.getX() - aktuálneX;
double y0 = bod.getY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -veľkosť && y1 > -veľkosť && x1 < veľkosť && y1 < veľkosť;}
public boolean bodVoStvorci(Point2D bod) { return bodVoŠtvorci(bod); }
public boolean bodVoŠtvorci(Poloha objekt){if (aktuálnyUhol % 90 == 0)
return objekt.polohaX() >= aktuálneX - veľkosť &&
objekt.polohaX() <= aktuálneX + veľkosť &&
objekt.polohaY() >= aktuálneY - veľkosť &&
objekt.polohaY() <= aktuálneY + veľkosť;
double x0 = objekt.polohaX() - aktuálneX;
double y0 = objekt.polohaY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -veľkosť && y1 > -veľkosť && x1 < veľkosť && y1 < veľkosť;}
public boolean bodVoStvorci(Poloha objekt) { return bodVoŠtvorci(objekt); }
public boolean bodVObdĺžniku(double súradnicaBoduX, double súradnicaBoduY, double pomer){
if (90 == aktuálnyUhol || 270 == aktuálnyUhol)
return súradnicaBoduX >= aktuálneX - (veľkosť * pomer) &&
súradnicaBoduX <= aktuálneX + (veľkosť * pomer) &&
súradnicaBoduY >= aktuálneY - veľkosť &&
súradnicaBoduY <= aktuálneY + veľkosť;
if (0 == aktuálnyUhol || 180 == aktuálnyUhol)
return súradnicaBoduX >= aktuálneX - veľkosť &&
súradnicaBoduX <= aktuálneX + veľkosť &&
súradnicaBoduY >= aktuálneY - (veľkosť * pomer) && súradnicaBoduY <= aktuálneY + (veľkosť * pomer);
double x0 = súradnicaBoduX - aktuálneX;
double y0 = súradnicaBoduY - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -(veľkosť * pomer) && y1 > -veľkosť &&
x1 < (veľkosť * pomer) && y1 < veľkosť;}
public boolean bodVObdlzniku(double súradnicaBoduX, double súradnicaBoduY, double pomer) { return bodVObdĺžniku(súradnicaBoduX, súradnicaBoduY, pomer); }
public boolean bodVObdĺžniku(Point2D bod, double pomer){
if (90 == aktuálnyUhol || 270 == aktuálnyUhol)
return bod.getX() >= aktuálneX - (veľkosť * pomer) &&
bod.getX() <= aktuálneX + (veľkosť * pomer) &&
bod.getY() >= aktuálneY - veľkosť &&
bod.getY() <= aktuálneY + veľkosť;
if (0 == aktuálnyUhol || 180 == aktuálnyUhol)
return bod.getX() >= aktuálneX - veľkosť &&
bod.getX() <= aktuálneX + veľkosť &&
bod.getY() >= aktuálneY - (veľkosť * pomer) &&
bod.getY() <= aktuálneY + (veľkosť * pomer);
double x0 = bod.getX() - aktuálneX;
double y0 = bod.getY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -(veľkosť * pomer) && y1 > -veľkosť &&
x1 < (veľkosť * pomer) && y1 < veľkosť;}
public boolean bodVObdlzniku(Point2D bod, double pomer) { return bodVObdĺžniku(bod, pomer); }
public boolean bodVObdĺžniku(Poloha objekt, double pomer){
if (90 == aktuálnyUhol || 270 == aktuálnyUhol)
return objekt.polohaX() >= aktuálneX - (veľkosť * pomer) &&
objekt.polohaX() <= aktuálneX + (veľkosť * pomer) &&
objekt.polohaY() >= aktuálneY - veľkosť &&
objekt.polohaY() <= aktuálneY + veľkosť;
if (0 == aktuálnyUhol || 180 == aktuálnyUhol)
return objekt.polohaX() >= aktuálneX - veľkosť &&
objekt.polohaX() <= aktuálneX + veľkosť &&
objekt.polohaY() >= aktuálneY - (veľkosť * pomer) &&
objekt.polohaY() <= aktuálneY + (veľkosť * pomer);
double x0 = objekt.polohaX() - aktuálneX;
double y0 = objekt.polohaY() - aktuálneY;
double α = Math.toRadians(90 - aktuálnyUhol);
double x1 = rotovanéX(x0, y0, α);
double y1 = rotovanéY(x0, y0, α);
return x1 > -(veľkosť * pomer) && y1 > -veľkosť &&
x1 < (veľkosť * pomer) && y1 < veľkosť;}
public boolean bodVObdlzniku(Poloha objekt, double pomer) { return bodVObdĺžniku(objekt, pomer); }
public void obrázok(String súbor) { obrázok(súbor, spôsobKreslenia); }
public void obrazok(String súbor) { obrázok(súbor, spôsobKreslenia); }
public void obrázok(String súbor, int spôsobKreslenia){
Image obrázok = súborNaObrázok(súbor);
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);
int šírkaObrázka = obrázok.getWidth(null);
int výškaObrázka = obrázok.getHeight(null);
if (šírkaObrázka < 0 || výškaObrázka < 0)
throw new RuntimeException("Obrázok „" + súbor + "“ je poškodený!");
if ((90 == aktuálnyUhol) || (0 ==
(spôsobKreslenia & KRESLI_ROTOVANÉ))){
if (0 == (spôsobKreslenia & KRESLI_NA_STRED)){aktualizujPôsobisko(aktuálneX,aktuálneY - výškaObrázka,aktuálneX + šírkaObrázka,aktuálneY);
grafikaAktívnehoPlátna.drawImage(obrázok,
(int)prepočítanéX, (int)prepočítanéY, null);}else{aktualizujPôsobisko(
aktuálneX - (šírkaObrázka / 2.0),
aktuálneY - (výškaObrázka / 2.0),
aktuálneX + (šírkaObrázka / 2.0),
aktuálneY + (výškaObrázka / 2.0));
grafikaAktívnehoPlátna.drawImage(obrázok,
(int)(prepočítanéX - (šírkaObrázka / 2.0)),
(int)(prepočítanéY - (výškaObrázka / 2.0)), null);}}else{
double α = Math.toRadians(aktuálnyUhol - 90);
grafikaAktívnehoPlátna.rotate(-α,prepočítanéX, prepočítanéY);
if (0 == (spôsobKreslenia & KRESLI_NA_STRED)){double x0 = 0;double y0 = -výškaObrázka;double x1 = šírkaObrázka;double y1 = 0;aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y0, α),
aktuálneY + rotovanéY(x0, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y1, α),
aktuálneY + rotovanéY(x0, y1, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y0, α),
aktuálneY + rotovanéY(x1, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y1, α),
aktuálneY + rotovanéY(x1, y1, α));
grafikaAktívnehoPlátna.drawImage(obrázok,
(int)prepočítanéX, (int)prepočítanéY, null);}else{
double x0 = -(šírkaObrázka / 2.0);
double y0 = -(výškaObrázka / 2.0);
double x1 = (šírkaObrázka / 2.0);
double y1 = (výškaObrázka / 2.0);aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y0, α),
aktuálneY + rotovanéY(x0, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y1, α),
aktuálneY + rotovanéY(x0, y1, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y0, α),
aktuálneY + rotovanéY(x1, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y1, α),
aktuálneY + rotovanéY(x1, y1, α));
grafikaAktívnehoPlátna.drawImage(obrázok,
(int)(prepočítanéX - (šírkaObrázka / 2.0)),
(int)(prepočítanéY - (výškaObrázka / 2.0)), null);}
grafikaAktívnehoPlátna.rotate(α,prepočítanéX, prepočítanéY);}automatickéPrekreslenie();}
public void obrazok(String súbor, int spôsobKreslenia)
{ obrázok(súbor, spôsobKreslenia); }
public void obrázok(Image obrázok)
{ obrázok(obrázok, spôsobKreslenia); }
public void obrazok(Image obrázok)
{ obrázok(obrázok, spôsobKreslenia); }
public void obrázok(Image obrázok, int spôsobKreslenia){
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);
int šírkaObrázka = obrázok.getWidth(null);
int výškaObrázka = obrázok.getHeight(null);
if (šírkaObrázka < 0 || výškaObrázka < 0)
throw new RuntimeException("Obrázok je poškodený!");if ((90 == aktuálnyUhol) ||
(0 == (spôsobKreslenia & KRESLI_ROTOVANÉ))){
if (0 == (spôsobKreslenia & KRESLI_NA_STRED)){aktualizujPôsobisko(aktuálneX,aktuálneY - výškaObrázka,aktuálneX + šírkaObrázka,aktuálneY);
if (obrázok instanceof Obrázok)((Obrázok)obrázok).kresliNa((int)prepočítanéX,
(int)prepočítanéY, grafikaAktívnehoPlátna);else
grafikaAktívnehoPlátna.drawImage(obrázok,
(int)prepočítanéX, (int)prepočítanéY, null);}else{aktualizujPôsobisko(
aktuálneX - (šírkaObrázka / 2.0),
aktuálneY - (výškaObrázka / 2.0),
aktuálneX + (šírkaObrázka / 2.0),
aktuálneY + (výškaObrázka / 2.0));
if (obrázok instanceof Obrázok)((Obrázok)obrázok).
kresliNaStred((int)prepočítanéX,
(int)prepočítanéY, grafikaAktívnehoPlátna);else
grafikaAktívnehoPlátna.drawImage(obrázok,
(int)(prepočítanéX - (šírkaObrázka / 2.0)),
(int)(prepočítanéY - (výškaObrázka / 2.0)), null);}}else{
double α = Math.toRadians(aktuálnyUhol - 90);
grafikaAktívnehoPlátna.rotate(-α,prepočítanéX, prepočítanéY);
if (0 == (spôsobKreslenia & KRESLI_NA_STRED)){double x0 = 0;double y0 = -výškaObrázka;double x1 = šírkaObrázka;double y1 = 0;aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y0, α),
aktuálneY + rotovanéY(x0, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y1, α),
aktuálneY + rotovanéY(x0, y1, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y0, α),
aktuálneY + rotovanéY(x1, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y1, α),
aktuálneY + rotovanéY(x1, y1, α));
if (obrázok instanceof Obrázok)((Obrázok)obrázok).kresliNa((int)prepočítanéX,
(int)prepočítanéY, grafikaAktívnehoPlátna);else
grafikaAktívnehoPlátna.drawImage(obrázok,
(int)prepočítanéX, (int)prepočítanéY, null);}else{
double x0 = -(šírkaObrázka / 2.0);
double y0 = -(výškaObrázka / 2.0);
double x1 = (šírkaObrázka / 2.0);
double y1 = (výškaObrázka / 2.0);aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y0, α),
aktuálneY + rotovanéY(x0, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y1, α),
aktuálneY + rotovanéY(x0, y1, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y0, α),
aktuálneY + rotovanéY(x1, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y1, α),
aktuálneY + rotovanéY(x1, y1, α));
if (obrázok instanceof Obrázok)((Obrázok)obrázok).
kresliNaStred((int)prepočítanéX,(int)prepočítanéY,grafikaAktívnehoPlátna);else
grafikaAktívnehoPlátna.drawImage(obrázok,
(int)(prepočítanéX - (šírkaObrázka / 2.0)),
(int)(prepočítanéY - (výškaObrázka / 2.0)),null);}
grafikaAktívnehoPlátna.rotate(α,prepočítanéX, prepočítanéY);}automatickéPrekreslenie();}
public void obrazok(Image obrázok, int spôsobKreslenia)
{ obrázok(obrázok, spôsobKreslenia); }public Shape text(String text)
{ return text(text, spôsobKreslenia); }
public Shape text(String text, int spôsobKreslenia){
double prepočítanéX = prepočítajX(aktuálneX);
double prepočítanéY = prepočítajY(aktuálneY);
grafikaAktívnehoPlátna.setFont(aktuálnePísmo);
FontMetrics rozmery = grafikaAktívnehoPlátna.getFontMetrics();
int šírkaTextu = rozmery.stringWidth(text);
int poklesTextu = (rozmery.getDescent() * 3) / 2;if (!kresliTvary){
TextLayout rozloženieTextu = new TextLayout(text,
aktuálnePísmo, grafikaAktívnehoPlátna.getFontRenderContext());
AffineTransform transformácie = new AffineTransform();if ((90 == aktuálnyUhol) ||
(0 == (spôsobKreslenia & KRESLI_ROTOVANÉ))){
if (0 == (spôsobKreslenia & KRESLI_NA_STRED)){
transformácie.setToTranslation((float)prepočítanéX,(float)prepočítanéY);}else{
transformácie.setToTranslation(
(float)(prepočítanéX - (šírkaTextu / 2.0)),
(float)(prepočítanéY + poklesTextu));}}else{
double α = Math.toRadians(aktuálnyUhol - 90);
transformácie.rotate(-α, prepočítanéX, prepočítanéY);
if (0 == (spôsobKreslenia & KRESLI_NA_STRED)){transformácie.translate(
(float)prepočítanéX, (float)prepočítanéY);}else{transformácie.translate(
(float)(prepočítanéX - (šírkaTextu / 2.0)),
(float)(prepočítanéY + poklesTextu));}}
return rozloženieTextu.getOutline(transformácie);}
grafikaAktívnehoPlátna.setColor(farbaPera);if ((90 == aktuálnyUhol) ||
(0 == (spôsobKreslenia & KRESLI_ROTOVANÉ))){
if (0 == (spôsobKreslenia & KRESLI_NA_STRED)){aktualizujPôsobisko(
aktuálneX, aktuálneY, aktuálneX + šírkaTextu,
aktuálneY + poklesTextu + rozmery.getAscent());
grafikaAktívnehoPlátna.drawString(text,
(float)prepočítanéX, (float)prepočítanéY);}else{aktualizujPôsobisko(
aktuálneX - (šírkaTextu / 2.0),aktuálneY - poklesTextu,
aktuálneX + (šírkaTextu / 2.0),
aktuálneY + rozmery.getAscent());
grafikaAktívnehoPlátna.drawString(text,
(float)(prepočítanéX - (šírkaTextu / 2.0)),
(float)(prepočítanéY + poklesTextu));}}else{
double α = Math.toRadians(aktuálnyUhol - 90);
grafikaAktívnehoPlátna.rotate(-α,prepočítanéX, prepočítanéY);
if (0 == (spôsobKreslenia & KRESLI_NA_STRED)){double x0 = 0; double y0 = 0;double x1 = šírkaTextu;
double y1 = poklesTextu + rozmery.getAscent();aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y0, α),
aktuálneY + rotovanéY(x0, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y1, α),
aktuálneY + rotovanéY(x0, y1, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y0, α),
aktuálneY + rotovanéY(x1, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y1, α),
aktuálneY + rotovanéY(x1, y1, α));
grafikaAktívnehoPlátna.drawString(text,
(float)prepočítanéX, (float)prepočítanéY);}else{
double x0 = -(šírkaTextu / 2.0);double y0 = -poklesTextu;
double x1 = (šírkaTextu / 2.0);
double y1 = rozmery.getAscent();aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y0, α),
aktuálneY + rotovanéY(x0, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x0, y1, α),
aktuálneY + rotovanéY(x0, y1, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y0, α),
aktuálneY + rotovanéY(x1, y0, α));aktualizujPôsobisko(
aktuálneX + rotovanéX(x1, y1, α),
aktuálneY + rotovanéY(x1, y1, α));
grafikaAktívnehoPlátna.drawString(text,
(float)(prepočítanéX - (šírkaTextu / 2.0)),
(float)(prepočítanéY + poklesTextu));}
grafikaAktívnehoPlátna.rotate(α,prepočítanéX, prepočítanéY);}automatickéPrekreslenie();return null;}public void začniCestu(){cesta.reset();cesta.moveTo(prepočítajX(aktuálneX),prepočítajY(aktuálneY));záznamCesty = true;
záznamCestyBezPolohyPera = true;}
public void zacniCestu() { začniCestu(); }
public void začniCestu(boolean rešpektujPolohuPera){cesta.reset();cesta.moveTo(prepočítajX(aktuálneX),prepočítajY(aktuálneY));záznamCesty = true;
záznamCestyBezPolohyPera = !rešpektujPolohuPera;}
public void zacniCestu(boolean rešpektujPolohuPera) { začniCestu(rešpektujPolohuPera); }public void skončiCestu(){záznamCesty = false;
záznamCestyBezPolohyPera = true;}
public void skonciCestu() { skončiCestu(); }public void zrušCestu(){cesta.reset();záznamCesty = false;
záznamCestyBezPolohyPera = true;}
public void zrusCestu() { zrušCestu(); }public void uzavriCestu(){if (záznamCesty){cesta.closePath();záznamCesty = false;
záznamCestyBezPolohyPera = true;}}public void vyplňCestu(){záznamCesty = false;
záznamCestyBezPolohyPera = true;
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.fill(cesta);automatickéPrekreslenie();}
public void vyplnCestu() { vyplňCestu(); }public void kresliCestu(){záznamCesty = false;
záznamCestyBezPolohyPera = true;
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(cesta);automatickéPrekreslenie();}public void obkresliCestu(){if (záznamCesty){cesta.closePath();záznamCesty = false;
záznamCestyBezPolohyPera = true;}
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
grafikaAktívnehoPlátna.draw(cesta);automatickéPrekreslenie();}public Shape cesta(){záznamCesty = false;
záznamCestyBezPolohyPera = true;return cesta;}
public Shape cestu() { return cesta(); }
public Shape cesty() { return cesta(); }public boolean myšVCeste(){
return cesta.contains(prepočítajX(súradnicaMyšiX),prepočítajY(súradnicaMyšiY));}
public boolean mysVCeste() { return myšVCeste(); }
public boolean bodVCeste(double súradnicaBoduX, double súradnicaBoduY){
return cesta.contains(prepočítajX(súradnicaBoduX),prepočítajY(súradnicaBoduY));}
public boolean bodVCeste(Point2D bod){
return cesta.contains(prepočítajX(bod.getX()),prepočítajY(bod.getY()));}
public boolean bodVCeste(Poloha objekt){
return cesta.contains(prepočítajX(objekt.polohaX()),
prepočítajY(objekt.polohaY()));}
public void zamestnaj(Oblasť oblasť) { oblasť.zamestnaj(this); }
public void uvoľni(Oblasť oblasť) { oblasť.uvoľni(this); }
public void uvolni(Oblasť oblasť) { uvoľni(oblasť); }
public void prepusti(Oblasť oblasť) { uvoľni(oblasť); }public void uvoľni(){if (null != zamestnanýPre){
zamestnanýPre.zamestnanec = null;kresliTvary = true;zamestnanýPre = null;}}
public void uvolni() { uvoľni(); }
public void prepusti() { uvoľni(); }
public boolean zamestnaný() { return zamestnanýPre != null; }
public boolean zamestnany() { return zamestnanýPre != null; }
public boolean zamestnaný(Oblasť oblasť)
{ return zamestnanýPre == oblasť; }
public boolean zamestnany(Oblasť oblasť)
{ return zamestnanýPre == oblasť; }
public void obkresliOblasť(Oblasť oblasť){
grafikaAktívnehoPlátna.setColor(farbaPera);
grafikaAktívnehoPlátna.setStroke(čiara);
if (aktuálnyUhol == 90 && aktuálneX == 0 && aktuálneY == 0){
grafikaAktívnehoPlátna.draw(oblasť);
aktualizujPôsobisko(oblasť.getBounds2D());}else{
AffineTransform at = new AffineTransform();
at.rotate(Math.toRadians(90 - aktuálnyUhol),
prepočítajX(aktuálneX), prepočítajY(aktuálneY));
at.translate(aktuálneX, -aktuálneY);
Area a = oblasť.createTransformedArea(at);
grafikaAktívnehoPlátna.draw(a);
aktualizujPôsobisko(a.getBounds2D());}automatickéPrekreslenie();}
public void obkresliOblast(Oblasť oblasť) { obkresliOblasť(oblasť); }
public void vyplňOblasť(Oblasť oblasť){
grafikaAktívnehoPlátna.setColor(farbaPera);
if (aktuálnyUhol == 90 && aktuálneX == 0 && aktuálneY == 0){
grafikaAktívnehoPlátna.fill(oblasť);
aktualizujPôsobisko(oblasť.getBounds2D());}else{
AffineTransform at = new AffineTransform();
at.rotate(Math.toRadians(90 - aktuálnyUhol),
prepočítajX(aktuálneX), prepočítajY(aktuálneY));
at.translate(aktuálneX, -aktuálneY);
Area a = oblasť.createTransformedArea(at);
grafikaAktívnehoPlátna.fill(a);
aktualizujPôsobisko(a.getBounds2D());}automatickéPrekreslenie();}
public void vyplnOblast(Oblasť oblasť) { vyplňOblasť(oblasť); }
public void vyplňOblasť(Oblasť oblasť, String súbor){
BufferedImage obrázok = (BufferedImage)súborNaObrázok(súbor);grafikaAktívnehoPlátna.
setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(),obrázok.getHeight())));
if (aktuálnyUhol == 90 && aktuálneX == 0 && aktuálneY == 0){
grafikaAktívnehoPlátna.fill(oblasť);
aktualizujPôsobisko(oblasť.getBounds2D());}else{
AffineTransform at = new AffineTransform();
at.rotate(Math.toRadians(90 - aktuálnyUhol),
prepočítajX(aktuálneX), prepočítajY(aktuálneY));
at.translate(aktuálneX, -aktuálneY);
Area a = oblasť.createTransformedArea(at);
grafikaAktívnehoPlátna.fill(a);
aktualizujPôsobisko(a.getBounds2D());}automatickéPrekreslenie();}
public void vyplnOblast(Oblasť oblasť, String súbor)
{ vyplňOblasť(oblasť, súbor); }
public void vyplňOblasť(Oblasť oblasť, BufferedImage obrázok){
float priehľadnosť = (obrázok instanceof Obrázok) ? (float)
((Obrázok)obrázok).priehľadnosť : 1.0f;if (priehľadnosť > 0){grafikaAktívnehoPlátna.
setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(null),obrázok.getHeight(null))));if (priehľadnosť < 1){Composite záloha =
grafikaAktívnehoPlátna.getComposite();
grafikaAktívnehoPlátna.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,priehľadnosť));
if (aktuálnyUhol == 90 && aktuálneX == 0 &&aktuálneY == 0){
grafikaAktívnehoPlátna.fill(oblasť);
aktualizujPôsobisko(oblasť.getBounds2D());}else{
AffineTransform at = new AffineTransform();
at.rotate(Math.toRadians(90 - aktuálnyUhol),prepočítajX(aktuálneX),prepočítajY(aktuálneY));
at.translate(aktuálneX, -aktuálneY);
Area a = oblasť.createTransformedArea(at);
grafikaAktívnehoPlátna.fill(a);
aktualizujPôsobisko(a.getBounds2D());}
grafikaAktívnehoPlátna.setComposite(záloha);}else{
if (aktuálnyUhol == 90 && aktuálneX == 0 &&aktuálneY == 0){
grafikaAktívnehoPlátna.fill(oblasť);
aktualizujPôsobisko(oblasť.getBounds2D());}else{
AffineTransform at = new AffineTransform();
at.rotate(Math.toRadians(90 - aktuálnyUhol),prepočítajX(aktuálneX),prepočítajY(aktuálneY));
at.translate(aktuálneX, -aktuálneY);
Area a = oblasť.createTransformedArea(at);
grafikaAktívnehoPlátna.fill(a);
aktualizujPôsobisko(a.getBounds2D());}}automatickéPrekreslenie();}}
public void vyplnOblast(Oblasť oblasť, BufferedImage obrázok)
{ vyplňOblasť(oblasť, obrázok); }
public boolean bodVOblasti(double súradnicaBoduX, double súradnicaBoduY, Oblasť oblasť){
if (aktuálnyUhol == 90 && aktuálneX == 0 && aktuálneY == 0)
return oblasť.contains(prepočítajX(súradnicaBoduX),prepočítajY(súradnicaBoduY));
AffineTransform at = new AffineTransform();
at.rotate(Math.toRadians(aktuálnyUhol - 90));
at.translate(aktuálneX, -aktuálneY);
Area a = oblasť.createTransformedArea(at);
return a.contains(prepočítajX(súradnicaBoduX),prepočítajY(súradnicaBoduY));}
public boolean bodVOblasti(Point2D bod, Oblasť oblasť){
if (aktuálnyUhol == 90 && aktuálneX == 0 && aktuálneY == 0)
return oblasť.contains(prepočítajX(bod.getX()),prepočítajY(bod.getY()));
AffineTransform at = new AffineTransform();
at.rotate(Math.toRadians(aktuálnyUhol - 90));
at.translate(aktuálneX, -aktuálneY);
Area a = oblasť.createTransformedArea(at);
return a.contains(prepočítajX(bod.getX()),prepočítajY(bod.getY()));}
public boolean bodVOblasti(Poloha objekt, Oblasť oblasť){
if (aktuálnyUhol == 90 && aktuálneX == 0 && aktuálneY == 0)
return oblasť.contains(prepočítajX(objekt.polohaX()),
prepočítajY(objekt.polohaY()));
AffineTransform at = new AffineTransform();
at.rotate(Math.toRadians(aktuálnyUhol - 90));
at.translate(aktuálneX, -aktuálneY);
Area a = oblasť.createTransformedArea(at);
return a.contains(prepočítajX(objekt.polohaX()),
prepočítajY(objekt.polohaY()));}public void vrstva(int vrstva){Vrstva.preraď(this, vrstva);automatickéPrekreslenie();}public int vrstva(){return vrstva;}public void naVrch(){
if (zoznamRobotov.size() <= 1) return;synchronized (zámokUdalostí){
int index = zoznamRobotov.indexOf(this);
Vrstva.vymaž(index, zoznamRobotov.size() - 1);zoznamRobotov.remove(this);zoznamRobotov.add(this);
Vrstva.vlož(index, zoznamRobotov.size() - 1);}
zoznamZmenený2 = zoznamZmenený1 = true;
if (viditeľný) automatickéPrekreslenie();}public void naSpodok(){
if (zoznamRobotov.size() <= 1) return;synchronized (zámokUdalostí){
int index = zoznamRobotov.indexOf(this);Vrstva.vymaž(0, index);zoznamRobotov.remove(this);zoznamRobotov.add(0, this);Vrstva.vlož(0, index);}
zoznamZmenený2 = zoznamZmenený1 = true;
if (viditeľný) automatickéPrekreslenie();}public void vyššie(){
if (zoznamRobotov.size() <= 1) return;
int indexOf = zoznamRobotov.indexOf(this);
if (-1 == indexOf || indexOf + 1 >=zoznamRobotov.size()) return;synchronized (zámokUdalostí){
GRobot r = zoznamRobotov.get(indexOf + 1);
Vrstva.vymaž(r); Vrstva.vymaž(this);zoznamRobotov.set(indexOf + 1,zoznamRobotov.get(indexOf));zoznamRobotov.set(indexOf, r);
Vrstva.vlož(r); Vrstva.vlož(this);}
zoznamZmenený2 = zoznamZmenený1 = true;
if (viditeľný) automatickéPrekreslenie();}
public void vyssie() { vyššie(); }public void nižšie(){
if (zoznamRobotov.size() <= 1) return;
int indexOf = zoznamRobotov.indexOf(this);if (indexOf - 1 <= 0) return;synchronized (zámokUdalostí){
GRobot r = zoznamRobotov.get(indexOf - 1);
Vrstva.vymaž(r); Vrstva.vymaž(this);zoznamRobotov.set(indexOf - 1,zoznamRobotov.get(indexOf));zoznamRobotov.set(indexOf, r);
Vrstva.vlož(r); Vrstva.vlož(this);}
zoznamZmenený2 = zoznamZmenený1 = true;
if (viditeľný) automatickéPrekreslenie();}
public void nizsie() { nižšie(); }
public void pred(GRobot ktorého){
if (zoznamRobotov.size() <= 1 || ktorého == this) return;synchronized (zámokUdalostí){
int index1 = zoznamRobotov.indexOf(this),
index2 = zoznamRobotov.indexOf(ktorého);
if (-1 == index2) index2 = zoznamRobotov.size() - 1;Vrstva.vymaž(index1, index2);zoznamRobotov.remove(this);
int indexOf = zoznamRobotov.indexOf(ktorého);
if (-1 == indexOf) indexOf = zoznamRobotov.size();
zoznamRobotov.add(indexOf + 1, this);Vrstva.vlož(index1, index2);}
zoznamZmenený2 = zoznamZmenený1 = true;
if (viditeľný) automatickéPrekreslenie();}
public void nad(GRobot ktorého) { pred(ktorého); }public void za(GRobot ktorého){
if (zoznamRobotov.size() <= 1 || ktorého == this) return;synchronized (zámokUdalostí){
int index1 = zoznamRobotov.indexOf(this),
index2 = zoznamRobotov.indexOf(ktorého);if (-1 == index2) index2 = 0;Vrstva.vymaž(index1, index2);zoznamRobotov.remove(this);
int indexOf = zoznamRobotov.indexOf(ktorého);
if (-1 == indexOf) indexOf = 0;
zoznamRobotov.add(indexOf, this);Vrstva.vlož(index1, index2);}
zoznamZmenený2 = zoznamZmenený1 = true;
if (viditeľný) automatickéPrekreslenie();}
public void pod(GRobot ktorého) { za(ktorého); }
public boolean somPred(GRobot ktorým){
if (this == ktorým) return false;for (GRobot r : zoznamRobotov){if (r == this) return false;if (r == ktorým) return true;}return false;}
public boolean somNad(GRobot ktorým) { return somPred(ktorým); }
public boolean jeZa(GRobot ktorý) { return somPred(ktorý); }
public boolean jePod(GRobot ktorý) { return somPred(ktorý); }
public boolean somZa(GRobot ktorým){
if (this == ktorým) return false;for (GRobot r : zoznamRobotov){if (r == this) return true;if (r == ktorým) return false;}return false;}
public boolean somPod(GRobot ktorým) { return somZa(ktorým); }
public boolean jePred(GRobot ktorý) { return somZa(ktorý); }
public boolean jeNad(GRobot ktorý) { return somZa(ktorý); }
public void spojnica(GRobot cieľ){
if (null == cieľ || this == cieľ) return;for (Spojnica s : spojnice){if (s.cieľ == cieľ){s.farba = farbaPera;s.čiara = čiara;automatickéPrekreslenie();return;}}
spojnice.add(new Spojnica(farbaPera, čiara, cieľ));automatickéPrekreslenie();}
public void spojnica(GRobot cieľ, double hrúbka){
if (null == cieľ || this == cieľ) return;
if (hrúbka < 0) throw new RuntimeException("Hrúbka čiary nesmie byť záporná!");
BasicStroke čiara = new BasicStroke((float)hrúbka,
BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);for (Spojnica s : spojnice){if (s.cieľ == cieľ){s.farba = farbaPera;s.čiara = čiara;automatickéPrekreslenie();return;}}
spojnice.add(new Spojnica(farbaPera, čiara, cieľ));automatickéPrekreslenie();}
public void spojnica(GRobot cieľ, Color farba){
if (null == cieľ || this == cieľ) return;for (Spojnica s : spojnice){if (s.cieľ == cieľ){if (farba instanceof Farba)s.farba = (Farba)farba;else s.farba = new Farba(farba);s.čiara = čiara;automatickéPrekreslenie();return;}}
spojnice.add(new Spojnica(farba, čiara, cieľ));automatickéPrekreslenie();}
public void spojnica(GRobot cieľ, double hrúbka, Color farba){
if (null == cieľ || this == cieľ) return;
if (hrúbka < 0) throw new RuntimeException("Hrúbka čiary nesmie byť záporná!");
BasicStroke čiara = new BasicStroke((float)hrúbka,
BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);for (Spojnica s : spojnice){if (s.cieľ == cieľ){if (farba instanceof Farba)s.farba = (Farba)farba;else s.farba = new Farba(farba);s.čiara = čiara;automatickéPrekreslenie();return;}}
spojnice.add(new Spojnica(farba, čiara, cieľ));automatickéPrekreslenie();}
public void spojnica(GRobot cieľ, Farebnosť objekt){
if (null == cieľ || this == cieľ) return;for (Spojnica s : spojnice){if (s.cieľ == cieľ){s.farba = objekt.farba();s.čiara = čiara;automatickéPrekreslenie();return;}}
spojnice.add(new Spojnica(objekt.farba(), čiara, cieľ));automatickéPrekreslenie();}
public void spojnica(GRobot cieľ, double hrúbka, Farebnosť objekt){
if (null == cieľ || this == cieľ) return;
if (hrúbka < 0) throw new RuntimeException("Hrúbka čiary nesmie byť záporná!");
BasicStroke čiara = new BasicStroke((float)hrúbka,
BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);for (Spojnica s : spojnice){if (s.cieľ == cieľ){s.farba = objekt.farba();s.čiara = čiara;automatickéPrekreslenie();return;}}
spojnice.add(new Spojnica(objekt.farba(), čiara, cieľ));automatickéPrekreslenie();}
public void kopírujSpojnice(GRobot odKtorého){
for (GRobot partner : zoznamRobotov){
for (int i = 0; i < partner.spojnice.size(); ++i){
Spojnica s = partner.spojnice.get(i);if (s.cieľ == odKtorého)
partner.spojnica(this, s.čiara.getLineWidth(), s.farba);}}
for (Spojnica s : odKtorého.spojnice)
spojnica(s.cieľ, s.čiara.getLineWidth(), s.farba);automatickéPrekreslenie();}
public void kopirujSpojnice(GRobot odKtorého)
{ kopírujSpojnice(odKtorého); }public void zrušSpojnice(){
for (GRobot partner : zoznamRobotov){
for (int i = 0; i < partner.spojnice.size(); ++i){
Spojnica s = partner.spojnice.get(i);
if (s.cieľ == this) partner.spojnice.remove(i--);}}spojnice.clear();automatickéPrekreslenie();}
public void zrusSpojnice() { zrušSpojnice(); }
public void zrušSpojnicu(GRobot cieľ){Spojnica naZrušenie = null;for (Spojnica s : spojnice){if (s.cieľ == cieľ){naZrušenie = s;break;}}if (null != naZrušenie){spojnice.remove(naZrušenie);automatickéPrekreslenie();}}
public void zrusSpojnicu(GRobot cieľ) { zrušSpojnicu(cieľ); }
public boolean jeSpojnica(GRobot cieľ){for (Spojnica s : spojnice)
if (s.cieľ == cieľ) return true;return false;}
public boolean máSpojnicu(GRobot cieľ) { return jeSpojnica(cieľ); }
public boolean maSpojnicu(GRobot cieľ) { return jeSpojnica(cieľ); }
public double veľkosť() { return veľkosť; }
public double velkost() { return veľkosť; }
public double rozmer() { return veľkosť; }
public void veľkosť(double veľkosť){this.veľkosť = veľkosť;
if (viditeľný) automatickéPrekreslenie();}
public void velkost(double veľkosť) { veľkosť(veľkosť); }
public void rozmer(double veľkosť) { veľkosť(veľkosť); }
public Oblasť kolíznaOblasť() { return kolíznaOblasť; }
public Oblasť koliznaOblast() { return kolíznaOblasť; }
public void kolíznaOblasť(Oblasť kolíznaOblasť)
{ this.kolíznaOblasť = kolíznaOblasť; }
public void koliznaOblast(Oblasť kolíznaOblasť)
{ this.kolíznaOblasť = kolíznaOblasť; }
public boolean koliduje(GRobot iný){
if (null == kolíznaOblasť && null == iný.kolíznaOblasť){
final double Σr = veľkosť + iný.veľkosť;
final double Δx = iný.aktuálneX - aktuálneX;
final double Δy = iný.aktuálneY - aktuálneY;
return Σr * Σr >= (Δx * Δx + Δy * Δy);}
Area a = (null == kolíznaOblasť) ?new Area(new Ellipse2D.Double(
prepočítajX(aktuálneX) - veľkosť,
prepočítajY(aktuálneY) - veľkosť,
2 * veľkosť, 2 * veľkosť)) : kolíznaOblasť;
Area b = (null == iný.kolíznaOblasť) ?new Area(new Ellipse2D.Double(
prepočítajX(iný.aktuálneX) - iný.veľkosť,
prepočítajY(iný.aktuálneY) - iný.veľkosť,
2 * iný.veľkosť, 2 * iný.veľkosť)) : iný.kolíznaOblasť;
if (a.getBounds().intersects(b.getBounds())){Area union = new Area(a);union.intersect(b);return !union.isEmpty();}return false;}public double vzdialenosť(){
return Math.hypot(aktuálneX, aktuálneY);}
public double vzdialenost() { return vzdialenosť(); }
public double vzdialenosťOd(double súradnicaBoduX, double súradnicaBoduY){
return Math.hypot(súradnicaBoduX - aktuálneX,súradnicaBoduY - aktuálneY);}
public double vzdialenostOd(double súradnicaBoduX, double súradnicaBoduY)
{ return vzdialenosťOd(súradnicaBoduX, súradnicaBoduY); }
public double vzdialenosťK(double súradnicaBoduX, double súradnicaBoduY){
return Math.hypot(súradnicaBoduX - aktuálneX,súradnicaBoduY - aktuálneY);}
public double vzdialenostK(double súradnicaBoduX, double súradnicaBoduY)
{ return vzdialenosťK(súradnicaBoduX, súradnicaBoduY); }
public double vzdialenosťOd(Point2D bod){
return Math.hypot(bod.getX() - aktuálneX,bod.getY() - aktuálneY);}
public double vzdialenostOd(Point2D bod)
{ return vzdialenosťOd(bod.getX(), bod.getY()); }
public double vzdialenosťK(Point2D bod){
return Math.hypot(bod.getX() - aktuálneX,bod.getY() - aktuálneY);}
public double vzdialenostK(Point2D bod)
{ return vzdialenosťK(bod.getX(), bod.getY()); }
public double vzdialenosťOd(Poloha objekt){
return Math.hypot(objekt.polohaX() - aktuálneX,objekt.polohaY() - aktuálneY);}
public double vzdialenostOd(Poloha objekt) { return vzdialenosťOd(objekt); }
public double vzdialenosťK(Poloha objekt){
return Math.hypot(objekt.polohaX() - aktuálneX,objekt.polohaY() - aktuálneY);}
public double vzdialenostK(Poloha objekt) { return vzdialenosťK(objekt); }
public double vzdialenosťOd(Shape tvar){
Rectangle2D hranice = tvar.getBounds2D();return Math.hypot(
(prepočítajSpäťX(hranice.getX()) +
hranice.getWidth() / 2) - aktuálneX,
(prepočítajSpäťY(hranice.getY()) -
hranice.getHeight() / 2) - aktuálneY);}
public double vzdialenostOd(Shape tvar) { return vzdialenosťOd(tvar); }
public double vzdialenosťK(Shape tvar){
Rectangle2D hranice = tvar.getBounds2D();return Math.hypot(
(prepočítajSpäťX(hranice.getX()) +
hranice.getWidth() / 2) - aktuálneX,
(prepočítajSpäťY(hranice.getY()) -
hranice.getHeight() / 2) - aktuálneY);}
public double vzdialenostK(Shape tvar) { return vzdialenosťK(tvar); }
public double vzdialenosťOdMyši(){
return Math.hypot(súradnicaMyšiX - aktuálneX,súradnicaMyšiY - aktuálneY);}
public double vzdialenostOdMysi() { return vzdialenosťOdMyši(); }
public double vzdialenosťKMyši(){
return Math.hypot(súradnicaMyšiX - aktuálneX,súradnicaMyšiY - aktuálneY);}
public double vzdialenostKMysi() { return vzdialenosťKMyši(); }public void kresliTvar() {}public void predvolenýTvar(){vlastnýTvarObrázok = null;try{
if (getClass().getMethod("kresliTvar").getDeclaringClass().
equals(GRobot.class)) vlastnýTvarKreslenie = null;else
vlastnýTvarKreslenie = použiPrekrytúMetóduKresli;}
catch (Exception e) { vypíšChybovéHlásenia(e); }this.vyplnený = true;automatickéPrekreslenie();}
public void predvolenyTvar() { predvolenýTvar(); }
public void predvolenýTvar(boolean vyplnený){vlastnýTvarObrázok = null;try{
if (getClass().getMethod("kresliTvar").getDeclaringClass().
equals(GRobot.class)) vlastnýTvarKreslenie = null;else
vlastnýTvarKreslenie = použiPrekrytúMetóduKresli;}
catch (Exception e) { vypíšChybovéHlásenia(e); }this.vyplnený = vyplnený;automatickéPrekreslenie();}
public void predvolenyTvar(boolean vyplnený){ predvolenýTvar(vyplnený); }
public void vlastnýTvar(String súbor){
if (null != vlastnýTvarKreslenie)vlastnýTvarKreslenie = null;
vlastnýTvarObrázok = súborNaObrázok(súbor);automatickéPrekreslenie();}
public void vlastnyTvar(String súbor) { vlastnýTvar(súbor); }
public void vlastnýTvar(Image obrázok){
if (null != vlastnýTvarKreslenie)vlastnýTvarKreslenie = null;vlastnýTvarObrázok = obrázok;automatickéPrekreslenie();}
public void vlastnyTvar(Image obrázok) { vlastnýTvar(obrázok); }public interface VlastnýTvar{public void kresli(GRobot r);}
public interface VlastnyTvar extends VlastnýTvar {}
public void vlastnýTvar(VlastnýTvar tvar){
if (null != vlastnýTvarObrázok)vlastnýTvarObrázok = null;vlastnýTvarKreslenie = tvar;automatickéPrekreslenie();}
public void vlastnyTvar(VlastnýTvar tvar) { vlastnýTvar(tvar); }public void kresliTvary(){uvoľni();kresliTvary = true;}
public void kresliÚtvary() { kresliTvary(); }
public void kresliUtvary() { kresliTvary(); }public void nekresliTvary(){uvoľni();kresliTvary = false;}
public void nekresliÚtvary() { nekresliTvary(); }
public void nekresliUtvary() { nekresliTvary(); }
public boolean kreslenieTvarovPovolené() { return kresliTvary; }
public boolean kreslenieTvarovPovolene() { return kresliTvary; }public void kresliVšade(){
grafikaAktívnehoPlátna.setClip(null);}
public void kresliVsade() { kresliVšade(); }
public void kresliDo(Shape tvar){if (null == tvar) return;
grafikaAktívnehoPlátna.clip(tvar);}
public void nekresliDo(Shape tvar){if (null == tvar) return;
Shape clip = grafikaAktívnehoPlátna.getClip();
if (null == clip) clip = new Rectangle.
Double(0, 0, šírkaPlátna, výškaPlátna);Area oblasťA = new Area(clip);Area oblasťB = new Area(tvar);oblasťA.subtract(oblasťB);
grafikaAktívnehoPlátna.setClip(oblasťA);}
public static class Svet extends JFrame{private Svet() { super(); }
public static int verzia(int hlavná, int vedľajšia){
return (majorVersion * 100 + minorVersion) - (hlavná * 100 + vedľajšia);}
public static GRobot hlavnýRobot() { return hlavnýRobot; }
public static GRobot hlavnyRobot() { return hlavnýRobot; }
public static void vyzviRobotov(){if (zámokZoznamuRobotov2){
System.err.println("Zdvojená " +"výzva bola zamietnutá!");}else{zámokZoznamuRobotov2 = true;boolean reštart;do {zoznamZmenený2 = false;reštart = false;
for (GRobot tento : zoznamRobotov){tento.prijatieVýzvy(null, -1);tento.prijatieVyzvy(null, -1);if (zoznamZmenený2){reštart = true;break;}}} while (reštart);zámokZoznamuRobotov2 = false;zlúčiťZoznamy();}}
public static void vyzviRobotov(int kľúč){if (zámokZoznamuRobotov2){
System.err.println("Zdvojená " +"výzva bola zamietnutá!");}else{zámokZoznamuRobotov2 = true;boolean reštart;do {zoznamZmenený2 = false;reštart = false;
for (GRobot tento : zoznamRobotov){
tento.prijatieVýzvy(null, kľúč);
tento.prijatieVyzvy(null, kľúč);if (zoznamZmenený2){reštart = true;break;}}} while (reštart);zámokZoznamuRobotov2 = false;zlúčiťZoznamy();}}
public static void vyzviRobotov(int kľúč, boolean obrátene){if (zámokZoznamuRobotov2){
System.err.println("Zdvojená " +"výzva bola zamietnutá!");}else{zámokZoznamuRobotov2 = true;if (obrátene){boolean reštart;do {zoznamZmenený2 = false;reštart = false;
for (int i = zoznamRobotov.size() - 1; i >= 0; --i){
GRobot tento = zoznamRobotov.get(i);
tento.prijatieVýzvy(null, kľúč);
tento.prijatieVyzvy(null, kľúč);if (zoznamZmenený2){reštart = true;break;}}} while (reštart);}else{boolean reštart;do {zoznamZmenený2 = false;reštart = false;
for (GRobot tento : zoznamRobotov){
tento.prijatieVýzvy(null, kľúč);
tento.prijatieVyzvy(null, kľúč);if (zoznamZmenený2){reštart = true;break;}}} while (reštart);}zámokZoznamuRobotov2 = false;zlúčiťZoznamy();}}
public static double najmenšieX() { return -šírkaPlátna / 2; }
public static double najmensieX() { return -šírkaPlátna / 2; }
public static double najmenšieY() { return -(výškaPlátna - 1) / 2; }
public static double najmensieY() { return -(výškaPlátna - 1) / 2; }
public static double najväčšieX() { return (šírkaPlátna - 1) / 2; }
public static double najvacsieX() { return (šírkaPlátna - 1) / 2; }
public static double najväčšieY() { return výškaPlátna / 2; }
public static double najvacsieY() { return výškaPlátna / 2; }
public static double ľavýOkraj(){
int súradnica = -hlavnýPanel.getWidth() / 2;
if (súradnica < (-šírkaPlátna / 2))return -šírkaPlátna / 2;return súradnica;}
public static double lavyOkraj() { return ľavýOkraj(); }
public static double spodnýOkraj(){
int súradnica = -(hlavnýPanel.getHeight() - 1) / 2;
if (súradnica < (-(výškaPlátna - 1) / 2))return -(výškaPlátna - 1) / 2;return súradnica;}
public static double spodnyOkraj() { return spodnýOkraj(); }
public static double dolnýOkraj() { return spodnýOkraj(); }
public static double dolnyOkraj() { return spodnýOkraj(); }
public static double pravýOkraj(){
int súradnica = (hlavnýPanel.getWidth() - 1) / 2;
if (súradnica > ((šírkaPlátna - 1) / 2))return (šírkaPlátna - 1) / 2;return súradnica;}
public static double pravyOkraj() { return pravýOkraj(); }
public static double vrchnýOkraj(){
int súradnica = hlavnýPanel.getHeight() / 2;
if (súradnica > (výškaPlátna / 2))return výškaPlátna / 2;return súradnica;}
public static double vrchnyOkraj() { return vrchnýOkraj(); }
public static double hornýOkraj() { return vrchnýOkraj(); }
public static double hornyOkraj() { return vrchnýOkraj(); }
public static boolean viditeľný(){
if (null == svet) return zobrazPriŠtarte;return svet.isVisible();}
public static boolean viditelny() { return viditeľný(); }
public static boolean zobrazený(){
if (null == svet) return zobrazPriŠtarte;return svet.isVisible();}
public static boolean zobrazeny() { return zobrazený(); }public static void skry(){zobrazPriŠtarte = false;if (null != svet)svet.setVisible(false);}public static void zobraz(){zobrazPriŠtarte = true;if (null != svet)svet.setVisible(true);}
public static void upevni() { svet.setResizable(false); }
public static void uvoľni() { svet.setResizable(true); }
public static void uvolni() { svet.setResizable(true); }
public static void zbaľ() { svet.pack(); }
public static void zbal() { svet.pack(); }
public static double vzdialenosť(double súradnicaBoduX, double súradnicaBoduY){
return Math.hypot(súradnicaBoduX, súradnicaBoduY);}
public static double vzdialenost(double súradnicaBoduX, double súradnicaBoduY)
{ return vzdialenosť(súradnicaBoduX, súradnicaBoduY); }
public static double vzdialenosť(Point2D bod){
return Math.hypot(bod.getX(), bod.getY());}
public static double vzdialenost(Point2D bod)
{ return vzdialenosť(bod.getX(), bod.getY()); }
public static double vzdialenosť(Poloha objekt){
return Math.hypot(objekt.polohaX(), objekt.polohaY());}
public static double vzdialenost(Poloha objekt) { return vzdialenosť(objekt); }
public static double vzdialenosť(Shape tvar){
Rectangle2D hranice = tvar.getBounds2D();return Math.hypot(
(prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2),
(prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2));}
public static double vzdialenost(Shape tvar) { return vzdialenosť(tvar); }
public static void vymaž() { podlaha.vymaž(); strop.vymaž(); }
public static void vymaz() { podlaha.vymaž(); strop.vymaž(); }
public static void vymažTexty() { podlaha.vymažTexty(); strop.vymažTexty(); }
public static void vymazTexty() { podlaha.vymažTexty(); strop.vymažTexty(); }
public static void vymažGrafiku() { podlaha.vymažGrafiku(); strop.vymažGrafiku(); }
public static void vymazGrafiku() { podlaha.vymažGrafiku(); strop.vymažGrafiku(); }
public static void povoľViacnásobnúObsluhuUdalostí()
{ viacnásobnáObsluhuUdalostíUmožnená = true; }
public static void povolViacnasobnuObsluhuUdalosti()
{ viacnásobnáObsluhuUdalostíUmožnená = true; }
public static void presmerujObsluhuUdalostí(ObsluhaUdalostí obsluha){ počúvadlo = obsluha; }
public static void presmerujObsluhuUdalosti(ObsluhaUdalostí obsluha){ počúvadlo = obsluha; }
public static void vyplň(Color farba) { podlaha.vyplň(farba); }
public static void vypln(Color farba) { vyplň(farba); }
public static void vyplň(Farebnosť objekt) { podlaha.vyplň(objekt); }
public static void vypln(Farebnosť objekt) { vyplň(objekt); }
public static Farba vyplň(int r, int g, int b)
{ return podlaha.vyplň(r, g, b); }
public static Farba vypln(int r, int g, int b)
{ return podlaha.vyplň(r, g, b); }
public static Farba vyplň(int r, int g, int b, int a)
{ return podlaha.vyplň(r, g, b, a); }
public Farba vypln(int r, int g, int b, int a)
{ return podlaha.vyplň(r, g, b, a); }
public static void vyplň(String súbor) { podlaha.vyplň(súbor); }
public static void vypln(String súbor) { podlaha.vyplň(súbor); }
public static void vyplň(BufferedImage obrázok){ podlaha.vyplň(obrázok); }
public static void vypln(BufferedImage obrázok){ podlaha.vyplň(obrázok); }
public static void priehľadnosť(double prePodlahu, double preStrop){
podlaha.priehľadnosť(prePodlahu);strop.priehľadnosť(preStrop);}
public static void priehladnost(double prePodlahu, double preStrop)
{ priehľadnosť(prePodlahu, preStrop); }
public static void upravPriehľadnosť(double prePodlahu, double preStrop){
podlaha.upravPriehľadnosť(prePodlahu);
strop.upravPriehľadnosť(preStrop);}
public static void upravPriehladnost(double prePodlahu, double preStrop)
{ upravPriehľadnosť(prePodlahu, preStrop); }
public static void nekresli() { nekresli = true; }public static void kresli(){nekresli = false;prekresli();}public static void prekresli(){if (pracujem){
žiadamPrekresleniePoPráci = true;return;}if (právePrekresľujem) return;právePrekresľujem = true;try{if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.prekreslenie();}
vyrovnávaciaPamäťGrafiky.setColor(farbaPozadia);
vyrovnávaciaPamäťGrafiky.fillRect(0, 0,šírkaPlátna, výškaPlátna);
podlaha.prekresli(vyrovnávaciaPamäťGrafiky);
for (GRobot tento : zoznamRobotov){if (tento.viditeľný)
tento.kresliSpojnice(vyrovnávaciaPamäťGrafiky);}
for (Map.Entry<Integer, Vrstva> záznamVrstvy :zoznamVrstiev.entrySet()){
Vrstva vrstva = záznamVrstvy.getValue();
for (Map.Entry<Integer, GRobot>
záznamRobota : vrstva.entrySet()){
GRobot tento = záznamRobota.getValue();if (tento.viditeľný)
tento.kresliRobota(vyrovnávaciaPamäťGrafiky);}}
for (GRobot tento : zoznamRobotov){if (tento.kresliPôsobisko)
tento.kresliPôsobisko(vyrovnávaciaPamäťGrafiky);}
strop.prekresli(vyrovnávaciaPamäťGrafiky);
grafika.drawImage(vyrovnávaciaPamäťObrázka, 0, 0, null);if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.dokreslenie();}svet.repaint();}
catch (Exception e) { vypíšChybovéHlásenia(e, false); } finally{právePrekresľujem = false;}}
public static void vymažPonuku(){if (!inicializované) return;
JMenuBar hlavnáPonuka = svet.getJMenuBar();for (;;){JMenu položkaHlavnejPonuky =
hlavnáPonuka.getMenu(aktuálnaPonuka);
if (null != položkaHlavnejPonuky){ponukaVPôvodnomStave = false;
položkaHlavnejPonuky.removeAll();}if (aktuálnaPonuka > 0){
hlavnáPonuka.remove(aktuálnaPonuka);--aktuálnaPonuka;}else break;}aktuálnaPoložka = 0;
hlavnáPonuka.setVisible(false);}
public static void vymazPonuku() { vymažPonuku(); }
public static void pridajPoložkuHlavnejPonuky(String text){if (!inicializované) return;
JMenuBar hlavnáPonuka = svet.getJMenuBar();
JMenu položkaHlavnejPonuky = hlavnáPonuka.getMenu(aktuálnaPonuka);hlavnáPonuka.setVisible(true);
if (0 == položkaHlavnejPonuky.getItemCount()){
položkaHlavnejPonuky.setText(text);}else{
položkaHlavnejPonuky = new JMenu(text);
hlavnáPonuka.add(položkaHlavnejPonuky);
++aktuálnaPonuka; aktuálnaPoložka = 0;}}
public static void pridajPolozkuHlavnejPonuky(String text)
{ pridajPoložkuHlavnejPonuky(text); }
public static void pridajPoložkuHlavnejPonuky(String text, int mnemonickáSkratka){if (!inicializované) return;
JMenuBar hlavnáPonuka = svet.getJMenuBar();
JMenu položkaHlavnejPonuky = hlavnáPonuka.getMenu(aktuálnaPonuka);hlavnáPonuka.setVisible(true);
if (0 == položkaHlavnejPonuky.getItemCount()){
položkaHlavnejPonuky.setText(text);
položkaHlavnejPonuky.setMnemonic(mnemonickáSkratka);}else{
položkaHlavnejPonuky = new JMenu(text);
položkaHlavnejPonuky.setMnemonic(mnemonickáSkratka);
hlavnáPonuka.add(položkaHlavnejPonuky);
++aktuálnaPonuka; aktuálnaPoložka = 0;}}
public static void pridajPolozkuHlavnejPonuky(String text, int mnemonickáSkratka)
{ pridajPoložkuHlavnejPonuky(text, mnemonickáSkratka); }
public static PoložkaPonuky pridajPoložkuPonuky(String text){if (!inicializované|| null == svet.getJMenuBar().
getMenu(aktuálnaPonuka)) return null;
return new PoložkaPonuky(text);}
public static PolozkaPonuky pridajPolozkuPonuky(String text){if (!inicializované|| null == svet.getJMenuBar().
getMenu(aktuálnaPonuka)) return null;
return new PolozkaPonuky(text);}
public static PoložkaPonuky pridajPoložkuPonuky(String text, int mnemonickáSkratka){if (!inicializované|| null == svet.getJMenuBar().
getMenu(aktuálnaPonuka)) return null;
return new PoložkaPonuky(text, mnemonickáSkratka);}
public static PolozkaPonuky pridajPolozkuPonuky(String text, int mnemonickáSkratka){if (!inicializované|| null == svet.getJMenuBar().
getMenu(aktuálnaPonuka)) return null;
return new PolozkaPonuky(text, mnemonickáSkratka);}
public static PoložkaPonuky pridajPoložkuPonuky(String text, int mnemonickáSkratka, int klávesováSkratka){if (!inicializované|| null == svet.getJMenuBar().
getMenu(aktuálnaPonuka)) return null;
return new PoložkaPonuky(text, mnemonickáSkratka, klávesováSkratka);}
public static PolozkaPonuky pridajPolozkuPonuky(String text, int mnemonickáSkratka, int klávesováSkratka){if (!inicializované|| null == svet.getJMenuBar().
getMenu(aktuálnaPonuka)) return null;
return new PolozkaPonuky(text, mnemonickáSkratka, klávesováSkratka);}
public static void pridajOddeľovačPonuky(){if (!inicializované) return;
JMenu položkaHlavnejPonuky = svet.
getJMenuBar().getMenu(aktuálnaPonuka);
if (null != položkaHlavnejPonuky){ponukaVPôvodnomStave = false;
položkaHlavnejPonuky.insertSeparator(aktuálnaPoložka++);}}
public static void pridajOddelovacPonuky() { pridajOddeľovačPonuky(); }
public static void pridajPoložkuPonukyVymazať(){
JMenuBar hlavnáPonuka = svet.getJMenuBar();if (inicializované&& null != hlavnáPonuka){JMenu položkaHlavnejPonuky =
hlavnáPonuka.getMenu(aktuálnaPonuka);
if (null != položkaHlavnejPonuky){položkaHlavnejPonuky.insert(položkaPonukyVymazať(),aktuálnaPoložka++);if (!hlavnáPonuka.isVisible())hlavnáPonuka.setVisible(true);}}}
public static void pridajPolozkuPonukyVymazat()
{ pridajPoložkuPonukyVymazať(); }
public static void pridajPoložkuPonukyPrekresliť(){
JMenuBar hlavnáPonuka = svet.getJMenuBar();if (inicializované&& null != hlavnáPonuka){JMenu položkaHlavnejPonuky =
hlavnáPonuka.getMenu(aktuálnaPonuka);
if (null != položkaHlavnejPonuky){položkaHlavnejPonuky.insert(položkaPonukyPrekresliť(),aktuálnaPoložka++);if (!hlavnáPonuka.isVisible())hlavnáPonuka.setVisible(true);}}}
public static void pridajPolozkuPonukyPrekreslit()
{ pridajPoložkuPonukyPrekresliť(); }
public static void pridajPoložkuPonukyKoniec(){
if (ponukaVPôvodnomStave) return;
JMenuBar hlavnáPonuka = svet.getJMenuBar();if (inicializované&& null != hlavnáPonuka){JMenu položkaHlavnejPonuky =
hlavnáPonuka.getMenu(aktuálnaPonuka);
if (null != položkaHlavnejPonuky){
položkaHlavnejPonuky.insert(položkaSkončiť,aktuálnaPoložka++);if (!hlavnáPonuka.isVisible())hlavnáPonuka.setVisible(true);}}}
public static void pridajPolozkuPonukyKoniec()
{ pridajPoložkuPonukyKoniec(); }
public static PoložkaPonuky položkaPonukyVymazať(){if (null == položkaVymazať)
položkaVymazať = new PoložkaPonuky("Vymazať",KeyEvent.VK_O, KeyEvent.VK_R);return položkaVymazať;}
public static PoložkaPonuky polozkaPonukyVymazat()
{ return položkaPonukyVymazať(); }
public static PoložkaPonuky položkaPonukyPrekresliť(){if (null == položkaPrekresliť)
položkaPrekresliť = new PoložkaPonuky("Prekresliť",KeyEvent.VK_O, KeyEvent.VK_R);return položkaPrekresliť;}
public static PoložkaPonuky polozkaPonukyPrekreslit()
{ return položkaPonukyPrekresliť(); }
public static PoložkaPonuky položkaPonukyKoniec(){ return položkaSkončiť; }
public static PoložkaPonuky polozkaPonukyKoniec()
{ return položkaPonukyKoniec(); }
public static PoložkaPonuky poslednáPoložkaPonuky() { return poslednáPoložkaPonuky; }
public static PolozkaPonuky poslednaPolozkaPonuky() { return (PolozkaPonuky)poslednáPoložkaPonuky; }
public static KontextováPoložka poslednáKontextováPoložka() { return poslednáKontextováPoložka; }
public static KontextovaPolozka poslednaKontextovaPolozka() { return (KontextovaPolozka)poslednáKontextováPoložka; }
public static String[] textNaRiadky(String text, int dĺžkaRiadka){
if (text == null || dĺžkaRiadka <= 0 ||text.length() <= dĺžkaRiadka)return new String[] {text};
StringBuffer naZmeny = new StringBuffer(text);
Vector<String> zoznam = new Vector<String>();int j;
while (-1 != (j = naZmeny.indexOf("\t")))naZmeny.setCharAt(j, ' ');while (naZmeny.length() > 0){
if (-1 != (j = naZmeny.indexOf("\n")) && j <= dĺžkaRiadka){int i = j;
if (i >= 0) zoznam.add(naZmeny.substring(0, i));naZmeny.delete(0, j + 1);continue;}
if (naZmeny.length() <= dĺžkaRiadka){
zoznam.add(naZmeny.toString());break;}int i = dĺžkaRiadka;
while (i > 0 && naZmeny.charAt(i - 1) != 32) --i;if (i == 0) i = dĺžkaRiadka;
zoznam.add(naZmeny.substring(0, i));naZmeny.delete(0, i);}
String riadky[] = new String[zoznam.size()];
for (int i = 0; i < zoznam.size(); i++) riadky[i] = zoznam.get(i);return riadky;}
public static String[] textNaRiadky(String text, int dĺžkaRiadka, boolean zachovajMedzery){
if (zachovajMedzery) return textNaRiadky(text, dĺžkaRiadka);
if (text == null || dĺžkaRiadka <= 0 ||text.length() <= dĺžkaRiadka)return new String[] {text};
StringBuffer naZmeny = new StringBuffer(text);
Vector<String> zoznam = new Vector<String>();int j;
while (-1 != (j = naZmeny.indexOf("\t")))naZmeny.setCharAt(j, ' ');{int i = naZmeny.length();
while (i > 0 && naZmeny.charAt(i - 1) == 32) --i;naZmeny.setLength(i);i = 0;
while (i < naZmeny.length() && naZmeny.charAt(i) == 32) ++i;naZmeny.delete(0, i);
while (-1 != (i = naZmeny.indexOf("  "))) naZmeny.deleteCharAt(i);}while (naZmeny.length() > 0){{int i = 0;
while (i < naZmeny.length() && naZmeny.charAt(i) == 32) ++i;naZmeny.delete(0, i);}
if (-1 != (j = naZmeny.indexOf("\n")) && j <= dĺžkaRiadka){int i = j;
while (i > 0 && naZmeny.charAt(i - 1) == 32) --i;
if (i >= 0) zoznam.add(naZmeny.substring(0, i));naZmeny.delete(0, j + 1);continue;}
if (naZmeny.length() <= dĺžkaRiadka){
zoznam.add(naZmeny.toString());break;}int i = dĺžkaRiadka;
while (i > 0 && naZmeny.charAt(i - 1) != 32) --i;
while (i > 0 && naZmeny.charAt(i - 1) == 32) --i;if (i == 0) i = dĺžkaRiadka;
zoznam.add(naZmeny.substring(0, i));naZmeny.delete(0, i);}
String riadky[] = new String[zoznam.size()];
for (int i = 0; i < zoznam.size(); i++) riadky[i] = zoznam.get(i);return riadky;}
public static void ikona(String súbor)
{ svet.setIconImage(súborNaObrázok(súbor)); }
public static void novýKurzorMyši(BufferedImage
obrázok, int x, int y, String meno){if (null == meno) return;for (Cursor c : kurzory)if (c.getName().equals(meno))
throw new RuntimeException("Kurzor so zadaným menom už jestvuje.");
Dimension veľkosť = Toolkit.getDefaultToolkit().
getBestCursorSize(obrázok.getWidth(), obrázok.getHeight());x = (veľkosť.width / 2) + x;y = (veľkosť.height / 2) - y;
if (x < 0) x = 0; if (y < 0) y = 0;
if (x >= veľkosť.width) x = veľkosť.width - 1;
if (y >= veľkosť.height) y = veľkosť.height - 1;
kurzory.add(Toolkit.getDefaultToolkit().createCustomCursor(
obrázok, new Point(x, y), meno));}
public static void novyKurzorMysi(BufferedImage obrázok, int x, int y, String meno) { novýKurzorMyši(obrázok, x, y, meno); }
public static void novýKurzorMyši(BufferedImage obrázok, double x, double y, String meno) { novýKurzorMyši(obrázok, (int)x, (int)y, meno); }
public static void novyKurzorMysi(BufferedImage obrázok, double x, double y, String meno) { novýKurzorMyši(obrázok, (int)x, (int)y, meno); }
public static void zmeňKurzorMyši(String meno){if (null == meno){
svet.getContentPane().setCursor(prázdnyKurzor);return;}for (Cursor c : kurzory)if (c.getName().equals(meno)){
svet.getContentPane().setCursor(c);return;}int i = 0;
for (String s : anglickéNázvyKurzorov){if (s.equals(meno)){
svet.getContentPane().setCursor(
Cursor.getPredefinedCursor(i));return;}++i;}i = 0;
for (String s : slovenskéNázvyKurzorov){if (s.equals(meno)){
svet.getContentPane().setCursor(
Cursor.getPredefinedCursor(i));return;}++i;}
throw new RuntimeException("Kurzor so zadaným menom nejestvuje.");}
public static void zmenKurzorMysi(String meno) { zmeňKurzorMyši(meno); }
public static void zmeňNovýKurzorMyši(
BufferedImage obrázok, int x, int y, String meno){
novýKurzorMyši(obrázok, x, y, meno);zmeňKurzorMyši(meno);}
public static void zmenNovyKurzorMysi(BufferedImage obrázok, int x, int y, String meno) { zmeňNovýKurzorMyši(obrázok, x, y, meno); }
public static void zmeňNovýKurzorMyši(BufferedImage obrázok, double x, double y, String meno) { zmeňNovýKurzorMyši(obrázok, (int)x, (int)y, meno); }
public static void zmenNovyKurzorMysi(BufferedImage obrázok, double x, double y, String meno) { zmeňNovýKurzorMyši(obrázok, (int)x, (int)y, meno); }
public static void koniec() { System.exit(0); }
public static void koniec(int kód) { System.exit(kód); }
public static Graphics2D grafika() { return grafika; }public static long údržba(){
Runtime runtime = Runtime.getRuntime();
long pred = runtime.freeMemory();runtime.gc();
long po = runtime.freeMemory();return po - pred;}
public static long udrzba() { return údržba(); }
public static void uvoľni(GRobot ktorý){
for (GRobot tento : zoznamRobotov){
for (int i = 0; i < tento.spojnice.size(); ++i){
Spojnica s = tento.spojnice.get(i);
if (s.cieľ == ktorý) tento.spojnice.remove(i--);}}
int index1 = zoznamRobotov.indexOf(ktorý),
index2 = zoznamRobotov.size() - 1;Vrstva.vymaž(index1, index2);ktorý.uvoľni();ktorý.spojnice.clear();zoznamRobotov.remove(ktorý);
záložnýZoznamRobotov.remove(ktorý);Vrstva.vlož(index1, --index2);if (ktorý == hlavnýRobot){hlavnýRobot = null;if (zoznamRobotov.size() > 0)
hlavnýRobot = zoznamRobotov.get(0);
else if (záložnýZoznamRobotov.size() > 0)
hlavnýRobot = záložnýZoznamRobotov.get(0);}}
public static void uvolni(GRobot ktorý) { uvoľni(ktorý); }
public static void uvoľni(Class typ){
Vrstva.vymaž(0, zoznamRobotov.size() - 1);
for (int i = 0; i < zoznamRobotov.size(); ++i){
GRobot ktorý = zoznamRobotov.get(i);if (typ.isInstance(ktorý)){
for (GRobot tento : zoznamRobotov){
for (int j = 0; j < tento.spojnice.size(); ++j){
Spojnica s = tento.spojnice.get(j);
if (s.cieľ == ktorý) tento.spojnice.remove(j--);}}ktorý.uvoľni();zoznamRobotov.remove(i--);
záložnýZoznamRobotov.remove(ktorý);
if (ktorý == hlavnýRobot) hlavnýRobot = null;}}
Vrstva.vlož(0, zoznamRobotov.size() - 1);if (null == hlavnýRobot){if (zoznamRobotov.size() > 0)
hlavnýRobot = zoznamRobotov.get(0);
else if (záložnýZoznamRobotov.size() > 0)
hlavnýRobot = záložnýZoznamRobotov.get(0);}}
public static void uvolni(Class typ) { uvoľni(typ); }
public static void použiKonfiguráciu(String názovSúboru){if (inicializované)throw new RuntimeException(
"Konfiguráciu nie je možné použiť. " +"Svet už bol inicializovaný");try{
konfiguračnýSúbor.otvorNaČítanie(
názovKonfiguračnéhoSúboru = názovSúboru);
počiatočnáŠírka = konfiguračnýSúbor.
čítajVlastnosť("windowWidth", 600L).intValue();
počiatočnáVýška = konfiguračnýSúbor.
čítajVlastnosť("windowHeight", 500L).intValue();
počiatočnéX = konfiguračnýSúbor.
čítajVlastnosť("windowX", 25L).intValue();
počiatočnéY = konfiguračnýSúbor.
čítajVlastnosť("windowY", 25L).intValue();}
catch (Exception e) { vypíšChybovéHlásenia(e); }
try { konfiguračnýSúbor.zavri(); }
catch (Exception e) { vypíšChybovéHlásenia(e); }}
public static void pouziKonfiguraciu(String názovSúboru)
{ použiKonfiguráciu(názovSúboru); }
public static void použiKonfiguráciu()
{ použiKonfiguráciu(predvolenýNázovKonfiguračnéhoSúboru); }
public static void pouziKonfiguraciu()
{ použiKonfiguráciu(predvolenýNázovKonfiguračnéhoSúboru); }
public static String načítajReťazec(String výzva)
{ return načítajReťazec(výzva, predvolenýTitulokVstupu); }
public static String nacitajRetazec(String výzva)
{ return načítajReťazec(výzva, predvolenýTitulokVstupu); }
public static String načítajReťazec(String výzva, String titulok){String reťazec = null;
Object[] výzvaATextovýRiadok = {výzva, textovýRiadok};textovýRiadok.setText("");
if (JOptionPane.showOptionDialog(svet, výzvaATextovýRiadok,
titulok, JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
null, predvolenéOdpovedeZadania, null)
== JOptionPane.YES_OPTION) reťazec = textovýRiadok.getText();return reťazec;}
public static String nacitajRetazec(String výzva, String titulok)
{ return načítajReťazec(výzva, titulok); }
public static String načítajHeslo(String výzva){
return načítajHeslo(výzva, predvolenýTitulokHesla);}
public static String nacitajHeslo(String výzva) { return načítajHeslo(výzva); }
public static String načítajHeslo(String výzva, String titulok){String heslo = null;
Object[] výzvaAHeslo = {výzva, riadokSHeslom};riadokSHeslom.setText("");
if (JOptionPane.showOptionDialog(svet, výzvaAHeslo, titulok,
JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null,
predvolenéOdpovedeZadania, null) ==
JOptionPane.YES_OPTION) heslo = new
String(riadokSHeslom.getPassword());return heslo;}
public static String nacitajHeslo(String výzva, String titulok)
{ return načítajHeslo(výzva, titulok); }
public static Long načítajCeléČíslo(String výzva){Long číslo = null;
String reťazec = načítajReťazec(výzva);
try { číslo = Long.valueOf(reťazec); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Long nacitajCeleCislo(String výzva) { return načítajCeléČíslo(výzva); }
public static Long načítajCeléČíslo(String výzva, String titulok){Long číslo = null;
String reťazec = načítajReťazec(výzva, titulok);
try { číslo = Long.valueOf(reťazec); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Long nacitajCeleCislo(String výzva, String titulok)
{ return načítajCeléČíslo(výzva, titulok); }
public static Double načítajReálneČíslo(String výzva){Double číslo = null;
String reťazec = načítajReťazec(výzva);
try { číslo = Double.valueOf(reťazec); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Double nacitajRealneCislo(String výzva)
{ return načítajReálneČíslo(výzva); }
public static Double načítajReálneČíslo(String výzva, String titulok){Double číslo = null;
String reťazec = načítajReťazec(výzva, titulok);
try { číslo = Double.valueOf(reťazec); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Double nacitajRealneCislo(String výzva, String titulok)
{ return načítajReálneČíslo(výzva, titulok); }
public static String upravReťazec(String reťazec, String výzva)
{ return upravReťazec(reťazec, výzva, predvolenýTitulokVstupu); }
public static String upravRetazec(String reťazec, String výzva)
{ return upravReťazec(reťazec, výzva, predvolenýTitulokVstupu); }
public static String upravReťazec(String reťazec, String výzva, String titulok){
Object[] výzvaATextovýRiadok = {výzva, textovýRiadok};
textovýRiadok.setText(reťazec);
if (JOptionPane.showOptionDialog(svet, výzvaATextovýRiadok,
titulok, JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
null, predvolenéOdpovedeZadania, null)
== JOptionPane.YES_OPTION) return textovýRiadok.getText();return null;}
public static String upravRetazec(String reťazec, String výzva, String titulok)
{ return upravReťazec(reťazec, výzva, titulok); }
public static Long upravCeléČíslo(int celéČíslo, String výzva){Long číslo = null;
String reťazec = upravReťazec(celéČíslo + "", výzva);
try { číslo = Long.valueOf(reťazec); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Long upravCeleCislo(int celéČíslo, String výzva) { return upravCeléČíslo(celéČíslo, výzva); }
public static Long upravCeléČíslo(int celéČíslo, String výzva, String titulok){Long číslo = null;
String reťazec = upravReťazec(celéČíslo + "", výzva, titulok);
try { číslo = Long.valueOf(reťazec); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Long upravCeleCislo(int celéČíslo, String výzva, String titulok)
{ return upravCeléČíslo(celéČíslo, výzva, titulok); }
public static Double upravReálneČíslo(double reálneČíslo, String výzva){Double číslo = null;
String reťazec = upravReťazec(reálneČíslo + "", výzva);
try { číslo = Double.valueOf(reťazec); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Double upravRealneCislo(double reálneČíslo, String výzva)
{ return upravReálneČíslo(reálneČíslo, výzva); }
public static Double upravReálneČíslo(double reálneČíslo, String výzva, String titulok){Double číslo = null;
String reťazec = upravReťazec(reálneČíslo + "", výzva, titulok);
try { číslo = Double.valueOf(reťazec); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Double upravRealneCislo(double reálneČíslo, String výzva, String titulok)
{ return upravReálneČíslo(reálneČíslo, výzva, titulok); }
public static void správa(String správa){
JOptionPane.showMessageDialog(svet, správa, "Správa", JOptionPane.INFORMATION_MESSAGE);}
public static void sprava(String správa) { správa(správa); }
public static void správa(String správa, String titulok){
JOptionPane.showMessageDialog(svet, správa, titulok, JOptionPane.INFORMATION_MESSAGE);}
public static void sprava(String správa, String titulok) { správa(správa, titulok); }
public static int otázka(String otázka){
return JOptionPane.showOptionDialog(svet, otázka, predvolenýTitulokOtázky, JOptionPane.YES_NO_OPTION,
JOptionPane.QUESTION_MESSAGE, null, predvolenéOdpovedeOtázky, predvolenéOdpovedeOtázky[0]);}
public static int otazka(String otázka) { return otázka(otázka); }
public static int otázka(String otázka, String titulok){
return JOptionPane.showOptionDialog(svet, otázka, titulok, JOptionPane.YES_NO_OPTION,
JOptionPane.QUESTION_MESSAGE, null, predvolenéOdpovedeOtázky, predvolenéOdpovedeOtázky[0]);}
public static int otazka(String otázka, String titulok) { return otázka(otázka, titulok); }
public static int otázka(String otázka, Object[] tlačidlá){
return JOptionPane.showOptionDialog(svet, otázka, predvolenýTitulokOtázky, JOptionPane.YES_NO_OPTION,
JOptionPane.QUESTION_MESSAGE, null, tlačidlá, tlačidlá[0]);}
public static int otazka(String otázka, Object[] tlačidlá) { return otázka(otázka, tlačidlá); }
public static int otázka(String otázka, String titulok, Object[] tlačidlá){
return JOptionPane.showOptionDialog(svet, otázka, titulok, JOptionPane.YES_NO_OPTION,
JOptionPane.QUESTION_MESSAGE, null, tlačidlá, tlačidlá[0]);}
public static int otazka(String otázka, String titulok, Object[] tlačidlá)
{ return otázka(otázka, titulok, tlačidlá); }
public static int otázka(String otázka, Object[] tlačidlá, int predvolenéTlačidlo){
return JOptionPane.showOptionDialog(svet, otázka, predvolenýTitulokOtázky, JOptionPane.YES_NO_OPTION,
JOptionPane.QUESTION_MESSAGE, null, tlačidlá, tlačidlá[predvolenéTlačidlo]);}
public static int otazka(String otázka, Object[] tlačidlá, int predvolenéTlačidlo)
{ return otázka(otázka, tlačidlá, predvolenéTlačidlo); }
public static int otázka(String otázka, String titulok, Object[] tlačidlá, int predvolenéTlačidlo){
return JOptionPane.showOptionDialog(svet, otázka, titulok, JOptionPane.YES_NO_OPTION,
JOptionPane.QUESTION_MESSAGE, null, tlačidlá, tlačidlá[predvolenéTlačidlo]);}
public static int otazka(String otázka, String titulok, Object[] tlačidlá, int predvolenéTlačidlo)
{ return otázka(otázka, titulok, tlačidlá, predvolenéTlačidlo); }
public static void zobrazÚvodnúObrazovku(Image obrázok){
final Image úvodnýObrázok = obrázok;if (null == úvodnáObrazovka){
úvodnáObrazovka = new JWindow()
{ @Override public void paint(java.awt.Graphics g)
{ g.drawImage(úvodnýObrázok, 0, 0, null); }};
úvodnáObrazovka.setBackground(new Color(0, 0, 0, 0));
com.sun.awt.AWTUtilities.setWindowOpaque(úvodnáObrazovka, false);
úvodnáObrazovka.getContentPane().setCursor(
Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));}úvodnáObrazovka.setSize(úvodnýObrázok.getWidth(null),
úvodnýObrázok.getHeight(null));
úvodnáObrazovka.setLocationRelativeTo(null);
úvodnáObrazovka.setVisible(true);skry();}
public static void zobrazUvodnuObrazovku(Image úvodnýObrázok)
{ zobrazÚvodnúObrazovku(úvodnýObrázok); }
public static void zobrazÚvodnúObrazovku(String názovSúboru)
{ zobrazÚvodnúObrazovku(súborNaObrázok(názovSúboru)); }
public static void zobrazUvodnuObrazovku(String názovSúboru)
{ zobrazÚvodnúObrazovku(názovSúboru); }
public static void skryÚvodnúObrazovku(){if (null != úvodnáObrazovka)
úvodnáObrazovka.setVisible(false);zobraz();}
public static void skryUvodnuObrazovku() { skryÚvodnúObrazovku(); }
public static boolean začniVstup(){
if (panelVstupnéhoRiadka.isVisible()) return false;
panelVstupnéhoRiadka.setVisible(true);
popisVstupnéhoRiadka.setVisible(false);vstupnýRiadok.setText("");vstupnýRiadok.requestFocus();automatickéPrekreslenie();return true;}
public static boolean zacniVstup() { return začniVstup(); }
public static boolean začniVstup(String výzva){
if (panelVstupnéhoRiadka.isVisible()) return false;
panelVstupnéhoRiadka.setVisible(true);
popisVstupnéhoRiadka.setVisible(true);
popisVstupnéhoRiadka.setText(výzva);vstupnýRiadok.setText("");vstupnýRiadok.requestFocus();automatickéPrekreslenie();return true;}
public static boolean zacniVstup(String výzva) { return začniVstup(výzva); }
public static void potvrďVstup() { GRobot.potvrďVstup(); }
public static void potvrdVstup() { GRobot.potvrďVstup(); }
public static void zrušVstup() { GRobot.zrušVstup(); }
public static void zrusVstup() { GRobot.zrušVstup(); }
public static boolean vstupnýRiadokZobrazený() { return panelVstupnéhoRiadka.isVisible(); }
public static boolean vstupnyRiadokZobrazeny() { return panelVstupnéhoRiadka.isVisible(); }
public static void neskrývajVstupnýRiadok()
{ vstupnýRiadokStáleViditeľný = true; }
public static void neskryvajVstupnyRiadok() { neskrývajVstupnýRiadok(); }
public static boolean neskrývajVstupnýRiadok(boolean začniVstup){
vstupnýRiadokStáleViditeľný = true;
if (začniVstup) return začniVstup();
return panelVstupnéhoRiadka.isVisible();}
public static boolean neskryvajVstupnyRiadok(boolean začniVstup)
{ return neskrývajVstupnýRiadok(začniVstup); }
public static void skrývajVstupnýRiadok(){
vstupnýRiadokStáleViditeľný = false;}
public static void skryvajVstupnyRiadok() { skrývajVstupnýRiadok(); }
public static void skrývajVstupnýRiadok(boolean zrušVstup){
vstupnýRiadokStáleViditeľný = false;if (zrušVstup) zrušVstup();}
public static void skryvajVstupnyRiadok(boolean zrušVstup)
{ skrývajVstupnýRiadok(zrušVstup); }
public static void aktivujVstupnýRiadok(){vstupnýRiadok.requestFocus();}
public static void aktivujVstupnyRiadok() { aktivujVstupnýRiadok(); }
public static JTextField vstupnýRiadok() { return vstupnýRiadok; }
public static JTextField vstupnyRiadok() { return vstupnýRiadok; }
public static String popisVstupnéhoRiadka(){
if (!popisVstupnéhoRiadka.isVisible()) return null;
return vstupnýRiadok.getText();}
public static String popisVstupnehoRiadka() { return popisVstupnehoRiadka(); }
public static void popisVstupnéhoRiadka(String výzva){if (null == výzva){
popisVstupnéhoRiadka.setVisible(false);}else{
popisVstupnéhoRiadka.setVisible(true);
popisVstupnéhoRiadka.setText(výzva);}}
public static void popisVstupnehoRiadka(String výzva) { popisVstupnéhoRiadka(výzva); }
public static String textVstupnéhoRiadka() { return vstupnýRiadok.getText(); }
public static String textVstupnehoRiadka() { return vstupnýRiadok.getText(); }
public static void textVstupnéhoRiadka(String text) { vstupnýRiadok.setText(text); }
public static void textVstupnehoRiadka(String text) { vstupnýRiadok.setText(text); }
public static void pripojTextVstupnéhoRiadka(String naPripojenie){
String textVstupnéhoRiadka = vstupnýRiadok.getText();
vstupnýRiadok.setText(textVstupnéhoRiadka + naPripojenie);}
public static void pripojTextVstupnehoRiadka(String naPripojenie)
{ pripojTextVstupnéhoRiadka(naPripojenie); }
public static String prevezmiReťazec() { return údajeVstupnéhoRiadka.toString(); }
public static String prevezmiRetazec() { return údajeVstupnéhoRiadka.toString(); }
public static String prevezmiZrušenéÚdaje() { return zrušenéÚdajeVstupnéhoRiadka.toString(); }
public static String prevezmiZruseneUdaje() { return zrušenéÚdajeVstupnéhoRiadka.toString(); }
public static Long prevezmiCeléČíslo(){Long číslo = null;
try { číslo = Long.valueOf(údajeVstupnéhoRiadka.toString()); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Long prevezmiCeleCislo() { return prevezmiCeléČíslo(); }
public static Double prevezmiReálneČíslo(){Double číslo = null;try { číslo = Double.valueOf
(údajeVstupnéhoRiadka.toString()); }
catch (Exception e) { vypíšChybovéHlásenia(e); return null; }return číslo;}
public static Double prevezmiRealneCislo()
{ return prevezmiReálneČíslo(); }
public static boolean zalamujeTexty()
{ return strop.zalamujeTexty(); }
public static void zalamujTexty(boolean zalamuj)
{ strop.zalamujTexty(zalamuj); }
public static void zalamujTexty() { strop.zalamujTexty(true); }
public static void nezalamujTexty() { strop.zalamujTexty(false); }
public static void vypíš(Object... argumenty) { strop.vypíš(argumenty); }
public static void vypis(Object... argumenty) { strop.vypíš(argumenty); }
public static void vypíšRiadok(Object... argumenty) { strop.vypíšRiadok(argumenty); }
public static void vypisRiadok(Object... argumenty) { strop.vypíšRiadok(argumenty); }
public static void vypíšNa(double x, double y, Object... argumenty) { strop.vypíšNa(x, y, argumenty); }
public static void vypisNa(double x, double y, Object... argumenty) { strop.vypíšNa(x, y, argumenty); }
public static void vypíšRiadokNa(double x, double y, Object... argumenty) { strop.vypíšRiadokNa(x, y, argumenty); }
public static void vypisRiadokNa(double x, double y, Object... argumenty) { strop.vypíšRiadokNa(x, y, argumenty); }
public static void píšNa(double x, double y, Object... argumenty) { strop.píšNa(x, y, argumenty); }
public static void pisNa(double x, double y, Object... argumenty) { strop.píšNa(x, y, argumenty); }
public static void píšRiadokNa(double x, double y, Object... argumenty) { strop.píšRiadokNa(x, y, argumenty); }
public static void pisRiadokNa(double x, double y, Object... argumenty) { strop.píšRiadokNa(x, y, argumenty); }
public static long náhodnéCeléČíslo() { return generátor.nextLong(); }
public static long nahodneCeleCislo() { return generátor.nextLong(); }
public static long náhodnéCeléČíslo(long hodnota){if (0 == hodnota) return 0;if (hodnota > 0)
return Math.abs(generátor.nextLong() % (hodnota + 1));
return -Math.abs(generátor.nextLong() % (hodnota - 1));}
public static long nahodneCeleCislo(long hodnota) { return náhodnéCeléČíslo(hodnota); }
public static long náhodnéCeléČíslo(long min, long max){if (min > max)
return max + (Math.abs(generátor.nextLong()) % (1 + min - max));
return min + (Math.abs(generátor.nextLong()) % (1 + max - min));}
public static long nahodneCeleCislo(long min, long max) { return náhodnéCeléČíslo(min, max); }
public static double náhodnéReálneČíslo() { return generátor.nextDouble(); }
public static double nahodneRealneCislo() { return generátor.nextDouble(); }
public static double náhodnéReálneČíslo(double hodnota)
{ return generátor.nextDouble() * hodnota; }
public static double nahodneRealneCislo(double hodnota)
{ return generátor.nextDouble() * hodnota; }
public static double náhodnéReálneČíslo(double min, double max){if (min > max)
return max + (generátor.nextDouble() * (min - max));
return min + (generátor.nextDouble() * (max - min));}
public static double nahodneRealneCislo(double min, double max)
{ return náhodnéReálneČíslo(min, max); }
public static boolean textyDoSchránky(){
final StringBuffer texty = new StringBuffer();texty.setLength(0);podlaha.prevezmiTexty(texty);strop.prevezmiTexty(texty);
return Schránka.text(texty.toString());}
public static boolean textyDoSchranky() { return textyDoSchránky(); }
public static boolean textDoSchránky() { return textyDoSchránky(); }
public static boolean textDoSchranky() { return textyDoSchránky(); }
public static boolean obrázokDoSchránky()
{ return Schránka.obrázok(vyrovnávaciaPamäťObrázka); }
public static boolean obrazokDoSchranky() { return obrázokDoSchránky(); }
public static boolean grafikaDoSchránky() { return obrázokDoSchránky(); }
public static boolean grafikaDoSchranky() { return obrázokDoSchránky(); }
public static int šírkaObrázka(String súbor) { return súborNaObrázok(súbor).getWidth(null); }
public static int sirkaObrazka(String súbor) { return súborNaObrázok(súbor).getWidth(null); }
public static int výškaObrázka(String súbor) { return súborNaObrázok(súbor).getHeight(null); }
public static int vyskaObrazka(String súbor) { return súborNaObrázok(súbor).getHeight(null); }
public static void priečinokObrázkov(String priečinok)
{ priečinokObrázkov = upravLomky(priečinok, true); }
public static void priecinokObrazkov(String priečinok)
{ priečinokObrázkov = upravLomky(priečinok, true); }
public static String priečinokObrázkov() { return priečinokObrázkov; }
public static String priecinokObrazkov() { return priečinokObrázkov; }
public static void načítajObrázky(Object... súbory){for (Object súbor : súbory)
súborNaObrázok(súbor.toString());}
public static void nacitajObrazky(Object... súbory){ načítajObrázky(súbory); }
public static void načítajObrázky(String[] súbory){for (String súbor : súbory)súborNaObrázok(súbor);}
public static void nacitajObrazky(String[] súbory){ načítajObrázky(súbory); }
public static Image načítajObrázok(String súbor) { return súborNaObrázok(súbor); }
public static Image nacitajObrazok(String súbor) { return súborNaObrázok(súbor); }
public static void obrázok(String súbor) { podlaha.obrázok(súbor); }
public static void obrazok(String súbor) { podlaha.obrázok(súbor); }
public static void obrázok(double x, double y, String súbor) { podlaha.obrázok(x, y, súbor); }
public static void obrazok(double x, double y, String súbor) { podlaha.obrázok(x, y, súbor); }
public static void obrázok(Image obrázok){ podlaha.obrázok(obrázok); }
public static void obrazok(Image obrázok){ podlaha.obrázok(obrázok); }
public static void obrázok(double x, double y, Image obrázok)
{ podlaha.obrázok(x, y, obrázok); }
public static void obrazok(double x, double y, Image obrázok)
{ podlaha.obrázok(x, y, obrázok); }
public static void uložObrázok(String súbor) { uložObrázok(súbor, false); }
public static void ulozObrazok(String súbor) { uložObrázok(súbor, false); }
public static void uložObrázok(String súbor, boolean prepísať){
File uložiťDo = new File(súbor);
if (!prepísať && uložiťDo.exists())
throw new RuntimeException("Súbor „" + súbor + "“ jestvuje!");
String prípona = súbor.substring(súbor.lastIndexOf('.') + 1);
if (prípona.toLowerCase().equals("png")){
try { ImageIO.write(obrázok, prípona, uložiťDo); }
catch (IOException e) { vypíšChybovéHlásenia(e, true); }}
else if (prípona.toLowerCase().equals("jpg")){
WritableRaster raster = obrázok.getRaster();
WritableRaster novýRaster = raster.createWritableChild(
0, 0, šírkaPlátna, výškaPlátna,0, 0, new int[] {0, 1, 2});
DirectColorModel farebnýModel = (DirectColorModel)obrázok.getColorModel();
DirectColorModel novýFarebnýModel = new
DirectColorModel(farebnýModel.getPixelSize(),farebnýModel.getRedMask(),farebnýModel.getGreenMask(),farebnýModel.getBlueMask());
BufferedImage rgbBuffer = new BufferedImage(
novýFarebnýModel, novýRaster, false, null);
try { ImageIO.write(rgbBuffer, prípona, uložiťDo); }
catch (IOException e) { vypíšChybovéHlásenia(e, true); }}else{
throw new RuntimeException("Neplatný typ súboru: " + prípona);}}
public static void ulozObrazok(String súbor, boolean prepísať) { uložObrázok(súbor, prepísať); }
public static Farba farbaTextu() { return strop.farbaTextu(); }
public static void farbaTextu(Color nováFarba) { strop.farbaTextu(nováFarba); }
public static void farbaTextu(Farebnosť objekt) { strop.farbaTextu(objekt); }
public static Farba farbaTextu(int r, int g, int b) { return strop.farbaTextu(r, g, b); }
public static Farba farbaTextu(int r, int g, int b, int a) { return strop.farbaTextu(r, g, b, a); }
public static void predvolenáFarbaTextu() { strop.predvolenáFarbaTextu(); }
public static void predvolenaFarbaTextu() { strop.predvolenáFarbaTextu(); }
public static Farba farbaPozadia() { return farbaPozadia; }
public static void farbaPozadia(Color nováFarba){
if (nováFarba instanceof Farba)
farbaPozadia = (Farba)nováFarba;else
farbaPozadia = new Farba(nováFarba);automatickéPrekreslenie();}
public static void farbaPozadia(Farebnosť objekt)
{ farbaPozadia(objekt.farba()); }
public static Farba farbaPozadia(int r, int g, int b){
farbaPozadia = new Farba(r, g, b);automatickéPrekreslenie();return farbaPozadia;}
public static Farba farbaPozadia(int r, int g, int b, int a){
farbaPozadia = new Farba(r, g, b, a);automatickéPrekreslenie();return farbaPozadia;}
public static void predvolenáFarbaPozadia()
{ farbaPozadia(predvolenéPozadie); }
public static void predvolenaFarbaPozadia()
{ farbaPozadia(predvolenéPozadie); }
public static Farba farbaBodu(double x, double y){int x0 = (int)prepočítajX(x);int y0 = (int)prepočítajY(y);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return čierna;
return new Farba(obrázok.getRGB(x0, y0));}
public static Farba farbaBodu(Point2D bod){
int x0 = (int)prepočítajX(bod.getX());
int y0 = (int)prepočítajY(bod.getY());
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return čierna;
return new Farba(obrázok.getRGB(x0, y0));}
public static Farba farbaBodu(GRobot ktorý)
{ return farbaBodu(ktorý.aktuálneX, ktorý.aktuálneY); }
public static boolean farbaBodu(double x, double y, Color farba){int x0 = (int)prepočítajX(x);int y0 = (int)prepočítajY(y);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (farba.getRGB() & 0xffffff) ==
(obrázok.getRGB(x0, y0) & 0xffffff);}
public static boolean farbaBodu(Point2D bod, Color farba){
int x0 = (int)prepočítajX(bod.getX());
int y0 = (int)prepočítajY(bod.getY());
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (farba.getRGB() & 0xffffff) ==
(obrázok.getRGB(x0, y0) & 0xffffff);}
public static boolean farbaBodu(GRobot ktorý, Color farba)
{ return farbaBodu(ktorý.aktuálneX, ktorý.aktuálneY, farba); }
public static boolean farbaBodu(double x, double y, Farebnosť objekt){int x0 = (int)prepočítajX(x);int y0 = (int)prepočítajY(y);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (objekt.farba().getRGB() & 0xffffff) ==
(obrázok.getRGB(x0, y0) & 0xffffff);}
public static boolean farbaBodu(Point2D bod, Farebnosť objekt){
int x0 = (int)prepočítajX(bod.getX());
int y0 = (int)prepočítajY(bod.getY());
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (objekt.farba().getRGB() & 0xffffff) ==
(obrázok.getRGB(x0, y0) & 0xffffff);}
public static boolean farbaBodu(GRobot ktorý, Farebnosť farebnosť)
{ return farbaBodu(ktorý.aktuálneX, ktorý.aktuálneY, farebnosť); }
public static Farba farbaNaMyši(){
int x0 = (int)prepočítajX(súradnicaMyšiX);
int y0 = (int)prepočítajY(súradnicaMyšiY);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return čierna;
return new Farba(obrázok.getRGB(x0, y0));}
public static Farba farbaNaMysi() { return farbaNaMyši(); }
public static boolean farbaNaMyši(Color farba){
int x0 = (int)prepočítajX(súradnicaMyšiX);
int y0 = (int)prepočítajY(súradnicaMyšiY);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (farba.getRGB() & 0xffffff) ==
(obrázok.getRGB(x0, y0) & 0xffffff);}
public static boolean farbaNaMysi(Color farba) { return farbaNaMyši(farba); }
public static boolean farbaNaMyši(Farebnosť objekt){
int x0 = (int)prepočítajX(súradnicaMyšiX);
int y0 = (int)prepočítajY(súradnicaMyšiY);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (objekt.farba().getRGB() & 0xffffff) ==
(obrázok.getRGB(x0, y0) & 0xffffff);}
public static boolean farbaNaMysi(Farebnosť objekt) { return farbaNaMyši(objekt); }
public static Písmo písmo() { return strop.písmo(); }
public static Pismo pismo() { return strop.pismo(); }
public static void písmo(Písmo novéPísmo) { strop.písmo(novéPísmo); }
public static void pismo(Písmo novéPísmo) { strop.písmo(novéPísmo); }
public static void písmo(Object novéPísmo) { strop.písmo(novéPísmo); }
public static void pismo(Object novéPísmo) { strop.písmo(novéPísmo); }
public static Písmo písmo(String názov, int veľkosť) { return strop.písmo(názov, veľkosť); }
public static Pismo pismo(String názov, int veľkosť) { return strop.pismo(názov, veľkosť); }
public static void predvolenéPísmo() { strop.predvolenéPísmo(); }
public static void predvolenePismo() { strop.predvolenéPísmo(); }
public static void priečinokZvukov(String priečinok)
{ priečinokZvukov = upravLomky(priečinok, true); }
public static void priecinokZvukov(String priečinok)
{ priečinokZvukov = upravLomky(priečinok, true); }
public static String priečinokZvukov() { return priečinokZvukov; }
public static String priecinokZvukov() { return priečinokZvukov; }
public static void načítajZvuky(Object... súbory){for (Object súbor : súbory)súborNaZvuk(súbor.toString());}
public static void nacitajZvuky(Object... súbory){ načítajZvuky(súbory); }
public static void načítajZvuky(String[] súbory){for (String súbor : súbory)súborNaZvuk(súbor);}
public static void nacitajZvuky(String[] súbory){ načítajZvuky(súbory); }
public static Zvuk načítajZvuk(String súbor) { return súborNaZvuk(súbor); }
public static Zvuk nacitajZvuk(String súbor) { return súborNaZvuk(súbor); }
public static void zvuk(String súbor) { súborNaZvuk(súbor).prehraj(); }
public static void zvukNaPozadí(String súbor){if (null == súbor){if (null != zvukNaPozadí){zvukNaPozadí.zastav();zvukNaPozadí = null;}}else{
if (null != zvukNaPozadí) zvukNaPozadí.zastav();
zvukNaPozadí = súborNaZvuk(súbor);
zvukNaPozadí.prehrávaťDookola();}}
public static void zvukNaPozadi(String súbor) { zvukNaPozadí(súbor); }
public static boolean hráZvukNaPozadí() { return null != zvukNaPozadí; }
public static boolean hraZvukNaPozadi() { return null != zvukNaPozadí; }
public static void zastavZvuky(Object... súbory){for (Object súbor : súbory)
súborNaZvuk(súbor.toString()).zastav();}
public static void hlasitosťPreZvuky(double miera, Object... súbory){for (Object súbor : súbory)
súborNaZvuk(súbor.toString()).hlasitosť(miera);}
public static void hlasitostPreZvuky(double miera, Object... súbory)
{ hlasitosťPreZvuky(miera, súbory); }
public static void váhaPreZvuky(double miera, Object... súbory){for (Object súbor : súbory)
súborNaZvuk(súbor.toString()).váha(miera);}
public static void vahaPreZvuky(double miera, Object... súbory)
{ váhaPreZvuky(miera, súbory); }
public static void zastavZvuky(String[] súbory){for (String súbor : súbory)
súborNaZvuk(súbor.toString()).zastav();}
public static void hlasitosťPreZvuky(double miera, String[] súbory){for (String súbor : súbory)
súborNaZvuk(súbor.toString()).hlasitosť(miera);}
public static void hlasitostPreZvuky(double miera, String[] súbory)
{ hlasitosťPreZvuky(miera, súbory); }
public static void váhaPreZvuky(double miera, String[] súbory){for (String súbor : súbory)
súborNaZvuk(súbor.toString()).váha(miera);}
public static void vahaPreZvuky(double miera, String[] súbory)
{ váhaPreZvuky(miera, súbory); }
public static void pípni() { Toolkit.getDefaultToolkit().beep(); }
public static void pipni() { Toolkit.getDefaultToolkit().beep(); }
public static void spustiČasovač(double čas) { časovač.spusti((int)(čas * 1000)); }
public static void spustiCasovac(double čas) { časovač.spusti((int)(čas * 1000)); }
public static void spustiČasovač(){
if (null == časovač.časovač) časovač.spusti(40);
else if (!časovač.časovač.isRunning()) časovač.časovač.start();}
public static void spustiCasovac() { spustiČasovač(); }
public static void odložČasovač(double čas) { časovač.odlož((int)(čas * 1000)); }
public static void odlozCasovac(double čas) { časovač.odlož((int)(čas * 1000)); }
public static boolean časovačAktívny() { return časovač.aktívny(); }
public static boolean casovacAktivny() { return časovač.aktívny(); }
public static double intervalČasovača(){
return (double)časovač.interval() / (double)1000.0;}
public static double intervalCasovaca() { return intervalČasovača(); }
public static void zastavČasovač() { časovač.zastav(); }
public static void zastavCasovac() { časovač.zastav(); }
public static void čakaj(double početSekúnd){
try { Thread.sleep((long)(početSekúnd * 1000)); }
catch (InterruptedException ie) {}}
public static void cakaj(double početSekúnd) { čakaj(početSekúnd); }}
public final static Svet svet = new Svet();
public static class Plátno implements Priehľadnosť{private Plátno() {}
private BufferedImage vyrovnávaciaPamäťObrázkaPlátna = new
BufferedImage(šírkaPlátna, výškaPlátna,BufferedImage.TYPE_INT_ARGB);
private Graphics2D vyrovnávaciaPamäťGrafikyPlátna =
vyrovnávaciaPamäťObrázkaPlátna.createGraphics();
private void vytvorNovéPlátno(int šírkaPlátna, int výškaPlátna){
vyrovnávaciaPamäťObrázkaPlátna = new BufferedImage(šírkaPlátna,
výškaPlátna, BufferedImage.TYPE_INT_ARGB);
vyrovnávaciaPamäťGrafikyPlátna =
vyrovnávaciaPamäťObrázkaPlátna.createGraphics();}private int[] originálPlátna;private int[] zálohaPlátna;private int[] operáciePlátna;
private Farba zmenaFarbyKonzoly = null;
private Písmo aktuálnePísmoKonzoly = predvolenéPísmoKonzoly;
private final Vector<RiadokKonzoly> vnútornáKonzola = new Vector<RiadokKonzoly>();
private boolean súradniceKonzolyAplikované = false;
private Point2D zmenaSúradnícKonzoly = null;
private boolean zalamujTexty = false;
private int posunutieTextovX = 0, posunutieTextovY = 0;
private float priehľadnosť = 1.0f;
private String[] rozbiNaSlová(StringBuffer text){int počet = 1;
for (int i = 0; -1 != (i = text.indexOf(" ", i)); ++i, ++počet);
String[] rozbité = new String[počet];
int index = 0, začiatok = 0, koniec = text.indexOf(" ", začiatok);while (-1 != koniec){
rozbité[index] = text.substring(začiatok, koniec);
začiatok = koniec + 1; ++index;
koniec = text.indexOf(" ", začiatok);}
rozbité[index] = text.substring(začiatok, text.length());return rozbité;}
private void prekresli(Graphics2D grafika){if (priehľadnosť > 0){if (priehľadnosť < 1){
Composite záloha = grafika.getComposite();grafika.setComposite(AlphaComposite.getInstance(
AlphaComposite.SRC_OVER, priehľadnosť));grafika.drawImage(
vyrovnávaciaPamäťObrázkaPlátna, 0, 0, null);grafika.setComposite(záloha);}else grafika.drawImage(
vyrovnávaciaPamäťObrázkaPlátna, 0, 0, null);}if (konzolaPoužitá){
grafika.setFont(aktuálnePísmoKonzoly);
FontMetrics rozmery = grafika.getFontMetrics();
int výškaRiadka = rozmery.getHeight();
int x0, výškaKlienta, výškaTextu;
int x = x0 = (šírkaPlátna - hlavnýPanel.getWidth()) / 2 + 2;
int y = (výškaPlátna - (výškaKlienta =
hlavnýPanel.getHeight()) - 1) / 2 + výškaRiadka;if (x < 2) x = x0 = 2;
if (y < výškaRiadka) y = výškaRiadka;if (zalamujTexty){
int šírkaMedzery = rozmery.stringWidth(" ");
int šírkaZalomenia = hlavnýPanel.getWidth();
if (šírkaZalomenia > šírkaPlátna)šírkaZalomenia = šírkaPlátna;výškaTextu = 0;
for (RiadokKonzoly riadok : vnútornáKonzola){
for (ČlánokKonzoly článok : riadok){
if (null == článok.článok) continue;if (null == článok.slová)
článok.slová = rozbiNaSlová(článok.článok);
for (String slovo : článok.slová){int šírkaSlova =rozmery.stringWidth(slovo);
if (x + šírkaSlova > x0 + šírkaZalomenia){výškaTextu += výškaRiadka;x = x0;}
x += šírkaSlova + šírkaMedzery;}x -= šírkaMedzery;}výškaTextu += výškaRiadka;x = x0;}
if (!súradniceKonzolyAplikované &&(výškaTextu > výškaKlienta ||výškaTextu > výškaPlátna)){int yRolujOd;
if (výškaKlienta > výškaPlátna){y = výškaPlátna - výškaTextu;yRolujOd = výškaRiadka;}else{
y = (výškaPlátna + výškaKlienta) / 2 - výškaTextu;
yRolujOd = (výškaPlátna - výškaKlienta) / 2 +výškaRiadka;}int yRolujDo = y;y += posunutieTextovY;if (y > yRolujOd){int Δy = y - yRolujOd;y -= posunutieTextovY;posunutieTextovY -= Δy;y += posunutieTextovY;}if (y < yRolujDo){int Δy = y - yRolujDo;y -= posunutieTextovY;posunutieTextovY -= Δy;y += posunutieTextovY;}
for (RiadokKonzoly riadok : vnútornáKonzola){
for (ČlánokKonzoly článok : riadok){if (null != článok.farba)
grafika.setColor(článok.farba);
if (null == článok.článok) continue;if (null != článok.slová)
for (String slovo : článok.slová){int šírkaSlova =rozmery.stringWidth(slovo);if (0 != šírkaSlova){if (x + šírkaSlova >x0 + šírkaZalomenia){y += výškaRiadka;x = x0;}
grafika.drawString(slovo, x, y);}
x += šírkaSlova + šírkaMedzery;}x -= šírkaMedzery;}y += výškaRiadka;x = x0;}}else{
for (RiadokKonzoly riadok : vnútornáKonzola){
for (ČlánokKonzoly článok : riadok){if (null != článok.farba)
grafika.setColor(článok.farba);if (null != článok.poloha){
x = x0 = (int)článok.poloha.getX() + 2;
y = (int)článok.poloha.getY() +výškaRiadka;}
if (null == článok.článok) continue;if (null != článok.slová)
for (String slovo : článok.slová){int šírkaSlova =rozmery.stringWidth(slovo);if (0 != šírkaSlova){if (x + šírkaSlova >x0 + šírkaZalomenia){y += výškaRiadka;x = x0;}
grafika.drawString(slovo, x, y);}
x += šírkaSlova + šírkaMedzery;}x -= šírkaMedzery;}y += výškaRiadka;x = x0;}}}else{
výškaTextu = vnútornáKonzola.size() * výškaRiadka;
if (!súradniceKonzolyAplikované){
if (výškaTextu > výškaKlienta ||výškaTextu > výškaPlátna){int yRolujOd;
if (výškaKlienta > výškaPlátna){y = výškaPlátna - výškaTextu;yRolujOd = výškaRiadka;}else{
y = (výškaPlátna + výškaKlienta) / 2 -výškaTextu;
yRolujOd = (výškaPlátna - výškaKlienta) / 2 +výškaRiadka;}int yRolujDo = y;
if (posunutieTextovX < 0) posunutieTextovX = 0;y += posunutieTextovY;x -= posunutieTextovX;if (y > yRolujOd){int Δy = y - yRolujOd;y -= posunutieTextovY;posunutieTextovY -= Δy;y += posunutieTextovY;}if (y < yRolujDo){int Δy = y - yRolujDo;y -= posunutieTextovY;posunutieTextovY -= Δy;y += posunutieTextovY;}
for (RiadokKonzoly riadok : vnútornáKonzola){
for (ČlánokKonzoly článok : riadok){if (null != článok.farba)
grafika.setColor(článok.farba);
if (null == článok.článok) continue;
String text = článok.článok.toString();
grafika.drawString(text, x, y);
x += rozmery.stringWidth(text);}y += výškaRiadka;x = x0;x -= posunutieTextovX;}}else{
if (posunutieTextovX < 0) posunutieTextovX = 0;x -= posunutieTextovX;
for (RiadokKonzoly riadok : vnútornáKonzola){
for (ČlánokKonzoly článok : riadok){if (null != článok.farba)
grafika.setColor(článok.farba);
if (null == článok.článok) continue;
String text = článok.článok.toString();
grafika.drawString(text, x, y);
x += rozmery.stringWidth(text);}y += výškaRiadka;x = x0;x -= posunutieTextovX;}}}else{
for (RiadokKonzoly riadok : vnútornáKonzola){
for (ČlánokKonzoly článok : riadok){if (null != článok.farba)
grafika.setColor(článok.farba);if (null != článok.poloha){
x = x0 = (int)článok.poloha.getX() + 2;
y = (int)článok.poloha.getY() +výškaRiadka;}
if (null == článok.článok) continue;
String text = článok.článok.toString();
grafika.drawString(text, x, y);
x += rozmery.stringWidth(text);}y += výškaRiadka;x = x0;}}}}}
private void prevezmiTexty(StringBuffer texty){
for (RiadokKonzoly riadok : vnútornáKonzola){
for (ČlánokKonzoly článok : riadok){
if (null == článok.článok) continue;texty.append(článok.článok);}texty.append("\n");}}
private final static char[] nepridajMedzeruZa =
{' ', '(', '[', '{', '\n', '„', '\'', '\"'};
private final static char[] nepridajMedzeruPred =
{' ', '\t', '\n', '.', ',', ';', ':', '!', '?', ')', ']', '}','%', '“', '\'', '\"'};
private void pridajMedzeru(StringBuffer článok, Object časť){
String reťazec = časť.toString();
if (0 == reťazec.length()) return;
boolean pridajMedzeru = článok.length() != 0;if (pridajMedzeru){
char znak = článok.charAt(článok.length() - 1);
for (char nepridaj : nepridajMedzeruZa)if (nepridaj == znak){pridajMedzeru = false;break;}}if (pridajMedzeru){char znak = reťazec.charAt(0);
for (char nepridaj : nepridajMedzeruPred)if (nepridaj == znak){pridajMedzeru = false;break;}}
if (pridajMedzeru) článok.append(" ");}
public static double najmenšieX() { return -šírkaPlátna / 2; }
public static double najmensieX() { return -šírkaPlátna / 2; }
public static double najmenšieY() { return -(výškaPlátna - 1) / 2; }
public static double najmensieY() { return -(výškaPlátna - 1) / 2; }
public static double najväčšieX() { return (šírkaPlátna - 1) / 2; }
public static double najvacsieX() { return (šírkaPlátna - 1) / 2; }
public static double najväčšieY() { return výškaPlátna / 2; }
public static double najvacsieY() { return výškaPlátna / 2; }
public static double ľavýOkraj(){
int súradnica = -hlavnýPanel.getWidth() / 2;
if (súradnica < (-šírkaPlátna / 2))return -šírkaPlátna / 2;return súradnica;}
public static double lavyOkraj() { return ľavýOkraj(); }
public static double spodnýOkraj(){
int súradnica = -(hlavnýPanel.getHeight() - 1) / 2;
if (súradnica < (-(výškaPlátna - 1) / 2))return -(výškaPlátna - 1) / 2;return súradnica;}
public static double spodnyOkraj() { return spodnýOkraj(); }
public static double dolnýOkraj() { return spodnýOkraj(); }
public static double dolnyOkraj() { return spodnýOkraj(); }
public static double pravýOkraj(){
int súradnica = (hlavnýPanel.getWidth() - 1) / 2;
if (súradnica > ((šírkaPlátna - 1) / 2))return (šírkaPlátna - 1) / 2;return súradnica;}
public static double pravyOkraj() { return pravýOkraj(); }
public static double vrchnýOkraj(){
int súradnica = hlavnýPanel.getHeight() / 2;
if (súradnica > (výškaPlátna / 2))return výškaPlátna / 2;return súradnica;}
public static double vrchnyOkraj() { return vrchnýOkraj(); }
public static double hornýOkraj() { return vrchnýOkraj(); }
public static double hornyOkraj() { return vrchnýOkraj(); }public void zálohuj(){if (null == originálPlátna)
originálPlátna = ((DataBufferInt)
vyrovnávaciaPamäťObrázkaPlátna.getRaster().getDataBuffer()).getData();if (null == zálohaPlátna)
zálohaPlátna = new int[originálPlátna.length];
System.arraycopy(originálPlátna, 0, zálohaPlátna, 0, originálPlátna.length);}
public void zalohuj() { zálohuj(); }public void obnov(){
if (null == zálohaPlátna || null == originálPlátna) return;
System.arraycopy(zálohaPlátna, 0, originálPlátna, 0, originálPlátna.length);automatickéPrekreslenie();}
public void zálohuj(GRobot ktorý){if (null == originálPlátna)
originálPlátna = ((DataBufferInt)
vyrovnávaciaPamäťObrázkaPlátna.
getRaster().getDataBuffer()).getData();
if (null == ktorý.zálohaPlátna){
ktorý.obrázokZálohyPlátna = new BufferedImage(šírkaPlátna,
výškaPlátna, BufferedImage.TYPE_INT_ARGB);
ktorý.zálohaPlátna = ((DataBufferInt)ktorý.obrázokZálohyPlátna.
getRaster().getDataBuffer()).getData();}
System.arraycopy(originálPlátna, 0,
ktorý.zálohaPlátna, 0, originálPlátna.length);}
public void zalohuj(GRobot ktorý) { zálohuj(ktorý); }
public void zapamätaj(GRobot ktorý) { zálohuj(ktorý); }
public void zapamataj(GRobot ktorý) { zálohuj(ktorý); }
public void obnov(GRobot ktorý){
if (null == ktorý.zálohaPlátna || null == originálPlátna) return;
System.arraycopy(ktorý.zálohaPlátna, 0,
originálPlátna, 0, originálPlátna.length);automatickéPrekreslenie();}
public void kresli(GRobot ktorý){
if (null == ktorý.obrázokZálohyPlátna) return;
vyrovnávaciaPamäťGrafikyPlátna.drawImage
(ktorý.obrázokZálohyPlátna, 0, 0, null);automatickéPrekreslenie();}
public Farba farbaBodu(double x, double y){int x0 = (int)prepočítajX(x);int y0 = (int)prepočítajY(y);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return čierna;
return new Farba(vyrovnávaciaPamäťObrázkaPlátna.getRGB(x0, y0), true);}
public Farba farbaBodu(Point2D bod){
int x0 = (int)prepočítajX(bod.getX());
int y0 = (int)prepočítajY(bod.getY());
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return čierna;
return new Farba(vyrovnávaciaPamäťObrázkaPlátna.getRGB(x0, y0), true);}
public Farba farbaBodu(GRobot ktorý)
{ return farbaBodu(ktorý.aktuálneX, ktorý.aktuálneY); }
public boolean farbaBodu(double x, double y, Color farba){int x0 = (int)prepočítajX(x);int y0 = (int)prepočítajY(y);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (farba.getRGB() & 0xffffffff) ==
(vyrovnávaciaPamäťObrázkaPlátna.getRGB(x0, y0) & 0xffffffff);}
public boolean farbaBodu(Point2D bod, Color farba){
int x0 = (int)prepočítajX(bod.getX());
int y0 = (int)prepočítajY(bod.getY());
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (farba.getRGB() & 0xffffffff) ==
(vyrovnávaciaPamäťObrázkaPlátna.getRGB(x0, y0) & 0xffffffff);}
public boolean farbaBodu(GRobot ktorý, Color farba)
{ return farbaBodu(ktorý.aktuálneX, ktorý.aktuálneY, farba); }
public boolean farbaBodu(double x, double y, Farebnosť objekt){int x0 = (int)prepočítajX(x);int y0 = (int)prepočítajY(y);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (objekt.farba().getRGB() & 0xffffffff) ==
(vyrovnávaciaPamäťObrázkaPlátna.getRGB(x0, y0) & 0xffffffff);}
public boolean farbaBodu(Point2D bod, Farebnosť objekt){
int x0 = (int)prepočítajX(bod.getX());
int y0 = (int)prepočítajY(bod.getY());
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (objekt.farba().getRGB() & 0xffffffff) ==
(vyrovnávaciaPamäťObrázkaPlátna.getRGB(x0, y0) & 0xffffffff);}
public boolean farbaBodu(GRobot ktorý, Farebnosť farebnosť)
{ return farbaBodu(ktorý.aktuálneX, ktorý.aktuálneY, farebnosť); }public Farba farbaNaMyši(){
int x0 = (int)prepočítajX(súradnicaMyšiX);
int y0 = (int)prepočítajY(súradnicaMyšiY);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return čierna;
return new Farba(vyrovnávaciaPamäťObrázkaPlátna.getRGB(x0, y0), true);}
public Farba farbaNaMysi() { return farbaNaMyši(); }
public boolean farbaNaMyši(Color farba){
int x0 = (int)prepočítajX(súradnicaMyšiX);
int y0 = (int)prepočítajY(súradnicaMyšiY);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (farba.getRGB() & 0xffffffff) ==
(vyrovnávaciaPamäťObrázkaPlátna.getRGB(x0, y0) & 0xffffffff);}
public boolean farbaNaMysi(Color farba) { return farbaNaMyši(farba); }
public boolean farbaNaMyši(Farebnosť objekt){
int x0 = (int)prepočítajX(súradnicaMyšiX);
int y0 = (int)prepočítajY(súradnicaMyšiY);
if (x0 < 0 || x0 >= šírkaPlátna ||
y0 < 0 || y0 >= výškaPlátna) return false;
return (objekt.farba().getRGB() & 0xffffffff) ==
(vyrovnávaciaPamäťObrázkaPlátna.getRGB(x0, y0) & 0xffffffff);}
public boolean farbaNaMysi(Farebnosť objekt) { return farbaNaMyši(objekt); }public Farba farbaTextu(){
if (null != zmenaFarbyKonzoly) return zmenaFarbyKonzoly;
for (int i = vnútornáKonzola.size() - 1; i >= 0; --i){
RiadokKonzoly riadok = vnútornáKonzola.get(i);
for (int j = riadok.size() - 1; j >= 0; --j){
ČlánokKonzoly článok = riadok.get(j);if (null != článok.farba)return článok.farba;}}return null;}
public void farbaTextu(Color nováFarba){
if (nováFarba instanceof Farba)
zmenaFarbyKonzoly = (Farba)nováFarba;else
zmenaFarbyKonzoly = new Farba(nováFarba);}
public void farbaTextu(Farebnosť objekt)
{ farbaTextu(objekt.farba()); }
public Farba farbaTextu(int r, int g, int b) { return zmenaFarbyKonzoly = new Farba(r, g, b); }
public Farba farbaTextu(int r, int g, int b, int a) { return zmenaFarbyKonzoly = new Farba(r, g, b, a); }
public void predvolenáFarbaTextu() { zmenaFarbyKonzoly = predvolenáFarbaKonzoly; }
public void predvolenaFarbaTextu() { zmenaFarbyKonzoly = predvolenáFarbaKonzoly; }
public Písmo písmo() { return aktuálnePísmoKonzoly; }
public Pismo pismo() { return new Pismo(aktuálnePísmoKonzoly); }
public void písmo(Písmo novéPísmo){
aktuálnePísmoKonzoly = novéPísmo;automatickéPrekreslenie();}
public void pismo(Písmo novéPísmo) { písmo(novéPísmo); }
public void písmo(Object novéPísmo){
if (novéPísmo instanceof Písmo) písmo((Písmo)novéPísmo);}
public void pismo(Object novéPísmo) { písmo(novéPísmo); }
public Písmo písmo(String názov, int veľkosť){
aktuálnePísmoKonzoly = new Písmo(názov, Písmo.PLAIN, veľkosť);automatickéPrekreslenie();return aktuálnePísmoKonzoly;}
public Pismo pismo(String názov, int veľkosť)
{ return new Pismo(písmo(názov, veľkosť)); }
public void predvolenéPísmo() { písmo(predvolenéPísmoKonzoly); }
public void predvolenePismo() { písmo(predvolenéPísmoKonzoly); }
public double priehľadnosť() { return priehľadnosť; }
public double priehladnost() { return priehľadnosť; }
public void priehľadnosť(double priehľadnosť){
this.priehľadnosť = (float)priehľadnosť;automatickéPrekreslenie();}
public void priehladnost(double priehľadnosť)
{ priehľadnosť(priehľadnosť); }
public void priehľadnosť(Priehľadnosť objekt){
this.priehľadnosť = (float)objekt.priehľadnosť();automatickéPrekreslenie();}
public void priehladnost(Priehľadnosť objekt){ priehľadnosť(objekt); }
public void upravPriehľadnosť(double zmena){
if (0 == priehľadnosť) priehľadnosť = 0.1f;
else priehľadnosť *= (float)zmena;automatickéPrekreslenie();}
public void upravPriehladnost(double zmena){ upravPriehľadnosť(zmena); }
public BufferedImage obrázok() { return vyrovnávaciaPamäťObrázkaPlátna; }
public BufferedImage obrazok() { return vyrovnávaciaPamäťObrázkaPlátna; }
public Graphics2D grafika() { return vyrovnávaciaPamäťGrafikyPlátna; }public void kresliVšade(){
vyrovnávaciaPamäťGrafikyPlátna.setClip(null);}
public void kresliVsade() { kresliVšade(); }
public void kresliDo(Shape tvar){if (null == tvar) return;
vyrovnávaciaPamäťGrafikyPlátna.clip(tvar);}
public void nekresliDo(Shape tvar){if (null == tvar) return;
Shape clip = vyrovnávaciaPamäťGrafikyPlátna.getClip();
if (null == clip) clip = new Rectangle.
Double(0, 0, šírkaPlátna, výškaPlátna);Area oblasťA = new Area(clip);Area oblasťB = new Area(tvar);oblasťA.subtract(oblasťB);
vyrovnávaciaPamäťGrafikyPlátna.setClip(oblasťA);}
public boolean zalamujeTexty() { return zalamujTexty; }
public void zalamujTexty(boolean zalamuj){zalamujTexty = zalamuj;automatickéPrekreslenie();}
public void zalamujTexty() { zalamujTexty(true); }
public void nezalamujTexty() { zalamujTexty(false); }
public void vypíš(Object... argumenty){
if (0 == vnútornáKonzola.size())
vnútornáKonzola.add(new RiadokKonzoly());if (!konzolaPoužitá){konzolaPoužitá = true;if (null != hlavnýRobot)hlavnýRobot.skry();}
RiadokKonzoly riadok = vnútornáKonzola.lastElement();
ČlánokKonzoly článok = new ČlánokKonzoly();if (null != zmenaFarbyKonzoly){
článok.farba = zmenaFarbyKonzoly;zmenaFarbyKonzoly = null;}
if (null != zmenaSúradnícKonzoly){
článok.poloha = zmenaSúradnícKonzoly;
súradniceKonzolyAplikované = true;zmenaSúradnícKonzoly = null;}
for (Object argument : argumenty){
if (argument instanceof GRobot){((GRobot)argument).ukáž();continue;}if (null == článok.článok)
článok.článok = new StringBuffer();if (null == argument){
pridajMedzeru(článok.článok, Súbor.nullString);
článok.článok.append(Súbor.nullString);}
else if (argument instanceof int[]){int[] pole = (int[])argument;
pridajMedzeru(článok.článok, 0);
for (int i = 0; i < pole.length; ++i){
if (i > 0) článok.článok.append(" ");článok.článok.append(pole[i]);}}
else if (argument instanceof long[]){
long[] pole = (long[])argument;
pridajMedzeru(článok.článok, 0);
for (int i = 0; i < pole.length; ++i){
if (i > 0) článok.článok.append(" ");článok.článok.append(pole[i]);}}
else if (argument instanceof float[]){
float[] pole = (float[])argument;
pridajMedzeru(článok.článok, 0.0);
for (int i = 0; i < pole.length; ++i){
if (i > 0) článok.článok.append(" ");článok.článok.append(pole[i]);}}
else if (argument instanceof double[]){
double[] pole = (double[])argument;
pridajMedzeru(článok.článok, 0.0);
for (int i = 0; i < pole.length; ++i){
if (i > 0) článok.článok.append(" ");článok.článok.append(pole[i]);}}
else if (argument instanceof boolean[]){
boolean[] pole = (boolean[])argument;
pridajMedzeru(článok.článok, false);
for (int i = 0; i < pole.length; ++i){
if (i > 0) článok.článok.append(" ");článok.článok.append(pole[i]);}}else{StringBuffer naPridanie;
if (argument instanceof char[])
naPridanie = new StringBuffer(new String((char[])argument));else
naPridanie = new StringBuffer(argument.toString());
int indexOf = naPridanie.indexOf("\t");
int newLine = naPridanie.indexOf("\n");
pridajMedzeru(článok.článok, naPridanie);while (indexOf != -1){if (indexOf < newLine)
indexOf += článok.článok.length();switch (indexOf % 4){
case 0: naPridanie.replace(indexOf, indexOf + 1,"    "); break;
case 1: naPridanie.replace(indexOf, indexOf + 1,"   "); break;
case 2: naPridanie.replace(indexOf, indexOf + 1,"  "); break;
default: naPridanie.setCharAt(indexOf, ' ');}
indexOf = naPridanie.indexOf("\t");}
indexOf = naPridanie.indexOf("\n");while (indexOf != -1){
článok.článok.append(naPridanie.substring(0, indexOf));riadok.add(článok);
vnútornáKonzola.add(riadok = new RiadokKonzoly());článok = new ČlánokKonzoly();
článok.článok = new StringBuffer();
naPridanie.delete(0, indexOf + 1);
indexOf = naPridanie.indexOf("\n");}
článok.článok.append(naPridanie);}}riadok.add(článok);automatickéPrekreslenie();}
public void vypis(Object... argumenty) { vypíš(argumenty); }
public void vypíšRiadok(Object... argumenty){vypíš(argumenty);
vnútornáKonzola.add(new RiadokKonzoly());automatickéPrekreslenie();}
public void vypisRiadok(Object... argumenty) { vypíšRiadok(argumenty); }
public void vypíšNa(double x, double y, Object... argumenty){
zmenaSúradnícKonzoly = new Point2D.Double(
prepočítajX(x), prepočítajY(y));vypíš(argumenty);}
public void vypisNa(double x, double y, Object... argumenty) { vypíšNa(x, y, argumenty); }
public void vypíšRiadokNa(double x, double y, Object... argumenty){
zmenaSúradnícKonzoly = new Point2D.Double(
prepočítajX(x), prepočítajY(y));vypíšRiadok(argumenty);}
public void vypisRiadokNa(double x, double y, Object... argumenty) { vypíšRiadokNa(x, y, argumenty); }
public void píšNa(double x, double y, Object... argumenty){
zmenaSúradnícKonzoly = new Point2D.Double(
prepočítajX(x), prepočítajY(y));vypíš(argumenty);}
public void pisNa(double x, double y, Object... argumenty) { píšNa(x, y, argumenty); }
public void píšRiadokNa(double x, double y, Object... argumenty){
zmenaSúradnícKonzoly = new Point2D.Double(
prepočítajX(x), prepočítajY(y));vypíšRiadok(argumenty);}
public void pisRiadokNa(double x, double y, Object... argumenty) { píšRiadokNa(x, y, argumenty); }
public void obrázok(String súbor){
Image obrázok = súborNaObrázok(súbor);
double prepočítanéX = prepočítajX(0);
double prepočítanéY = prepočítajY(0);
int šírkaObrázka = obrázok.getWidth(null);
int výškaObrázka = obrázok.getHeight(null);
if (šírkaObrázka < 0 || výškaObrázka < 0)
throw new RuntimeException("Obrázok „" + súbor + "“ je poškodený!");
vyrovnávaciaPamäťGrafikyPlátna.drawImage(obrázok,
(int)(prepočítanéX - (šírkaObrázka / 2.0)),
(int)(prepočítanéY - (výškaObrázka / 2.0)), null);automatickéPrekreslenie();}
public void obrazok(String súbor) { obrázok(súbor); }
public void obrázok(double x, double y, String súbor){
Image obrázok = súborNaObrázok(súbor);
double prepočítanéX = prepočítajX(x);
double prepočítanéY = prepočítajY(y);
int šírkaObrázka = obrázok.getWidth(null);
int výškaObrázka = obrázok.getHeight(null);
if (šírkaObrázka < 0 || výškaObrázka < 0)
throw new RuntimeException("Obrázok „" + súbor + "“ je poškodený!");
vyrovnávaciaPamäťGrafikyPlátna.drawImage(obrázok,
(int)prepočítanéX, (int)prepočítanéY, null);automatickéPrekreslenie();}
public void obrazok(double x, double y, String súbor) { obrázok(x, y, súbor); }
public void obrázok(Image obrázok){
double prepočítanéX = prepočítajX(0);
double prepočítanéY = prepočítajY(0);
int šírkaObrázka = obrázok.getWidth(null);
int výškaObrázka = obrázok.getHeight(null);
if (šírkaObrázka < 0 || výškaObrázka < 0)
throw new RuntimeException("Obrázok je poškodený!");
if (obrázok instanceof Obrázok)((Obrázok)obrázok).
kresliNaStred((int)prepočítanéX, (int)prepočítanéY,
vyrovnávaciaPamäťGrafikyPlátna);else
vyrovnávaciaPamäťGrafikyPlátna.drawImage(obrázok,
(int)(prepočítanéX - (šírkaObrázka / 2.0)),
(int)(prepočítanéY - (výškaObrázka / 2.0)), null);automatickéPrekreslenie();}
public void obrazok(Image obrázok) { obrázok(obrázok); }
public void obrázok(double x, double y, Image obrázok){
double prepočítanéX = prepočítajX(x);
double prepočítanéY = prepočítajY(y);
int šírkaObrázka = obrázok.getWidth(null);
int výškaObrázka = obrázok.getHeight(null);
if (šírkaObrázka < 0 || výškaObrázka < 0)
throw new RuntimeException("Obrázok je poškodený!");
if (obrázok instanceof Obrázok)((Obrázok)obrázok).
kresliNa((int)prepočítanéX, (int)prepočítanéY, vyrovnávaciaPamäťGrafikyPlátna);else
vyrovnávaciaPamäťGrafikyPlátna.drawImage(obrázok,
(int)prepočítanéX, (int)prepočítanéY, null);automatickéPrekreslenie();}
public void obrazok(double x, double y, Image obrázok) { obrázok(x, y, obrázok); }
public void uložObrázok(String súbor){uložObrázok(súbor, false);}
public void ulozObrazok(String súbor) { uložObrázok(súbor); }
public void uložObrázok(String súbor, boolean prepísať){
File uložiťDo = new File(súbor);
if (!prepísať && uložiťDo.exists())
throw new RuntimeException("Súbor „" + súbor + "“ jestvuje!");
String prípona = súbor.substring(súbor.lastIndexOf('.') + 1);
if (prípona.toLowerCase().equals("png")){
try { ImageIO.write(vyrovnávaciaPamäťObrázkaPlátna, prípona, uložiťDo); }
catch (IOException e) { vypíšChybovéHlásenia(e, true); }}
else if (prípona.toLowerCase().equals("jpg")){
WritableRaster raster = vyrovnávaciaPamäťObrázkaPlátna.getRaster();
WritableRaster novýRaster = raster.createWritableChild(
0, 0, šírkaPlátna, výškaPlátna,0, 0, new int[] {0, 1, 2});
DirectColorModel farebnýModel = (DirectColorModel)
vyrovnávaciaPamäťObrázkaPlátna.getColorModel();
DirectColorModel novýFarebnýModel = new
DirectColorModel(farebnýModel.getPixelSize(),farebnýModel.getRedMask(),farebnýModel.getGreenMask(),farebnýModel.getBlueMask());
BufferedImage rgbBuffer = new BufferedImage(
novýFarebnýModel, novýRaster, false, null);
try { ImageIO.write(rgbBuffer, prípona, uložiťDo); }
catch (IOException e) { vypíšChybovéHlásenia(e, true); }}else{
throw new RuntimeException("Neplatný typ súboru: " + prípona);}}
public void ulozObrazok(String súbor, boolean prepísať) { uložObrázok(súbor, prepísať); }public void vymaž(){
posunutieTextovX = posunutieTextovY = 0;
zmenaFarbyKonzoly = farbaTextu();vnútornáKonzola.clear();
súradniceKonzolyAplikované = false;zmenaSúradnícKonzoly = null;
if (null == originálPlátna) originálPlátna = ((DataBufferInt)
vyrovnávaciaPamäťObrázkaPlátna.getRaster().getDataBuffer()).getData();
Arrays.fill(originálPlátna, 0);if (právePrekresľujem) return;if (null != počúvadlo){počúvadlo.vymazanie();}automatickéPrekreslenie();}
public void vymaz() { vymaž(); }public void vymažTexty(){
posunutieTextovX = posunutieTextovY = 0;
zmenaFarbyKonzoly = farbaTextu();vnútornáKonzola.clear();
súradniceKonzolyAplikované = false;zmenaSúradnícKonzoly = null;automatickéPrekreslenie();}
public void vymazTexty() { vymažTexty(); }public void vymažGrafiku(){
if (null == originálPlátna) originálPlátna = ((DataBufferInt)
vyrovnávaciaPamäťObrázkaPlátna.getRaster().getDataBuffer()).getData();
Arrays.fill(originálPlátna, 0);if (právePrekresľujem) return;if (null != počúvadlo)synchronized (zámokUdalostí){počúvadlo.vymazanie();}automatickéPrekreslenie();}
public void vymazGrafiku() { vymažGrafiku(); }public void vyplň(Color farba){
vyrovnávaciaPamäťGrafikyPlátna.setColor(farba);
vyrovnávaciaPamäťGrafikyPlátna.fillRect(0, 0,šírkaPlátna, výškaPlátna);if (právePrekresľujem) return;automatickéPrekreslenie();}
public void vypln(Color farba) { vyplň(farba); }
public void vyplň(Farebnosť objekt) { vyplň(objekt.farba()); }
public void vypln(Farebnosť objekt) { vyplň(objekt); }
public Farba vyplň(int r, int g, int b){
Farba nováFarba = new Farba(r, g, b);vyplň(nováFarba);return nováFarba;}
public Farba vypln(int r, int g, int b) { return vyplň(r, g, b); }
public Farba vyplň(int r, int g, int b, int a){
Farba nováFarba = new Farba(r, g, b, a);vyplň(nováFarba);return nováFarba;}
public Farba vypln(int r, int g, int b, int a) { return vyplň(r, g, b, a); }
public void vyplň(String súbor){
BufferedImage obrázok = (BufferedImage)súborNaObrázok(súbor);
vyrovnávaciaPamäťGrafikyPlátna.
setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(),obrázok.getHeight())));
vyrovnávaciaPamäťGrafikyPlátna.fillRect(0, 0,šírkaPlátna, výškaPlátna);if (právePrekresľujem) return;automatickéPrekreslenie();}
public void vypln(String súbor) { vyplň(súbor); }
public void vyplň(BufferedImage obrázok){
float priehľadnosť = (obrázok instanceof Obrázok) ? (float)
((Obrázok)obrázok).priehľadnosť : 1.0f;if (priehľadnosť > 0){
vyrovnávaciaPamäťGrafikyPlátna.
setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(null),obrázok.getHeight(null))));if (priehľadnosť < 1){Composite záloha =
vyrovnávaciaPamäťGrafikyPlátna.getComposite();
vyrovnávaciaPamäťGrafikyPlátna.setComposite(AlphaComposite.getInstance(
AlphaComposite.SRC_OVER, priehľadnosť));
vyrovnávaciaPamäťGrafikyPlátna.fillRect(0, 0,šírkaPlátna, výškaPlátna);
vyrovnávaciaPamäťGrafikyPlátna.setComposite(záloha);}else
vyrovnávaciaPamäťGrafikyPlátna.fillRect(0, 0,šírkaPlátna, výškaPlátna);if (!právePrekresľujem)automatickéPrekreslenie();}}
public void vypln(BufferedImage obrázok) { vyplň(obrázok); }
public void vylejFarbu(double x, double y, Color farba){VykonajVObrázku.vylejFarbu(
vyrovnávaciaPamäťObrázkaPlátna,x, y, farba);if (právePrekresľujem) return;automatickéPrekreslenie();}
public void vylejFarbu(double x, double y, Farebnosť objekt)
{ vylejFarbu(x, y, objekt.farba()); }
public Farba vylejFarbu(double x, double y, int r, int g, int b){
Farba nováFarba = new Farba(r, g, b);vylejFarbu(x, y, nováFarba);return nováFarba;}
public Farba vylejFarbu(double x, double y, int r, int g, int b, int a){
Farba nováFarba = new Farba(r, g, b, a);vylejFarbu(x, y, nováFarba);return nováFarba;}
public void vylejFarbu(Point2D bod, Color farba){VykonajVObrázku.vylejFarbu(
vyrovnávaciaPamäťObrázkaPlátna,
bod.getX(), bod.getY(), farba);if (právePrekresľujem) return;automatickéPrekreslenie();}
public void vylejFarbu(Point2D bod, Farebnosť objekt)
{ vylejFarbu(bod, objekt.farba()); }
public Farba vylejFarbu(Point2D bod, int r, int g, int b){
Farba nováFarba = new Farba(r, g, b);vylejFarbu(bod, nováFarba);return nováFarba;}
public Farba vylejFarbu(Point2D bod, int r, int g, int b, int a){
Farba nováFarba = new Farba(r, g, b, a);vylejFarbu(bod, nováFarba);return nováFarba;}
public void vylejFarbu(GRobot ktorý)
{ vylejFarbu(ktorý.aktuálneX, ktorý.aktuálneY, ktorý.farbaPera); }
public void rozmaž(int opakovanie, int rozsah, Color pozadie){
VykonajVObrázku.rozmaž(vyrovnávaciaPamäťObrázkaPlátna,
vyrovnávaciaPamäťGrafikyPlátna, opakovanie, rozsah, pozadie);automatickéPrekreslenie();}
public void rozmaz(int opakovanie, int rozsah, Color pozadie)
{ rozmaž(opakovanie, rozsah, pozadie); }
public void rozmaž(int opakovanie, Color pozadie)
{ rozmaž(opakovanie, 1, pozadie); }
public void rozmaz(int opakovanie, Color pozadie)
{ rozmaž(opakovanie, 1, pozadie); }
public void rozmaž(Color pozadie) { rozmaž(1, 1, pozadie); }
public void rozmaz(Color pozadie) { rozmaž(1, 1, pozadie); }
public void rozmaž(int opakovanie, int rozsah, Farebnosť pozadie){
VykonajVObrázku.rozmaž(vyrovnávaciaPamäťObrázkaPlátna,
vyrovnávaciaPamäťGrafikyPlátna, opakovanie, rozsah,pozadie.farba());automatickéPrekreslenie();}
public void rozmaz(int opakovanie, int rozsah, Farebnosť pozadie)
{ rozmaž(opakovanie, rozsah, pozadie); }
public void rozmaž(int opakovanie, Farebnosť pozadie)
{ rozmaž(opakovanie, 1, pozadie.farba()); }
public void rozmaz(int opakovanie, Farebnosť pozadie)
{ rozmaž(opakovanie, 1, pozadie.farba()); }
public void rozmaž(Farebnosť pozadie) { rozmaž(1, 1, pozadie.farba()); }
public void rozmaz(Farebnosť pozadie) { rozmaž(1, 1, pozadie.farba()); }
public void rozmaž(int opakovanie, int rozsah)
{ rozmaž(opakovanie, rozsah, farbaPozadia); }
public void rozmaz(int opakovanie, int rozsah)
{ rozmaž(opakovanie, rozsah, farbaPozadia); }
public void rozmaž(int opakovanie)
{ rozmaž(opakovanie, 1, farbaPozadia); }
public void rozmaz(int opakovanie)
{ rozmaž(opakovanie, 1, farbaPozadia); }
public void rozmaž() { rozmaž(1, 1, farbaPozadia); }
public void rozmaz() { rozmaž(1, 1, farbaPozadia); }
public void rozmaž(int opakovanie, int rozsah,int bgr, int bgg, int bgb){
rozmaž(opakovanie, rozsah, new Farba(bgr, bgg, bgb));}
public void rozmaz(int opakovanie, int rozsah, int bgr, int bgg, int bgb)
{ rozmaž(opakovanie, rozsah, new Farba(bgr, bgg, bgb)); }
public void rozmaž(int opakovanie, int bgr, int bgg, int bgb)
{ rozmaž(opakovanie, 1, new Farba(bgr, bgg, bgb)); }
public void rozmaz(int opakovanie, int bgr, int bgg, int bgb)
{ rozmaž(opakovanie, 1, new Farba(bgr, bgg, bgb)); }
public void rozmaž(int bgr, int bgg, int bgb)
{ rozmaž(1, 1, new Farba(bgr, bgg, bgb)); }
public void rozmaz(int bgr, int bgg, int bgb)
{ rozmaž(1, 1, new Farba(bgr, bgg, bgb)); }
public void roluj(double Δx, double Δy){
VykonajVObrázku.roluj(vyrovnávaciaPamäťObrázkaPlátna,(int)Δx, (int)Δy);automatickéPrekreslenie();}
public void pretoč(double Δx, double Δy){
VykonajVObrázku.pretoč(vyrovnávaciaPamäťObrázkaPlátna,(int)Δx, (int)Δy);automatickéPrekreslenie();}
public void pretoc(double Δx, double Δy) { pretoč(Δx, Δy); }
public void rolujTexty(int Δx, int Δy){posunutieTextovX += Δx;posunutieTextovY += Δy;automatickéPrekreslenie();}public void rolujTexty(){
posunutieTextovX += 8 * rolovanieKolieskomMyšiX *
poslednáUdalosťRolovania.getScrollAmount();
posunutieTextovY += 8 * rolovanieKolieskomMyšiY *
poslednáUdalosťRolovania.getScrollAmount();automatickéPrekreslenie();}
public void posunutieTextovX(int nováHodnota){
posunutieTextovX = nováHodnota;automatickéPrekreslenie();}
public void posunutieTextovY(int nováHodnota){
posunutieTextovY = nováHodnota;automatickéPrekreslenie();}
public int posunutieTextovX() { return posunutieTextovX; }
public int posunutieTextovY() { return posunutieTextovY; }
public void posunutieTextov(int x, int y){posunutieTextovX = x;posunutieTextovY = y;automatickéPrekreslenie();}public Point posunutieTextov()
{ return new Point(posunutieTextovX, posunutieTextovY); }
public boolean textyDoSchránky(){
final StringBuffer texty = new StringBuffer();
texty.setLength(0); prevezmiTexty(texty);
return Schránka.text(texty.toString());}
public boolean textyDoSchranky() { return textyDoSchránky(); }
public boolean textDoSchránky() { return textyDoSchránky(); }
public boolean textDoSchranky() { return textyDoSchránky(); }
public boolean obrázokDoSchránky()
{ return Schránka.obrázok(vyrovnávaciaPamäťObrázkaPlátna); }
public boolean obrazokDoSchranky() { return obrázokDoSchránky(); }
public boolean grafikaDoSchránky() { return obrázokDoSchránky(); }
public boolean grafikaDoSchranky() { return obrázokDoSchránky(); }}
public static class Platno extends Plátno implements Priehladnost { private Platno() {} }
public final static Plátno podlaha = new Plátno();
public final static Plátno strop = new Plátno();public static class Súbor{
private BufferedWriter zápis = null;
private BufferedReader čítanie = null;
private boolean prvýRiadok = false;
private final StringBuffer načítanýRiadok = new StringBuffer();
private final Vector<String> vlastnosťNázov   = new Vector<String>();
private final Vector<String> vlastnosťHodnota = new Vector<String>();
private final Vector<Boolean> vlastnosťNaZápis =new Vector<Boolean>();
private boolean zachovajNepoužitéVlastnosti = true;
private boolean vlastnostiNačítané = false;
private String mennýPriestorVlastností = null;
private int naposledyZapísanáVlastnosť = -1;
private static void overPlatnosťPriečinka(File priečinok) throws FileNotFoundException, IllegalArgumentException{if (null == priečinok)
throw new IllegalArgumentException("Názov priečinka nesmie by prázdny.");if (!priečinok.exists())
throw new FileNotFoundException("Priečinok „" + priečinok + "” nejestvuje.");if (!priečinok.isDirectory())
throw new IllegalArgumentException("Zadaná cesta „" + priečinok + "“ nie je priečinok.");if (!priečinok.canRead())
throw new IllegalArgumentException("Priečinok „" + priečinok + "“ nie je možné čítať.");}
private void zapisujVlastnosti() throws IOException{
for (int i = 0; i < vlastnosťNázov.size(); ++i){
if (zachovajNepoužitéVlastnosti ||vlastnosťNaZápis.elementAt(i)){
String názov = vlastnosťNázov.elementAt(i);
if (názov.equals("")) zapíšRiadok(""); else{
String hodnota = vlastnosťHodnota.elementAt(i);
if (-1 != hodnota.indexOf('\n') ||-1 != hodnota.indexOf('\r') ||-1 != hodnota.indexOf('\\')){int indexOf = 0;StringBuffer upravenáHodnota =new StringBuffer(hodnota);
while (-1 != (indexOf = upravenáHodnota.indexOf("\\", indexOf))){
upravenáHodnota.replace(indexOf,indexOf + 1, "\\\\");indexOf += 2;}indexOf = 0;
while (-1 != (indexOf = upravenáHodnota.indexOf("\n", indexOf)))
upravenáHodnota.replace(indexOf,indexOf + 1, "\\n");indexOf = 0;
while (-1 != (indexOf = upravenáHodnota.indexOf("\r", indexOf)))
upravenáHodnota.replace(indexOf,indexOf + 1, "\\r");if (názov.startsWith(";"))
zapíšRiadok(";" + upravenáHodnota);else
zapíšRiadok(názov + "=" + upravenáHodnota);}else{if (názov.startsWith(";"))zapíšRiadok(";" + hodnota);else
zapíšRiadok(názov + "=" + hodnota);}}}}}
private void overPlatnosťNázvu(String názov) throws IllegalArgumentException{if (názov.equals(""))
throw new IllegalArgumentException("Názov vlastnosti nesmie byť prázdny!");if (názov.startsWith(";"))
throw new IllegalArgumentException("Názov vlastnosti nesmie začínať znakom komentára!");if (-1 != názov.indexOf('.'))
throw new IllegalArgumentException("Názov vlastnosti nesmie obsahovať bodku!");if (-1 != názov.indexOf('='))
throw new IllegalArgumentException("Názov vlastnosti nesmie obsahovať znak rovná sa!");}
private final static String nullString = "null";
private Long prevezmiCeléČíslo(StringBuffer reťazec){
if (0 == reťazec.length()) return null;Long číslo = null;
int indexOf = reťazec.indexOf(" ");while (0 == indexOf){reťazec.deleteCharAt(0);
if (0 == reťazec.length()) return null;
indexOf = reťazec.indexOf(" ");}if (indexOf == -1){try{
if (!reťazec.toString().equalsIgnoreCase(nullString))
číslo = Long.valueOf(reťazec.toString());reťazec.setLength(0);}
catch (Exception e) { vypíšChybovéHlásenia(e, false); }}else{try{
if (!reťazec.substring(0, indexOf).equalsIgnoreCase(nullString))
číslo = Long.valueOf(reťazec.substring(0, indexOf));
reťazec.delete(0, indexOf + 1);}
catch (Exception e) { vypíšChybovéHlásenia(e); }}return číslo;}
private Double prevezmiReálneČíslo(StringBuffer reťazec){
if (0 == reťazec.length()) return null;Double číslo = null;
int indexOf = reťazec.indexOf(" ");while (0 == indexOf){reťazec.deleteCharAt(0);
if (0 == reťazec.length()) return null;
indexOf = reťazec.indexOf(" ");}if (indexOf == -1){try{
if (!reťazec.toString().equalsIgnoreCase(nullString))
číslo = Double.valueOf(reťazec.toString());reťazec.setLength(0);}
catch (Exception e) { vypíšChybovéHlásenia(e, false); }}else{try{
if (!reťazec.substring(0, indexOf).equalsIgnoreCase
(nullString)) číslo = Double.valueOf
(reťazec.substring(0, indexOf));
reťazec.delete(0, indexOf + 1);}
catch (Exception e) { vypíšChybovéHlásenia(e); }}return číslo;}
private Boolean prevezmiBoolean(StringBuffer reťazec){
if (0 == reťazec.length()) return null;Boolean hodnota = null;
int indexOf = reťazec.indexOf(" ");while (0 == indexOf){reťazec.deleteCharAt(0);
if (0 == reťazec.length()) return null;
indexOf = reťazec.indexOf(" ");}if (indexOf == -1){
if (!reťazec.toString().equalsIgnoreCase(nullString))
hodnota = Boolean.valueOf(reťazec.toString());reťazec.setLength(0);}else{
if (!reťazec.substring(0, indexOf).equalsIgnoreCase(nullString))
hodnota = Boolean.valueOf(reťazec.substring(0, indexOf));
reťazec.delete(0, indexOf + 1);}return hodnota;}
private void čítajVlastnosti() throws IOException,IllegalArgumentException{
if (vlastnostiNačítané) return;if (null == čítanie)
throw new IOException("Nie je otvorený súbor na čítanie.");
String reťazec, názov, hodnota;
while (null != (reťazec = čítajRiadok())){if (reťazec.equals("")){vlastnosťNázov.add("");vlastnosťHodnota.add("");vlastnosťNaZápis.add(false);continue;}int indexOf;if (reťazec.startsWith(";")){
hodnota = reťazec.substring(1);
if (-1 != hodnota.indexOf('\\')){
StringBuffer upravenáHodnota = new StringBuffer(hodnota);
for (indexOf = 0; -1 != (indexOf = upravenáHodnota.indexOf("\\", indexOf)); ++indexOf){
upravenáHodnota.deleteCharAt(indexOf);
switch (upravenáHodnota.charAt(indexOf)){
case 'n': upravenáHodnota.setCharAt(indexOf, '\n'); break;
case 'r': upravenáHodnota.setCharAt(indexOf, '\r'); break;
case 't': upravenáHodnota.setCharAt(indexOf, '\t'); break;
case 'b': upravenáHodnota.setCharAt(indexOf, '\b'); break;
case 'f': upravenáHodnota.setCharAt(indexOf, '\f'); break;}}
hodnota = new String(upravenáHodnota);}vlastnosťNázov.add(";");vlastnosťHodnota.add(hodnota);vlastnosťNaZápis.add(false);continue;}
indexOf = reťazec.indexOf("=");if (-1 == indexOf){názov = new String(reťazec);hodnota = new String("");}else{
názov = reťazec.substring(0, indexOf);
hodnota = reťazec.substring(1 + indexOf);}názov = názov.trim();if (názov.equals(""))
throw new IllegalArgumentException("V súbore sa nachádza vlastnosť bez názvu!");if (názov.startsWith(";"))
throw new IllegalArgumentException("V súbore sa nachádza vlastnosť začínajúca znakom komentára!");
if (-1 != vlastnosťNázov.indexOf(názov))
throw new IllegalArgumentException("V súbore sa nachádza zdvojená vlastnosť: " + názov);
if (-1 != hodnota.indexOf('\\')){
StringBuffer upravenáHodnota = new StringBuffer(hodnota);
for (indexOf = 0; -1 != (indexOf = upravenáHodnota.indexOf("\\", indexOf)); ++indexOf){
upravenáHodnota.deleteCharAt(indexOf);
switch (upravenáHodnota.charAt(indexOf)){
case 'n': upravenáHodnota.setCharAt(indexOf, '\n'); break;
case 'r': upravenáHodnota.setCharAt(indexOf, '\r'); break;
case 't': upravenáHodnota.setCharAt(indexOf, '\t'); break;
case 'b': upravenáHodnota.setCharAt(indexOf, '\b'); break;
case 'f': upravenáHodnota.setCharAt(indexOf, '\f'); break;}}
hodnota = new String(upravenáHodnota);}vlastnosťNázov.add(názov);vlastnosťHodnota.add(hodnota);vlastnosťNaZápis.add(false);}vlastnostiNačítané = true;}
private String čítanieRiadka() throws IOException{if (prvýRiadok){
String riadok = čítanie.readLine();
if (null != riadok && riadok.length() > 0 &&riadok.charAt(0) == '\uFEFF')riadok = riadok.substring(1);prvýRiadok = false;return riadok;}return čítanie.readLine();}
private boolean nieSúĎalšieÚdaje() throws IOException{if (null == čítanie)
throw new IOException("Nie je otvorený súbor na čítanie.");
while (0 == načítanýRiadok.length() || načítanýRiadok.equals(" ")){načítanýRiadok.setLength(0);
String riadok = čítanieRiadka();
if (null == riadok) return true;načítanýRiadok.append(riadok);}return false;}
public static String[] zoznamSúborov(String cesta) throws FileNotFoundException, IllegalArgumentException{
File priečinok = new File(cesta);try{
overPlatnosťPriečinka(priečinok);}
catch (FileNotFoundException notFound){String výslednýZoznam[] =
zoznamZJarSúboru(null, cesta, true, false);if (null == výslednýZoznam){
if (null == cesta || 0 != cesta.length())throw notFound;priečinok = new File(".");}else return výslednýZoznam;}
File zoznamPoložiek[] = priečinok.listFiles();
Vector<String> zoznam = new Vector<String>();
for (int i = 0; i < zoznamPoložiek.length; i++)
if (zoznamPoložiek[i].isFile())
zoznam.add(zoznamPoložiek[i].getName());
if (0 == zoznam.size()) return null;
String výslednýZoznam[] = new String[zoznam.size()];
for (int i = 0; i < zoznam.size(); i++)
výslednýZoznam[i] = zoznam.get(i);return výslednýZoznam;}
public static String[] zoznamSuborov(String cesta) throws FileNotFoundException, IllegalArgumentException
{ return zoznamSúborov(cesta); }
public static String[] zoznamPriečinkov(String cesta) throws FileNotFoundException, IllegalArgumentException{
File priečinok = new File(cesta);try{
overPlatnosťPriečinka(priečinok);}
catch (FileNotFoundException notFound){String výslednýZoznam[] =
zoznamZJarSúboru(null, cesta, false, true);if (null == výslednýZoznam){
if (null == cesta || 0 != cesta.length())throw notFound;priečinok = new File(".");}else return výslednýZoznam;}
File zoznamPoložiek[] = priečinok.listFiles();
Vector<String> zoznam = new Vector<String>();
for (int i = 0; i < zoznamPoložiek.length; i++)
if (zoznamPoložiek[i].isDirectory())
zoznam.add(zoznamPoložiek[i].getName());
if (0 == zoznam.size()) return null;
String výslednýZoznam[] = new String[zoznam.size()];
for (int i = 0; i < zoznam.size(); i++)
výslednýZoznam[i] = zoznam.get(i);return výslednýZoznam;}
public static String[] zoznamPriecinkov(String cesta) throws FileNotFoundException, IllegalArgumentException
{ return zoznamPriečinkov(cesta); }
public static String[] zoznamSúborovAPriečinkov(String cesta) throws FileNotFoundException, IllegalArgumentException{
File priečinok = new File(cesta);try{
overPlatnosťPriečinka(priečinok);}
catch (FileNotFoundException notFound){String výslednýZoznam[] =
zoznamZJarSúboru(null, cesta, true, true);if (null == výslednýZoznam){
if (null == cesta || 0 != cesta.length())throw notFound;priečinok = new File(".");}else return výslednýZoznam;}
File zoznamPoložiek[] = priečinok.listFiles();
Vector<String> zoznam = new Vector<String>();
for (int i = 0; i < zoznamPoložiek.length; i++)
if (zoznamPoložiek[i].isFile() ||
zoznamPoložiek[i].isDirectory())
zoznam.add(zoznamPoložiek[i].getName());
if (0 == zoznam.size()) return null;
String výslednýZoznam[] = new String[zoznam.size()];
for (int i = 0; i < zoznam.size(); i++)
výslednýZoznam[i] = zoznam.get(i);return výslednýZoznam;}
public static String[] zoznamSuborovAPriecinkov(String cesta) throws FileNotFoundException, IllegalArgumentException
{ return zoznamSúborovAPriečinkov(cesta); }
public static String[] zoznam(String cesta) throws FileNotFoundException, IllegalArgumentException{
File priečinok = new File(cesta);try{
overPlatnosťPriečinka(priečinok);}
catch (FileNotFoundException notFound){String výslednýZoznam[] =
zoznamZJarSúboru(null, cesta, true, true);if (null == výslednýZoznam){
if (null == cesta || 0 != cesta.length())throw notFound;priečinok = new File(".");}else return výslednýZoznam;}
File zoznamPoložiek[] = priečinok.listFiles();
Vector<String> zoznam = new Vector<String>();
for (int i = 0; i < zoznamPoložiek.length; i++)
zoznam.add(zoznamPoložiek[i].getName());
if (0 == zoznam.size()) return null;
String výslednýZoznam[] = new String[zoznam.size()];
for (int i = 0; i < zoznam.size(); i++)
výslednýZoznam[i] = zoznam.get(i);return výslednýZoznam;}
public static boolean existuje(String názov)
{ return new File(názov).exists(); }
public static boolean jestvuje(String názov)
{ return new File(názov).exists(); }
public static boolean vytvorPriečinok(String názov)
{ return new File(názov).mkdir(); }
public static boolean vytvorPriecinok(String názov)
{ return new File(názov).mkdir(); }
public static boolean novýPriečinok(String názov)
{ return new File(názov).mkdir(); }
public static boolean novyPriecinok(String názov)
{ return new File(názov).mkdir(); }
public static boolean jeSúbor(String názov)
{ return new File(názov).isFile(); }
public static boolean jeSubor(String názov)
{ return new File(názov).isFile(); }
public static boolean jePriečinok(String názov)
{ return new File(názov).isDirectory(); }
public static boolean jePriecinok(String názov)
{ return new File(názov).isDirectory(); }
public static void kopíruj(String zdroj, String cieľ,
boolean prepísať) throws FileNotFoundException, IOException{
File súborZdroja = new File(zdroj);
File súborCieľa = new File(cieľ);
if (!prepísať && súborCieľa.exists())
throw new IOException("Cieľový súbor „" + cieľ +"“ už jestvuje!");
if (prepísať && súborCieľa.exists() && !súborCieľa.isFile())
throw new IOException("Cieľový súbor „" + cieľ +"“ nie je súbor!");InputStream čítanie;if (súborZdroja.exists()){if (!súborZdroja.isFile())
throw new IOException("Zdrojový súbor „" + zdroj +"“ nie je súbor!");
čítanie = new FileInputStream(súborZdroja);}else{try{čítanie = GRobot.class.
getResourceAsStream(zdroj.replace('\\', '/'));}catch (Exception e){
throw new FileNotFoundException("Zdrojový súbor „" +zdroj + "“ nejestvuje!");}}
FileOutputStream zápis = new FileOutputStream(súborCieľa);
byte[] zásobník = new byte[32768];int dĺžka;
while ((dĺžka = čítanie.read(zásobník)) > 0){
zápis.write(zásobník, 0, dĺžka);}čítanie.close();zápis.close();if (súborZdroja.exists())
súborCieľa.setLastModified(súborZdroja.lastModified());else{
URL url = GRobot.class.getResource(zdroj.replace('\\', '/'));
long čas = url.openConnection().getLastModified();
if (0 != čas) súborCieľa.setLastModified(čas);}}
public static void kopiruj(String zdroj, String cieľ,
boolean prepísať) throws FileNotFoundException, IOException
{ kopíruj(zdroj, cieľ, prepísať); }
public static void kopíruj(String zdroj, String cieľ)
throws FileNotFoundException, IOException
{ kopíruj(zdroj, cieľ, false); }
public static void kopiruj(String zdroj, String cieľ)
throws FileNotFoundException, IOException
{ kopíruj(zdroj, cieľ, false); }
public static void pripoj(String zdroj, String cieľ)
throws FileNotFoundException, IOException{
File súborZdroja = new File(zdroj);
File súborCieľa = new File(cieľ);
if (súborCieľa.exists() && !súborCieľa.isFile())
throw new IOException("Cieľový súbor „" + cieľ +"“ nie je súbor!");InputStream čítanie;if (súborZdroja.exists()){if (!súborZdroja.isFile())
throw new IOException("Zdrojový súbor „" + zdroj +"“ nie je súbor!");
čítanie = new FileInputStream(súborZdroja);}else{try{čítanie = GRobot.class.
getResourceAsStream(zdroj.replace('\\', '/'));}catch (Exception e){
throw new FileNotFoundException("Zdrojový súbor „" +zdroj + "“ nejestvuje!");}}
FileOutputStream zápis = new FileOutputStream(súborCieľa, true);
byte[] zásobník = new byte[32768];int dĺžka;
while ((dĺžka = čítanie.read(zásobník)) > 0){
zápis.write(zásobník, 0, dĺžka);}čítanie.close();zápis.close();}
public static boolean premenuj(String zdroj, String cieľ)
{ return new File(zdroj).renameTo(new File(cieľ)); }
public static boolean presuň(String zdroj, String cieľovýPriečinok){
File zdrojováPoložka = new File(zdroj);
File cieľováPoložka = new File(cieľovýPriečinok);
return zdrojováPoložka.renameTo(new
File(cieľováPoložka, zdrojováPoložka.getName()));}
public static boolean presun(String zdroj, String cieľovýPriečinok)
{ return presuň(zdroj, cieľovýPriečinok); }
public static boolean vymaž(String názov)
{ return new File(názov).delete(); }
public static boolean vymaz(String názov)
{ return new File(názov).delete(); }
public static long naposledyUpravený(String názov){
return new File(názov).lastModified();}
public long naposledyUpraveny(String názov) { return naposledyUpravený(názov); }
public String mennýPriestorVlastností()
{ return mennýPriestorVlastností; }
public String mennyPriestorVlastnosti()
{ return mennýPriestorVlastností; }
public void mennýPriestorVlastností(String novýMennýPriestor){if (null == novýMennýPriestor){
mennýPriestorVlastností = null;return;}
if (novýMennýPriestor.equals(""))
throw new IllegalArgumentException(
"Menný priestor nesmie byť prázdny!");
if (novýMennýPriestor.endsWith("."))
throw new IllegalArgumentException(
"Menný priestor nesmie končiť bodkou!");
if (novýMennýPriestor.startsWith("."))
throw new IllegalArgumentException(
"Menný priestor nesmie začínať bodkou!");
if (-1 != novýMennýPriestor.indexOf('='))
throw new IllegalArgumentException(
"Menný priestor nesmie obsahovať znak rovná sa!");
mennýPriestorVlastností = novýMennýPriestor;}
public void mennyPriestorVlastnosti(String novýMennýPriestor)
{ mennýPriestorVlastností(novýMennýPriestor); }
public static String dialógOtvoriť(String titulok){
FileDialog dialóg = new FileDialog(svet, titulok,FileDialog.LOAD);dialóg.setVisible(true);if (null != dialóg.getFile())
return dialóg.getDirectory() + File.separator +dialóg.getFile();return null;}
public static String dialogOtvorit(String titulok) { return dialógOtvoriť(titulok); }
public static String dialógUložiť(String titulok){
FileDialog dialóg = new FileDialog(svet, titulok,FileDialog.SAVE);dialóg.setVisible(true);if (null != dialóg.getFile())
return dialóg.getDirectory() + File.separator +dialóg.getFile();return null;}
public static String dialogUlozit(String titulok) { return dialógUložiť(titulok); }
public void otvorNaZápis(String názovSúboru) throws IOException, NullPointerException{if (null == názovSúboru)
throw new NullPointerException("Názov súboru nesmie byť zamlčaný!");zavri();
zápis = new BufferedWriter(new OutputStreamWriter(
new FileOutputStream(názovSúboru), "UTF-8"));}
public void otvorNaZapis(String názovSúboru) throws IOException, NullPointerException{ otvorNaZápis(názovSúboru); }
public void otvorNaZápis(String názovSúboru, boolean pripojiť) throws IOException, NullPointerException{if (null == názovSúboru)
throw new NullPointerException("Názov súboru nesmie byť zamlčaný!");zavri();
zápis = new BufferedWriter(new OutputStreamWriter(
new FileOutputStream(názovSúboru, pripojiť), "UTF-8"));}
public void otvorNaZapis(String názovSúboru, boolean pripojiť)
throws IOException, NullPointerException
{ otvorNaZápis(názovSúboru, pripojiť); }
public void otvorNaČítanie(String názovSúboru) throws IOException, NullPointerException{if (null == názovSúboru)
throw new NullPointerException("Názov súboru nesmie byť zamlčaný!");zavri();
FileNotFoundException notFound = null;try{
čítanie = new BufferedReader(new InputStreamReader(
new FileInputStream(názovSúboru), "UTF-8"));prvýRiadok = true;vlastnostiNačítané = false;vlastnosťNázov.clear();vlastnosťHodnota.clear();vlastnosťNaZápis.clear();return;}
catch (FileNotFoundException e){notFound = e;}try{
čítanie = new BufferedReader(new
InputStreamReader(GRobot.class.
getResourceAsStream(názovSúboru.
replace('\\', '/')), "UTF-8"));prvýRiadok = true;vlastnostiNačítané = false;vlastnosťNázov.clear();vlastnosťHodnota.clear();vlastnosťNaZápis.clear();}
catch (NullPointerException isNull){
if (null != notFound) throw notFound;throw isNull;}}
public void otvorNaCitanie(String názovSúboru) throws IOException, NullPointerException
{ otvorNaČítanie(názovSúboru); }
public void zavri() throws IOException{if (null != zápis){zapisujVlastnosti();zápis.close();zápis = null;
if (!zachovajNepoužitéVlastnosti)
for (int i = 0; i < vlastnosťNaZápis.size(); ++i)
vlastnosťNaZápis.set(i, false);}if (null != čítanie){čítanie.close();čítanie = null;}prvýRiadok = false;}
public String čítajVlastnosť(String názov, String predvolenáHodnota) throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
return new String(predvolenáHodnota);}
return new String(vlastnosťHodnota.get(indexOf));}
public String citajVlastnost(String názov, String predvolenáHodnota) throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public StringBuffer čítajVlastnosť(String názov, StringBuffer predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
return new StringBuffer(predvolenáHodnota);}
return new StringBuffer(vlastnosťHodnota.get(indexOf));}
public StringBuffer citajVlastnost(String názov, StringBuffer predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public Long čítajVlastnosť(String názov, Long predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
return new Long(predvolenáHodnota);}
String hodnota = vlastnosťHodnota.get(indexOf).trim();
if (hodnota.equalsIgnoreCase(nullString)) return null;return Long.valueOf(hodnota);}
public Long citajVlastnost(String názov, Long predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public Double čítajVlastnosť(String názov, Double predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
return new Double(predvolenáHodnota);}
String hodnota = vlastnosťHodnota.get(indexOf).trim();
if (hodnota.equalsIgnoreCase(nullString)) return null;
return Double.valueOf(hodnota);}
public Double citajVlastnost(String názov, Double predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public Boolean čítajVlastnosť(String názov, Boolean predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
return new Boolean(predvolenáHodnota);}
String hodnota = vlastnosťHodnota.get(indexOf).trim();
if (hodnota.equalsIgnoreCase(nullString)) return null;
return Boolean.valueOf(hodnota);}
public Boolean citajVlastnost(String názov, Boolean predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public int[] čítajVlastnosť(String názov, int[] predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;int[] pole;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
pole = new int[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
StringBuffer reťazec = new StringBuffer(vlastnosťHodnota.get(indexOf));
Vector<Long> vektor = new Vector<Long>();Long hodnota;
while (null != (hodnota = prevezmiCeléČíslo(reťazec)))vektor.add(hodnota);
if (0 == vektor.size() && null != predvolenáHodnota){
pole = new int[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}pole = new int[vektor.size()];
for (int i = 0; i < vektor.size(); ++i)
pole[i] = vektor.elementAt(i).intValue();return pole;}
public int[] citajVlastnost(String názov, int[] predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public float[] čítajVlastnosť(String názov, float[] predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;float[] pole;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
pole = new float[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
StringBuffer reťazec = new StringBuffer(
vlastnosťHodnota.get(indexOf));
Vector<Double> vektor = new Vector<Double>();Double hodnota;
while (null != (hodnota = prevezmiReálneČíslo(reťazec)))vektor.add(hodnota);
if (0 == vektor.size() && null != predvolenáHodnota){
pole = new float[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
pole = new float[vektor.size()];
for (int i = 0; i < vektor.size(); ++i)
pole[i] = vektor.elementAt(i).floatValue();return pole;}
public float[] citajVlastnost(String názov, float[] predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public long[] čítajVlastnosť(String názov, long[] predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;long[] pole;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
pole = new long[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
StringBuffer reťazec = new StringBuffer(vlastnosťHodnota.get(indexOf));
Vector<Long> vektor = new Vector<Long>();Long hodnota;
while (null != (hodnota = prevezmiCeléČíslo(reťazec)))vektor.add(hodnota);
if (0 == vektor.size() && null != predvolenáHodnota){
pole = new long[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
pole = new long[vektor.size()];
for (int i = 0; i < vektor.size(); ++i)
pole[i] = vektor.elementAt(i).longValue();return pole;}
public long[] citajVlastnost(String názov, long[] predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public double[] čítajVlastnosť(String názov, double[] predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;double[] pole;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
pole = new double[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
StringBuffer reťazec = new StringBuffer(
vlastnosťHodnota.get(indexOf));
Vector<Double> vektor = new Vector<Double>();Double hodnota;
while (null != (hodnota = prevezmiReálneČíslo(reťazec)))vektor.add(hodnota);
if (0 == vektor.size() && null != predvolenáHodnota){
pole = new double[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
pole = new double[vektor.size()];
for (int i = 0; i < vektor.size(); ++i)
pole[i] = vektor.elementAt(i).doubleValue();return pole;}
public double[] citajVlastnost(String názov, double[] predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public boolean[] čítajVlastnosť(String názov, boolean[] predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;boolean[] pole;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
pole = new boolean[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
StringBuffer reťazec = new StringBuffer(vlastnosťHodnota.get(indexOf));
Vector<Boolean> vektor = new Vector<Boolean>();Boolean hodnota;
while (null != (hodnota = prevezmiBoolean(reťazec)))vektor.add(hodnota);
if (0 == vektor.size() && null != predvolenáHodnota){
pole = new boolean[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
pole = new boolean[vektor.size()];
for (int i = 0; i < vektor.size(); ++i)
pole[i] = vektor.elementAt(i).booleanValue();return pole;}
public boolean[] citajVlastnost(String názov, boolean[] predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public char[] čítajVlastnosť(String názov, char[] predvolenáHodnota)
throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;
čítajVlastnosti(); int indexOf;char[] pole;
if (-1 == (indexOf = vlastnosťNázov.indexOf(názov))){
if (null == predvolenáHodnota) return null;
pole = new char[predvolenáHodnota.length];
for (int i = 0; i < predvolenáHodnota.length; ++i)
pole[i] = predvolenáHodnota[i];return pole;}
StringBuffer reťazec = new StringBuffer(vlastnosťHodnota.get(indexOf));
pole = new char[reťazec.length()];
for (int i = 0; i < reťazec.length(); ++i)pole[i] = reťazec.charAt(i);return pole;}
public char[] citajVlastnost(String názov, char[] predvolenáHodnota)
throws IOException, IllegalArgumentException
{ return čítajVlastnosť(názov, predvolenáHodnota); }
public boolean zachovávaNepoužitéVlastnosti()
{ return zachovajNepoužitéVlastnosti; }
public boolean zachovavaNepouziteVlastnosti()
{ return zachovajNepoužitéVlastnosti; }
public void zachovajNepoužitéVlastnosti()
{ zachovajNepoužitéVlastnosti = true; }
public void zachovajNepouziteVlastnosti()
{ zachovajNepoužitéVlastnosti = true; }
public void odstraňujNepoužitéVlastnosti()
{ zachovajNepoužitéVlastnosti = false; }
public void odstranujNepouziteVlastnosti()
{ zachovajNepoužitéVlastnosti = false; }
public void zapíšVlastnosť(String názov, Object hodnota) throws IOException, IllegalArgumentException{názov = názov.trim();overPlatnosťNázvu(názov);
if (null != mennýPriestorVlastností)
názov = mennýPriestorVlastností + '.' + názov;if (null == zápis)
throw new IOException("Nie je otvorený súbor na zápis.");StringBuffer reťazec;if (hodnota instanceof int[]){int[] pole = (int[])hodnota;reťazec = new StringBuffer();
for (int i = 0; i < pole.length; ++i)reťazec.append(pole[i] + " ");hodnota = reťazec;}
else if (hodnota instanceof float[]){
float[] pole = (float[])hodnota;reťazec = new StringBuffer();
for (int i = 0; i < pole.length; ++i)reťazec.append(pole[i] + " ");hodnota = reťazec;}
else if (hodnota instanceof long[]){long[] pole = (long[])hodnota;reťazec = new StringBuffer();
for (int i = 0; i < pole.length; ++i)reťazec.append(pole[i] + " ");hodnota = reťazec;}
else if (hodnota instanceof double[]){
double[] pole = (double[])hodnota;reťazec = new StringBuffer();
for (int i = 0; i < pole.length; ++i)reťazec.append(pole[i] + " ");hodnota = reťazec;}
else if (hodnota instanceof boolean[]){
boolean[] pole = (boolean[])hodnota;reťazec = new StringBuffer();
for (int i = 0; i < pole.length; ++i)reťazec.append(pole[i] + " ");hodnota = reťazec;}
else if (hodnota instanceof char[]){reťazec = new StringBuffer();
reťazec.append((char[])hodnota);hodnota = reťazec;}int indexOf;
if (-1 != (indexOf = vlastnosťNázov.indexOf(názov))){
vlastnosťHodnota.set(indexOf, hodnota.toString());
vlastnosťNaZápis.set(indexOf, true);
naposledyZapísanáVlastnosť = indexOf;return;}vlastnosťNázov.add(názov);
vlastnosťHodnota.add(hodnota.toString());vlastnosťNaZápis.add(true);
naposledyZapísanáVlastnosť = vlastnosťNázov.size() - 1;}
public void zapisVlastnost(String názov, Object hodnota) throws IOException, IllegalArgumentException
{ zapíšVlastnosť(názov, hodnota); }
public void zapíšKomentárVlastností(String komentár){++naposledyZapísanáVlastnosť;
if (naposledyZapísanáVlastnosť >= vlastnosťNázov.size()){vlastnosťNázov.add(";");
vlastnosťHodnota.add(komentár);vlastnosťNaZápis.add(true);
naposledyZapísanáVlastnosť = vlastnosťNázov.size();}else{if (vlastnosťNázov.elementAt(
naposledyZapísanáVlastnosť).equals(";")){
vlastnosťHodnota.set(naposledyZapísanáVlastnosť, komentár);
vlastnosťNaZápis.set(naposledyZapísanáVlastnosť, true);}else{
vlastnosťNázov.insertElementAt(";",naposledyZapísanáVlastnosť);
vlastnosťHodnota.insertElementAt(komentár,naposledyZapísanáVlastnosť);
vlastnosťNaZápis.insertElementAt(true,naposledyZapísanáVlastnosť);}}}
public void zapisKomentarVlastnosti(String komentár) { zapíšKomentárVlastností(komentár); }
public void zapíšPrázdnyRiadokVlastností(){++naposledyZapísanáVlastnosť;
if (naposledyZapísanáVlastnosť >= vlastnosťNázov.size()){vlastnosťNázov.add("");vlastnosťHodnota.add("");vlastnosťNaZápis.add(true);
naposledyZapísanáVlastnosť = vlastnosťNázov.size();}else{if (vlastnosťNázov.elementAt(
naposledyZapísanáVlastnosť).equals("")){vlastnosťNaZápis.set(
naposledyZapísanáVlastnosť, true);}else{
vlastnosťNázov.insertElementAt("",naposledyZapísanáVlastnosť);
vlastnosťHodnota.insertElementAt("",naposledyZapísanáVlastnosť);
vlastnosťNaZápis.insertElementAt(true,naposledyZapísanáVlastnosť);}}}
public void zapisPrazdnyRiadokVlastnosti() { zapíšPrázdnyRiadokVlastností(); }
public String čítajRiadok() throws IOException{if (null == čítanie)
throw new IOException("Nie je otvorený súbor na čítanie.");
if (načítanýRiadok.length() > 0){
if (načítanýRiadok.equals(" ")){načítanýRiadok.setLength(0);return čítanieRiadka();}
String riadok = new String(načítanýRiadok);načítanýRiadok.setLength(0);return riadok;}return čítanieRiadka();}
public String citajRiadok() throws IOException { return čítajRiadok(); }
public Long čítajCeléČíslo() throws IOException{
if (nieSúĎalšieÚdaje()) return null;Long číslo = null;
int indexOf = načítanýRiadok.indexOf(" ");while (0 == indexOf){
načítanýRiadok.deleteCharAt(0);
if (nieSúĎalšieÚdaje()) return null;
indexOf = načítanýRiadok.indexOf(" ");}if (-1 == indexOf){try{
číslo = Long.valueOf(načítanýRiadok.toString());načítanýRiadok.setLength(0);}
catch (Exception e) { vypíšChybovéHlásenia(e, false); }}else{try{
číslo = Long.valueOf(načítanýRiadok.substring(0, indexOf));
načítanýRiadok.delete(0, indexOf + 1);}
catch (Exception e) { vypíšChybovéHlásenia(e); }}return číslo;}
public Long citajCeleCislo() throws IOException { return čítajCeléČíslo(); }
public Double čítajReálneČíslo() throws IOException{
if (nieSúĎalšieÚdaje()) return null;Double číslo = null;
int indexOf = načítanýRiadok.indexOf(" ");while (0 == indexOf){
načítanýRiadok.deleteCharAt(0);
if (nieSúĎalšieÚdaje()) return null;
indexOf = načítanýRiadok.indexOf(" ");}if (-1 == indexOf){try{
číslo = Double.valueOf(načítanýRiadok.toString());načítanýRiadok.setLength(0);}
catch (Exception e) { vypíšChybovéHlásenia(e, false); }}else{try{
číslo = Double.valueOf(načítanýRiadok.substring(0,indexOf));
načítanýRiadok.delete(0, indexOf + 1);}
catch (Exception e) { vypíšChybovéHlásenia(e); }}return číslo;}
public Double citajRealneCislo() throws IOException{ return čítajReálneČíslo(); }
public Boolean čítajBoolean() throws IOException{
if (nieSúĎalšieÚdaje()) return null;Boolean hodnota = null;
int indexOf = načítanýRiadok.indexOf(" ");while (0 == indexOf){
načítanýRiadok.deleteCharAt(0);
if (nieSúĎalšieÚdaje()) return null;
indexOf = načítanýRiadok.indexOf(" ");}if (-1 == indexOf){
if (!načítanýRiadok.toString().equalsIgnoreCase(nullString))
hodnota = Boolean.valueOf(načítanýRiadok.toString());načítanýRiadok.setLength(0);}else{
if (!načítanýRiadok.substring(0, indexOf).equalsIgnoreCase(nullString))
hodnota = Boolean.valueOf(načítanýRiadok.substring(0, indexOf));
načítanýRiadok.delete(0, indexOf + 1);}return hodnota;}
public Boolean citajBoolean() throws IOException { return čítajBoolean(); }
public void čítaj(Object... objekty) throws IOException, IllegalArgumentException{if (null == čítanie)
throw new IOException("Nie je otvorený súbor na čítanie.");for (Object obj : objekty){
if (obj instanceof StringBuffer){
((StringBuffer)obj).setLength(0);
((StringBuffer)obj).append(čítajRiadok());}else if (obj instanceof int[]){int[] pole = (int[])obj;Long číslo;
for (int i = 0; i < pole.length; ++i){
if (null != (číslo = this.čítajCeléČíslo()))pole[i] = číslo.intValue();else pole[i] = 0;}}
else if (obj instanceof float[]){float[] pole = (float[])obj;Double číslo;
for (int i = 0; i < pole.length; ++i){
if (null != (číslo = this.čítajReálneČíslo()))pole[i] = číslo.floatValue();else pole[i] = 0;}}
else if (obj instanceof long[]){long[] pole = (long[])obj;Long číslo;
for (int i = 0; i < pole.length; ++i){
if (null != (číslo = this.čítajCeléČíslo()))pole[i] = číslo.longValue();else pole[i] = 0;}}
else if (obj instanceof double[]){double[] pole = (double[])obj;Double číslo;
for (int i = 0; i < pole.length; ++i){
if (null != (číslo = this.čítajReálneČíslo()))pole[i] = číslo.doubleValue();else pole[i] = 0;}}
else if (obj instanceof boolean[]){
boolean[] pole = (boolean[])obj;Boolean hodnota;
for (int i = 0; i < pole.length; ++i){
if (null != (hodnota = this.čítajBoolean()))
pole[i] = hodnota.booleanValue();else pole[i] = false;}}
else if (obj instanceof char[]){char[] pole = (char[])obj;čítanie.read(pole);}else{
throw new IllegalArgumentException(
"Nepovolený údajový typ metódy súbor.čítaj: " +
obj.getClass().getCanonicalName());}}}
public void citaj(Object... objekty) throws IOException, IllegalArgumentException{ čítaj(objekty); }
public void zapíšReťazec(String text) throws IOException{if (null == zápis)
throw new IOException("Nie je otvorený súbor na zápis.");zápis.write(text);}
public void zapisRetazec(String text) throws IOException { zapíšReťazec(text); }
public void zapíšRiadok(String text) throws IOException{if (null == zápis)
throw new IOException("Nie je otvorený súbor na zápis.");zápis.write(text + "\r\n");}
public void zapisRiadok(String text) throws IOException { zapíšRiadok(text); }
public void zapíš(Object... objekty) throws IOException{for (Object obj : objekty){
if (obj instanceof String || obj instanceof StringBuffer)zapíšRiadok(obj.toString());else if (obj instanceof int[]){int[] pole = (int[])obj;
for (int i = 0; i < pole.length; ++i)zapíšReťazec(pole[i] + " ");}
else if (obj instanceof float[]){float[] pole = (float[])obj;
for (int i = 0; i < pole.length; ++i)zapíšReťazec(pole[i] + " ");}
else if (obj instanceof long[]){long[] pole = (long[])obj;
for (int i = 0; i < pole.length; ++i)zapíšReťazec(pole[i] + " ");}
else if (obj instanceof double[]){double[] pole = (double[])obj;
for (int i = 0; i < pole.length; ++i)zapíšReťazec(pole[i] + " ");}
else if (obj instanceof boolean[]){
boolean[] pole = (boolean[])obj;
for (int i = 0; i < pole.length; ++i)zapíšReťazec(pole[i] + " ");}
else if (obj instanceof char[]){
zapíšReťazec(new String((char[])obj));}else zapíšReťazec(obj + " ");}}
public void zapis(Object... objekty) throws IOException { zapíš(objekty); }}
public static class Subor extends Súbor {}
public final Súbor súbor = new Súbor();
public final Súbor subor = súbor;
public static class Obrázok extends BufferedImage implements Priehľadnosť{
private static RenderingHints hints = new RenderingHints(
RenderingHints.KEY_ANTIALIASING,
RenderingHints.VALUE_ANTIALIAS_ON);static{
hints.put(RenderingHints.KEY_RENDERING,
RenderingHints.VALUE_RENDER_QUALITY);
hints.put(RenderingHints.KEY_TEXT_ANTIALIASING,
RenderingHints.VALUE_TEXT_ANTIALIAS_ON);}
private float priehľadnosť = 1.0f;
private final double posunX, posunY;private int[] údajeObrázka;private int[] údajeOperácie;
private final static double faktor = 0.7;private GRobot kreslič = null;
private void kresliNa(int x, int y, Graphics2D grafika){if (priehľadnosť > 0){if (priehľadnosť < 1){
Composite záloha = grafika.getComposite();grafika.setComposite(AlphaComposite.getInstance(
AlphaComposite.SRC_OVER, priehľadnosť));
grafika.drawImage(this, x, y, null);grafika.setComposite(záloha);}else
grafika.drawImage(this, x, y, null);}}
private void kresliNaStred(int x, int y, Graphics2D grafika){if (priehľadnosť > 0){if (priehľadnosť < 1){
Composite záloha = grafika.getComposite();grafika.setComposite(AlphaComposite.getInstance(
AlphaComposite.SRC_OVER, priehľadnosť));grafika.drawImage(this,
x - (šírka / 2), y - (výška / 2), null);grafika.setComposite(záloha);}else grafika.drawImage(this,
x - (šírka / 2), y - (výška / 2), null);}}public final int šírka, sirka;public final int výška, vyska;
public final Graphics2D grafika = this.createGraphics();
{ grafika.addRenderingHints(hints); }public Obrázok(){
super(šírkaPlátna, výškaPlátna,BufferedImage.TYPE_INT_ARGB);
sirka = this.šírka = šírkaPlátna;
vyska = this.výška = výškaPlátna;this.posunX = this.posunY = 0;}
public Obrázok(int šírka, int výška){
super(šírka, výška, BufferedImage.TYPE_INT_ARGB);
sirka = this.šírka = šírka; vyska = this.výška = výška;
this.posunX = -(šírkaPlátna / 2) + (šírka / 2);
this.posunY = -(výškaPlátna / 2) + (výška / 2);
grafika.translate(posunX, posunY);}public Obrázok(Image obrázok){
super(obrázok.getWidth(null), obrázok.getHeight(null),BufferedImage.TYPE_INT_ARGB);
sirka = this.šírka = getWidth(); vyska = this.výška = getHeight();
this.posunX = -(šírkaPlátna / 2) + (šírka / 2);
this.posunY = -(výškaPlátna / 2) + (výška / 2);
grafika.drawImage(obrázok, 0, 0, null);
grafika.translate(posunX, posunY);}
public static Obrázok načítaj(String súbor){
Image obrázokZoSúboru = súborNaObrázok(súbor);
Obrázok novýObrázok = new Obrázok(
obrázokZoSúboru.getWidth(null),
obrázokZoSúboru.getHeight(null));novýObrázok.grafika.translate(
-novýObrázok.posunX, -novýObrázok.posunY);
novýObrázok.grafika.drawImage(obrázokZoSúboru, 0, 0, null);novýObrázok.grafika.translate(
novýObrázok.posunX, novýObrázok.posunY);return novýObrázok;}
public static Obrazok nacitaj(String súbor)
{ return new Obrazok(načítaj(súbor)); }
public int šírka() { return getWidth(); }
public int sirka() { return getWidth(); }
public int výška() { return getHeight(); }
public int vyska() { return getHeight(); }
public Graphics2D grafika() { return grafika; }
public double najmenšieX() { return -šírka / 2; }
public double najmensieX() { return -šírka / 2; }
public double najmenšieY() { return -(výška - 1) / 2; }
public double najmensieY() { return -(výška - 1) / 2; }
public double najväčšieX() { return (šírka - 1) / 2; }
public double najvacsieX() { return (šírka - 1) / 2; }
public double najväčšieY() { return výška / 2; }
public double najvacsieY() { return výška / 2; }public void vymaž(){
if (null == údajeObrázka) údajeObrázka =
((DataBufferInt)getRaster().getDataBuffer()).getData();Arrays.fill(údajeObrázka, 0);}
public void vymaz() { vymaž(); }
public void prepíšBod(double x, double y, Color farba){
setRGB((int)((šírka / 2.0) + x),
(int)((výška / 2.0) - y), farba.getRGB());}
public void prepíšBod(double x, double y, Farebnosť objekt){
setRGB((int)((šírka / 2.0) + x),
(int)((výška / 2.0) - y), objekt.farba().getRGB());}
public void prepíšBod(double x, double y, int farba){
setRGB((int)((šírka / 2.0) + x),
(int)((výška / 2.0) - y), farba);}
public void prepisBod(double x, double y, Color farba){ prepíšBod(x, y, farba); }
public void prepisBod(double x, double y, Farebnosť objekt){ prepíšBod(x, y, objekt); }
public void prepisBod(double x, double y, int farba){ prepíšBod(x, y, farba); }
public GRobot kreslič() { return kreslič; }
public GRobot kreslic() { return kreslič; }
public void kreslič(GRobot kreslič){
if (this.kreslič == kreslič) return;
if (null != this.kreslič) this.kreslič.kresliTvary();this.kreslič = kreslič;
if (null != kreslič) kreslič.nekresliTvary();}
public void kreslic(GRobot kreslič) { kreslič(kreslič); }
public void zrušKresliča() { kreslič(null); }
public void zrusKreslica() { kreslič(null); }public void kresli(Shape tvar){if (null == kreslič) return;
grafika.setColor(kreslič.farbaPera);
grafika.setStroke(kreslič.čiara);grafika.draw(tvar);}public void vyplň(Shape tvar){if (null == kreslič) return;
grafika.setColor(kreslič.farbaPera);grafika.fill(tvar);}
public void vypln(Shape tvar) { vyplň(tvar); }public void vyplň(Color farba){grafika.setColor(farba);
grafika.translate(-posunX, -posunY);
grafika.fillRect(0, 0, šírka, výška);
grafika.translate(posunX, posunY);}
public void vypln(Color farba) { vyplň(farba); }
public void vyplň(Farebnosť objekt){
grafika.setColor(objekt.farba());
grafika.translate(-posunX, -posunY);
grafika.fillRect(0, 0, šírka, výška);
grafika.translate(posunX, posunY);}
public void vypln(Farebnosť objekt) { vyplň(objekt); }
public Farba vyplň(int r, int g, int b){
Farba nováFarba = new Farba(r, g, b);vyplň(nováFarba);return nováFarba;}
public Farba vypln(int r, int g, int b) { return vyplň(r, g, b); }
public Farba vyplň(int r, int g, int b, int a){
Farba nováFarba = new Farba(r, g, b, a);vyplň(nováFarba);return nováFarba;}
public Farba vypln(int r, int g, int b, int a) { return vyplň(r, g, b, a); }
public void vyplň(Shape tvar, String súbor){
BufferedImage obrázok = (BufferedImage)súborNaObrázok(súbor);
grafika.setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(), obrázok.getHeight())));grafika.fill(tvar);}
public void vypln(Shape tvar, String súbor) { vyplň(tvar, súbor); }
public void vyplň(Shape tvar, BufferedImage obrázok){
float priehľadnosť = (obrázok instanceof Obrázok) ? (float)
((Obrázok)obrázok).priehľadnosť : 1.0f;if (priehľadnosť > 0){
grafika.setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(null),obrázok.getHeight(null))));if (priehľadnosť < 1){
Composite záloha = grafika.getComposite();grafika.setComposite(AlphaComposite.getInstance(
AlphaComposite.SRC_OVER, priehľadnosť));grafika.fill(tvar);grafika.setComposite(záloha);}else grafika.fill(tvar);}}
public void vypln(Shape tvar, BufferedImage obrázok) { vyplň(tvar, obrázok); }
public void kresli(String súbor){
int x = (šírka - obrázok.getWidth()) / 2;
int y = (výška - obrázok.getHeight()) / 2;
BufferedImage obrázok = (BufferedImage)súborNaObrázok(súbor);
grafika.drawImage(obrázok, 0, 0, null);}
public void kresli(double x, double y, String súbor){
BufferedImage obrázok = (BufferedImage)súborNaObrázok(súbor);
x = (šírka - obrázok.getWidth()) / 2.0 + x;
y = (výška - obrázok.getHeight()) / 2.0 - y;
grafika.translate(-posunX, -posunY);
grafika.drawImage(obrázok, (int)x, (int)y, null);
grafika.translate(posunX, posunY);}
public void kresli(Point2D bod, String súbor)
{ kresli(bod.getX(), bod.getY(), súbor); }
public void kresli(GRobot ktorý, String súbor)
{ kresli(ktorý.polohaX(), ktorý.polohaY(), súbor); }
public void kresli(BufferedImage obrázok){
int x = (šírka - obrázok.getWidth()) / 2;
int y = (výška - obrázok.getHeight()) / 2;
grafika.translate(-posunX, -posunY);
grafika.drawImage(obrázok, (int)x, (int)y, null);
grafika.translate(posunX, posunY);}
public void kresli(double x, double y, BufferedImage obrázok){
x = (šírka - obrázok.getWidth()) / 2.0 + x;
y = (výška - obrázok.getHeight()) / 2.0 - y;
grafika.translate(-posunX, -posunY);
grafika.drawImage(obrázok, (int)x, (int)y, null);
grafika.translate(posunX, posunY);}
public void kresli(Point2D bod, BufferedImage obrázok)
{ kresli(bod.getX(), bod.getY(), obrázok); }
public void kresli(GRobot ktorý, BufferedImage obrázok)
{ kresli(ktorý.polohaX(), ktorý.polohaY(), obrázok); }
public void vyplň(String súbor){
BufferedImage obrázok = (BufferedImage)súborNaObrázok(súbor);
grafika.setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(),obrázok.getHeight())));
grafika.fillRect(0, 0, šírka, výška);}
public void vypln(String súbor) { vyplň(súbor); }
public void vyplň(BufferedImage obrázok){
float priehľadnosť = (obrázok instanceof Obrázok) ? (float)
((Obrázok)obrázok).priehľadnosť : 1.0f;if (priehľadnosť > 0){
grafika.setPaint(new TexturePaint(obrázok,
new Rectangle(0, 0, obrázok.getWidth(null),obrázok.getHeight(null))));if (priehľadnosť < 1){
Composite záloha = grafika.getComposite();
grafika.setComposite(AlphaComposite.getInstance(
AlphaComposite.SRC_OVER, priehľadnosť));
grafika.fillRect(0, 0, šírka, výška);grafika.setComposite(záloha);}else
grafika.fillRect(0, 0, šírka, výška);}}
public void vypln(BufferedImage obrázok) { vyplň(obrázok); }
public void vylejFarbu(double x, double y, Color farba){
VykonajVObrázku.vylejFarbu(this, x, y, farba);if (právePrekresľujem) return;automatickéPrekreslenie();}
public void vylejFarbu(double x, double y, Farebnosť objekt){
VykonajVObrázku.vylejFarbu(this, x, y, objekt.farba());if (právePrekresľujem) return;automatickéPrekreslenie();}
public Farba vylejFarbu(double x, double y, int r, int g, int b){
Farba nováFarba = new Farba(r, g, b);vylejFarbu(x, y, nováFarba);return nováFarba;}
public Farba vylejFarbu(double x, double y, int r, int g, int b, int a){
Farba nováFarba = new Farba(r, g, b, a);vylejFarbu(x, y, nováFarba);return nováFarba;}
public void vylejFarbu(Point2D bod, Color farba){
VykonajVObrázku.vylejFarbu(this,
bod.getX(), bod.getY(), farba);if (právePrekresľujem) return;automatickéPrekreslenie();}
public void vylejFarbu(Point2D bod, Farebnosť objekt){
VykonajVObrázku.vylejFarbu(this,
bod.getX(), bod.getY(), objekt.farba());if (právePrekresľujem) return;automatickéPrekreslenie();}
public Farba vylejFarbu(Point2D bod, int r, int g, int b){
Farba nováFarba = new Farba(r, g, b);vylejFarbu(bod, nováFarba);return nováFarba;}
public Farba vylejFarbu(Point2D bod, int r, int g, int b, int a){
Farba nováFarba = new Farba(r, g, b, a);vylejFarbu(bod, nováFarba);return nováFarba;}
public void vylejFarbu(GRobot ktorý)
{ vylejFarbu(ktorý.aktuálneX, ktorý.aktuálneY, ktorý.farbaPera); }
public void negatív() { VykonajVObrázku.negatív(this); }
public void negativ() { VykonajVObrázku.negatív(this); }
public void bledší(double faktor){
if (null == údajeObrázka) údajeObrázka =
((DataBufferInt)getRaster().getDataBuffer()).getData();
for (int j = 0; j < údajeObrázka.length; ++j){
if (0 != (údajeObrázka[j] & 0xff000000)){
int r = (údajeObrázka[j] >> 16) & 0xff;
int g = (údajeObrázka[j] >>  8) & 0xff;
int b =  údajeObrázka[j]        & 0xff;
int i = (int)(1.0 / (1.0 - faktor));
if (r == 0 && g == 0 && b == 0){r = g = b = i;}else{if (r > 0 && r < i) r = i;if (g > 0 && g < i) g = i;if (b > 0 && b < i) b = i;
r /= faktor; if (r > 255) r = 255;
g /= faktor; if (g > 255) g = 255;
b /= faktor; if (b > 255) b = 255;}
údajeObrázka[j] = (údajeObrázka[j] & 0xff000000) |(r << 16) | (g << 8) | b;}}}
public void bledsi(double faktor) { bledší(faktor); }
public void svetlejší(double faktor) { bledší(faktor); }
public void svetlejsi(double faktor) { bledší(faktor); }
public void tmavší(double faktor){
if (null == údajeObrázka) údajeObrázka =
((DataBufferInt)getRaster().getDataBuffer()).getData();
for (int j = 0; j < údajeObrázka.length; ++j){
if (0 != (údajeObrázka[j] & 0xff000000)){
int r = (údajeObrázka[j] >> 16) & 0xff;
int g = (údajeObrázka[j] >>  8) & 0xff;
int b =  údajeObrázka[j]        & 0xff;r *= faktor; if (r < 0) r = 0;g *= faktor; if (g < 0) g = 0;b *= faktor; if (b < 0) b = 0;
údajeObrázka[j] = (údajeObrázka[j] & 0xff000000) |(r << 16) | (g << 8) | b;}}}
public void tmavsi(double faktor) { tmavší(faktor); }
public void bledší() { bledší(faktor); }
public void bledsi() { bledší(faktor); }
public void svetlejší() { bledší(faktor); }
public void svetlejsi() { bledší(faktor); }
public void tmavší() { tmavší(faktor); }
public void tmavsi() { tmavší(faktor); }public void čiernobiely(){
if (null == údajeObrázka) údajeObrázka =
((DataBufferInt)getRaster().getDataBuffer()).getData();
for (int j = 0; j < údajeObrázka.length; ++j){
if (0 != (údajeObrázka[j] & 0xff000000)){
int r = (údajeObrázka[j] >> 16) & 0xff;
int g = (údajeObrázka[j] >>  8) & 0xff;
int b =  údajeObrázka[j]        & 0xff;r = (r + g + b) / 3;
údajeObrázka[j] = (údajeObrázka[j] & 0xff000000) |(r << 16) | (r << 8) | r;}}}
public void ciernobiely() { čiernobiely(); }
public void odtieneŠedej() { čiernobiely(); }
public void odtieneSedej() { čiernobiely(); }
public void monochromatický(Color farba){
if (null == údajeObrázka) údajeObrázka =
((DataBufferInt)getRaster().getDataBuffer()).getData();int i = farba.getRGB();int R = (i >> 16) & 0xff;int G = (i >>  8) & 0xff;int B =  i        & 0xff;
for (int j = 0; j < údajeObrázka.length; ++j){
if (0 != (údajeObrázka[j] & 0xff000000)){
int r = (údajeObrázka[j] >> 16) & 0xff;
int g = (údajeObrázka[j] >>  8) & 0xff;
int b =  údajeObrázka[j]        & 0xff;r = (r + g + b) / 3;g = (r * G) / 0xff;b = (r * B) / 0xff;r = (r * R) / 0xff;
údajeObrázka[j] = (údajeObrázka[j] & 0xff000000) |(r << 16) | (g << 8) | b;}}}
public void monochromaticky(Color farba) { monochromatický(farba); }
public void jednofarebný(Color farba) { monochromatický(farba); }
public void jednofarebny(Color farba) { monochromatický(farba); }
public void farebnýFilter(Color farba){
if (null == údajeObrázka) údajeObrázka =
((DataBufferInt)getRaster().getDataBuffer()).getData();int i = farba.getRGB();int R = (i >> 16) & 0xff;int G = (i >>  8) & 0xff;int B =  i        & 0xff;
for (int j = 0; j < údajeObrázka.length; ++j){
if (0 != (údajeObrázka[j] & 0xff000000)){
int r = (údajeObrázka[j] >> 16) & 0xff;
int g = (údajeObrázka[j] >>  8) & 0xff;
int b =  údajeObrázka[j]        & 0xff;r = (r + g + b) / 3;g = (r + G) / 2;b = (r + B) / 2;r = (r + R) / 2;
údajeObrázka[j] = (údajeObrázka[j] & 0xff000000) |(r << 16) | (g << 8) | b;}}}
public void farebnyFilter(Color farba) { farebnýFilter(farba); }
public void monochromatický(Farebnosť objekt)
{ monochromatický(objekt.farba()); }
public void monochromaticky(Farebnosť objekt)
{ monochromatický(objekt.farba()); }
public void jednofarebný(Farebnosť objekt)
{ monochromatický(objekt.farba()); }
public void jednofarebny(Farebnosť objekt)
{ monochromatický(objekt.farba()); }
public void farebnýFilter(Farebnosť objekt)
{ farebnýFilter(objekt.farba()); }
public void farebnyFilter(Farebnosť objekt)
{ farebnýFilter(objekt.farba()); }
public boolean použiMasku(BufferedImage maska)
{ return VykonajVObrázku.použiMasku(this, maska); }
public boolean pouziMasku(BufferedImage maska)
{ return VykonajVObrázku.použiMasku(this, maska); }
public boolean vyrobMasku(BufferedImage nováMaska)
{ return null != VykonajVObrázku.vyrobMasku(this, nováMaska); }
public BufferedImage vyrobMasku()
{ return VykonajVObrázku.vyrobMasku(this, null); }
public void rozmaž(int opakovanie, int rozsah, Color pozadie){
grafika.translate(-posunX, -posunY);
VykonajVObrázku.rozmaž(this, grafika, opakovanie,rozsah, pozadie);
grafika.translate(posunX, posunY);}
public void rozmaz(int opakovanie, int rozsah, Color pozadie)
{ rozmaž(opakovanie, rozsah, pozadie); }
public void rozmaž(int opakovanie, Color pozadie)
{ rozmaž(opakovanie, 1, pozadie); }
public void rozmaz(int opakovanie, Color pozadie)
{ rozmaž(opakovanie, 1, pozadie); }
public void rozmaž(Color pozadie) { rozmaž(1, 1, pozadie); }
public void rozmaz(Color pozadie) { rozmaž(1, 1, pozadie); }
public void rozmaž(int opakovanie, int rozsah, Farebnosť pozadie){
grafika.translate(-posunX, -posunY);
VykonajVObrázku.rozmaž(this, grafika, opakovanie,rozsah, pozadie.farba());
grafika.translate(posunX, posunY);}
public void rozmaz(int opakovanie, int rozsah, Farebnosť pozadie)
{ rozmaž(opakovanie, rozsah, pozadie.farba()); }
public void rozmaž(int opakovanie, Farebnosť pozadie)
{ rozmaž(opakovanie, 1, pozadie.farba()); }
public void rozmaz(int opakovanie, Farebnosť pozadie)
{ rozmaž(opakovanie, 1, pozadie.farba()); }
public void rozmaž(Farebnosť pozadie) { rozmaž(1, 1, pozadie.farba()); }
public void rozmaz(Farebnosť pozadie) { rozmaž(1, 1, pozadie.farba()); }
public void rozmaž(int opakovanie, int rozsah)
{ rozmaž(opakovanie, rozsah, farbaPozadia); }
public void rozmaz(int opakovanie, int rozsah)
{ rozmaž(opakovanie, rozsah, farbaPozadia); }
public void rozmaž(int opakovanie)
{ rozmaž(opakovanie, 1, farbaPozadia); }
public void rozmaz(int opakovanie)
{ rozmaž(opakovanie, 1, farbaPozadia); }
public void rozmaž() { rozmaž(1, 1, farbaPozadia); }
public void rozmaz() { rozmaž(1, 1, farbaPozadia); }
public void rozmaž(int opakovanie, int rozsah,int bgr, int bgg, int bgb)
{ rozmaž(opakovanie, rozsah, new Farba(bgr, bgg, bgb)); }
public void rozmaz(int opakovanie, int rozsah, int bgr, int bgg, int bgb)
{ rozmaž(opakovanie, rozsah, new Farba(bgr, bgg, bgb)); }
public void rozmaž(int opakovanie, int bgr, int bgg, int bgb)
{ rozmaž(opakovanie, 1, new Farba(bgr, bgg, bgb)); }
public void rozmaz(int opakovanie, int bgr, int bgg, int bgb)
{ rozmaž(opakovanie, 1, new Farba(bgr, bgg, bgb)); }
public void rozmaž(int bgr, int bgg, int bgb)
{ rozmaž(1, 1, new Farba(bgr, bgg, bgb)); }
public void rozmaz(int bgr, int bgg, int bgb)
{ rozmaž(1, 1, new Farba(bgr, bgg, bgb)); }public void prevráťVodorovne(){if (null == údajeObrázka)
údajeObrázka = ((DataBufferInt)getRaster().getDataBuffer()).getData();if (null == údajeOperácie)
údajeOperácie = new int[údajeObrázka.length];
System.arraycopy(údajeObrázka, 0, údajeOperácie,0, údajeObrázka.length);
int index1 = 0, index2 = šírka * (výška - 1);
for (int i = 0; i < výška; ++i){
for (int j = 0; j < šírka; ++j){údajeObrázka[index1 + j] =údajeOperácie[index2 + j];}index1 += šírka;index2 -= šírka;}}
public void prevratVodorovne() { prevráťVodorovne(); }
public void prevráťHorizontálne() { prevráťVodorovne(); }
public void prevratHorizontalne() { prevráťVodorovne(); }public void prevráťZvislo(){if (null == údajeObrázka)
údajeObrázka = ((DataBufferInt)getRaster().getDataBuffer()).getData();if (null == údajeOperácie)
údajeOperácie = new int[údajeObrázka.length];
System.arraycopy(údajeObrázka, 0, údajeOperácie,0, údajeObrázka.length);
int index1 = 0, index2 = šírka - 1;
for (int i = 0; i < výška; ++i){
for (int j = 0; j < šírka; ++j){údajeObrázka[index1 + j] =údajeOperácie[index2 - j];}index1 += šírka;index2 += šírka;}}
public void prevratZvislo() { prevráťZvislo(); }
public void prevráťVertikálne() { prevráťZvislo(); }
public void prevratVertikalne() { prevráťZvislo(); }
public void roluj(double Δx, double Δy){
int dx = (int)Δx; int dy = -(int)Δy;
if (dx == 0 && dy == 0) return;if (null == údajeObrázka)
údajeObrázka = ((DataBufferInt)getRaster().getDataBuffer()).getData();
if (dx >= šírka || dx <= -šírka ||dy >= výška || dy <= -výška){Arrays.fill(údajeObrázka, 0);return;}
int spodnáZarážka, vrchnáZarážka,
zarážkaRiadkov, zarážkaStĺpcov;if (dy <= 0){spodnáZarážka = 0;
vrchnáZarážka = šírka * -dy - dx;zarážkaRiadkov = výška + dy;if (dx <= 0){zarážkaStĺpcov = šírka + dx;
for (int i = 0; i < zarážkaRiadkov; ++i){int j = 0;
for (; j < zarážkaStĺpcov; ++j)
údajeObrázka[spodnáZarážka + j] =
údajeObrázka[vrchnáZarážka + j];for (; j < šírka; ++j)
údajeObrázka[spodnáZarážka + j] = 0;spodnáZarážka += šírka;vrchnáZarážka += šírka;}}else{zarážkaStĺpcov = dx;
for (int i = 0; i < zarážkaRiadkov; ++i){int j = šírka - 1;
for (; j >= zarážkaStĺpcov; --j)
údajeObrázka[spodnáZarážka + j] =
údajeObrázka[vrchnáZarážka + j];for (; j >= 0; --j)
údajeObrázka[spodnáZarážka + j] = 0;spodnáZarážka += šírka;vrchnáZarážka += šírka;}}vrchnáZarážka = šírka * výška;
while (spodnáZarážka < vrchnáZarážka){
údajeObrázka[spodnáZarážka] = 0;++spodnáZarážka;}}else{
spodnáZarážka = -dx + šírka * (výška - 1 - dy);
vrchnáZarážka = šírka * (výška - 1);zarážkaRiadkov = dy;if (dx <= 0){zarážkaStĺpcov = šírka + dx;
for (int i = výška - 1; i >= zarážkaRiadkov; --i){int j = 0;
for (; j < zarážkaStĺpcov; ++j)
údajeObrázka[vrchnáZarážka + j] =
údajeObrázka[spodnáZarážka + j];for (; j < šírka; ++j)
údajeObrázka[vrchnáZarážka + j] = 0;spodnáZarážka -= šírka;vrchnáZarážka -= šírka;}}else{zarážkaStĺpcov = dx;
for (int i = výška - 1; i >= zarážkaRiadkov; --i){int j = šírka - 1;
for (; j >= zarážkaStĺpcov; --j)
údajeObrázka[vrchnáZarážka + j] =
údajeObrázka[spodnáZarážka + j];for (; j >= 0; --j)
údajeObrázka[vrchnáZarážka + j] = 0;spodnáZarážka -= šírka;vrchnáZarážka -= šírka;}}
vrchnáZarážka = (šírka * dy) - 1;while (vrchnáZarážka >= 0){
údajeObrázka[vrchnáZarážka] = 0;--vrchnáZarážka;}}}
public void pretoč(double Δx, double Δy){
int dx = (int)Δx; int dy = -(int)Δy;
if (dx == 0 && dy == 0) return;if (null == údajeObrázka)
údajeObrázka = ((DataBufferInt)getRaster().getDataBuffer()).getData();if (null == údajeOperácie)
údajeOperácie = new int[údajeObrázka.length];
System.arraycopy(údajeObrázka, 0,
údajeOperácie, 0, údajeObrázka.length);while (dx < 0) dx += šírka;
while (dx >= šírka) dx -= šírka;while (dy < 0) dy += výška;
while (dy >= výška) dy -= výška;
int index1 = 0, index2 = šírka * (výška + 1 - dy) - dx;for (int i = dy; i > 0; --i){for (int j = dx; j > 0; --j){údajeObrázka[index1++] =údajeOperácie[index2++];}index2 -= šírka;
for (int j = šírka - dx; j > 0; --j){údajeObrázka[index1++] =údajeOperácie[index2++];}index2 += šírka;}index2 = šírka - dx;
for (int i = výška - dy; i > 0; --i){for (int j = dx; j > 0; --j){údajeObrázka[index1++] =údajeOperácie[index2++];}index2 -= šírka;
for (int j = šírka - dx; j > 0; --j){údajeObrázka[index1++] =údajeOperácie[index2++];}index2 += šírka;}}
public void pretoc(double Δx, double Δy) { pretoč(Δx, Δy); }
public Farba farbaBodu(double x, double y){
int x0 = (int)((šírka / 2.0) + x);
int y0 = (int)((výška / 2.0) - y);if (x0 < 0 || x0 >= šírka ||
y0 < 0 || y0 >= výška) return čierna;
return new Farba(getRGB(x0, y0), true);}
public Farba farbaBodu(Point2D bod){
int x0 = (int)((šírka / 2.0) + bod.getX());
int y0 = (int)((výška / 2.0) - bod.getY());if (x0 < 0 || x0 >= šírka ||
y0 < 0 || y0 >= výška) return čierna;
return new Farba(getRGB(x0, y0), true);}
public Farba farbaBodu(GRobot ktorý)
{ return farbaBodu(ktorý.aktuálneX, ktorý.aktuálneY); }
public boolean farbaBodu(double x, double y, Color farba){
int x0 = (int)((šírka / 2.0) + x);
int y0 = (int)((výška / 2.0) - y);if (x0 < 0 || x0 >= šírka ||
y0 < 0 || y0 >= výška) return false;
return (farba.getRGB() & 0xffffffff) ==(getRGB(x0, y0) & 0xffffffff);}
public boolean farbaBodu(Point2D bod, Color farba){
int x0 = (int)((šírka / 2.0) + bod.getX());
int y0 = (int)((výška / 2.0) - bod.getY());if (x0 < 0 || x0 >= šírka ||
y0 < 0 || y0 >= výška) return false;
return (farba.getRGB() & 0xffffffff) ==(getRGB(x0, y0) & 0xffffffff);}
public boolean farbaBodu(GRobot ktorý, Color farba)
{ return farbaBodu(ktorý.aktuálneX, ktorý.aktuálneY, farba); }
public boolean farbaBodu(double x, double y, Farebnosť objekt){
int x0 = (int)((šírka / 2.0) + x);
int y0 = (int)((výška / 2.0) - y);if (x0 < 0 || x0 >= šírka ||
y0 < 0 || y0 >= výška) return false;
return (objekt.farba().getRGB() & 0xffffffff) ==(getRGB(x0, y0) & 0xffffffff);}
public boolean farbaBodu(Point2D bod, Farebnosť objekt){
int x0 = (int)((šírka / 2.0) + bod.getX());
int y0 = (int)((výška / 2.0) - bod.getY());if (x0 < 0 || x0 >= šírka ||
y0 < 0 || y0 >= výška) return false;
return (objekt.farba().getRGB() & 0xffffffff) ==(getRGB(x0, y0) & 0xffffffff);}
public boolean farbaBodu(GRobot ktorý, Farebnosť objekt)
{ return farbaBodu(ktorý.aktuálneX, ktorý.aktuálneY, objekt.farba()); }
public double priehľadnosť() { return priehľadnosť; }
public double priehladnost() { return priehľadnosť; }
public void priehľadnosť(double priehľadnosť){
this.priehľadnosť = (float)priehľadnosť;}
public void priehladnost(double priehľadnosť)
{ priehľadnosť(priehľadnosť); }
public void priehľadnosť(Priehľadnosť objekt)
{ this.priehľadnosť = (float)objekt.priehľadnosť(); }
public void priehladnost(Priehľadnosť objekt){ priehľadnosť(objekt); }
public void upravPriehľadnosť(double zmena){
if (0 == priehľadnosť) priehľadnosť = 0.1f;
else priehľadnosť *= (float)zmena;}
public void upravPriehladnost(double zmena){ upravPriehľadnosť(zmena); }
public void ulož(String súbor) { ulož(súbor, false); }
public void uloz(String súbor) { ulož(súbor); }
public void ulož(String súbor, boolean prepísať){
File uložiťDo = new File(súbor);
if (!prepísať && uložiťDo.exists())
throw new RuntimeException("Súbor „" + súbor + "“ jestvuje!");
String prípona = súbor.substring(súbor.lastIndexOf('.') + 1);
if (prípona.toLowerCase().equals("png")){
try { ImageIO.write(this, prípona, uložiťDo); }
catch (IOException e) { vypíšChybovéHlásenia(e, true); }}
else if (prípona.toLowerCase().equals("jpg")){
WritableRaster raster = getRaster();
WritableRaster novýRaster = raster.createWritableChild(
0, 0, šírka, výška, 0, 0, new int[] {0, 1, 2});
DirectColorModel farebnýModel =
(DirectColorModel)getColorModel();
DirectColorModel novýFarebnýModel = new
DirectColorModel(farebnýModel.getPixelSize(),farebnýModel.getRedMask(),farebnýModel.getGreenMask(),farebnýModel.getBlueMask());
BufferedImage rgbBuffer = new BufferedImage(
novýFarebnýModel, novýRaster, false, null);
try { ImageIO.write(rgbBuffer, prípona, uložiťDo); }
catch (IOException e) { vypíšChybovéHlásenia(e, true); }}else{
throw new RuntimeException("Neplatný typ súboru: " + prípona);}}
public void uloz(String súbor, boolean prepísať){ ulož(súbor, prepísať); }
public boolean doSchránky() { return Schránka.obrázok(this); }
public boolean doSchranky() { return Schránka.obrázok(this); }}
public static class Obrazok extends Obrázok implements Priehladnost{public Obrazok() { super(); }
public Obrazok(int šírka, int výška) { super(šírka, výška); }
public Obrazok(Image obrázok) { super(obrázok); }}
public static class Oblasť extends Area implements Poloha{private GRobot zamestnanec;public Oblasť() {}
public Oblasť(Shape tvar) { super(tvar); }
public Oblasť(GRobot zamestnanec) { zamestnaj(zamestnanec); }
public Oblasť(Shape tvar, GRobot zamestnanec)
{ super(tvar); zamestnaj(zamestnanec); }
public boolean prázdna() { return isEmpty(); }
public boolean prazdna() { return isEmpty(); }
public void zamestnaj(GRobot zamestnanec){
if (this.zamestnanec == zamestnanec) return;
if (null != zamestnanec.zamestnanýPre) throw new RuntimeException(
"Tento robot už je zamestnaný za účelom tvorby inej " +"oblasti.");uvoľni();
zamestnanec.kresliTvary = false;
zamestnanec.zamestnanýPre = this;
this.zamestnanec = zamestnanec;}public void uvoľni(){if (null != zamestnanec){
zamestnanec.kresliTvary = true;
zamestnanec.zamestnanýPre = null;zamestnanec = null;}}
public void uvolni() { uvoľni(); }
public void prepusti() { uvoľni(); }
public void uvoľni(GRobot zamestnanec){
if (this.zamestnanec == zamestnanec){
zamestnanec.kresliTvary = true;
zamestnanec.zamestnanýPre = null;this.zamestnanec = null;}}
public void uvolni(GRobot zamestnanec) { uvoľni(zamestnanec); }
public void prepusti(GRobot zamestnanec) { uvoľni(zamestnanec); }
public boolean zamestnaný() { return zamestnanec != null; }
public boolean zamestnany() { return zamestnanec != null; }
public boolean zamestnaný(GRobot zamestnanec)
{ return this.zamestnanec == zamestnanec; }
public boolean zamestnany(GRobot zamestnanec)
{ return this.zamestnanec == zamestnanec; }public void pridaj(Shape tvar){Area oblasť = new Area(tvar);add(oblasť);}public void odober(Shape tvar){Area oblasť = new Area(tvar);subtract(oblasť);}
public void prienik(Shape tvar){Area oblasť = new Area(tvar);subtract(oblasť);}
public void vymaž() { reset(); }
public void vymaz() { reset(); }public void kresli(){if (null != zamestnanec)zamestnanec.kresli(this);}public void vyplň(){if (null != zamestnanec)zamestnanec.vyplň(this);}
public void vypln() { vyplň(); }
public void vyplň(String súbor){if (null != zamestnanec)
zamestnanec.vyplň(this, súbor);}
public void vypln(String súbor) { vyplň(súbor); }
public void vyplň(BufferedImage obrázok){if (null != zamestnanec)
zamestnanec.vyplň(this, obrázok);}
public void vypln(BufferedImage obrázok) { vyplň(obrázok); }public void kresli(GRobot r){r.kresli(this);}public void vyplň(GRobot r){r.vyplň(this);}
public void vypln(GRobot r) { vyplň(r); }
public void vyplň(GRobot r, String súbor){r.vyplň(this, súbor);}
public void vypln(GRobot r, String súbor) { vyplň(r, súbor); }
public void vyplň(GRobot r, BufferedImage obrázok){r.vyplň(this, obrázok);}
public void vypln(GRobot r, BufferedImage obrázok) { vyplň(r, obrázok); }
public boolean bodV(double súradnicaBoduX, double súradnicaBoduY){
return contains(prepočítajX(súradnicaBoduX),prepočítajY(súradnicaBoduY));}
public boolean bodV(Point2D bod)
{ return contains(prepočítajX(bod.getX()), prepočítajY(bod.getY())); }public boolean bodV(Poloha r){
return contains(prepočítajX(r.polohaX()),prepočítajY(r.polohaY()));}public boolean myšV(){
return contains(prepočítajX(súradnicaMyšiX),prepočítajY(súradnicaMyšiY));}
public boolean mysV() { return myšV(); }public double polohaX(){
Rectangle2D hranice = getBounds2D();
double Δx = (prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2);return Δx;}public double polohaY(){
Rectangle2D hranice = getBounds2D();
double Δy = (prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2);return Δy;}public double súradnicaX(){return polohaX();}public double suradnicaX(){return polohaX();}public double súradnicaY(){return polohaY();}public double suradnicaY(){return polohaY();}public Point2D.Double poloha(){
Rectangle2D hranice = getBounds2D();
double Δx = (prepočítajSpäťX(hranice.getX()) +hranice.getWidth() / 2);
double Δy = (prepočítajSpäťY(hranice.getY()) -hranice.getHeight() / 2);
return new Point2D.Double(Δx, Δy);}}
public static class Oblast extends Oblasť{public Oblast() { super(); }
public Oblast(Shape tvar) { super(tvar); }
public Oblast(GRobot zamestnanec) { super(zamestnanec); }
public Oblast(Shape tvar, GRobot zamestnanec) { super(tvar, zamestnanec); }}
public static class PoložkaPonuky extends JMenuItem{
private final static ActionListener voľbaPoložkyPonuky =new ActionListener(){
public void actionPerformed(ActionEvent e){poslednáPoložkaPonuky = null;
JMenuBar hlavnáPonuka = svet.getJMenuBar();
for (int j = 0; j < hlavnáPonuka.getMenuCount(); ++j){
JMenu položkaHlavnejPonuky = hlavnáPonuka.getMenu(j);
if (null != položkaHlavnejPonuky){
for (int i = 0; i < položkaHlavnejPonuky.getItemCount(); ++i){
PoložkaPonuky tátoPoložka = (PoložkaPonuky)
položkaHlavnejPonuky.getItem(i);
if (e.getSource() == tátoPoložka){
poslednáPoložkaPonuky = tátoPoložka;tátoPoložka.aktivovaná(true);}else if (null != tátoPoložka){tátoPoložka.aktivovaná(false);}}}}
if (null != poslednáPoložkaPonuky){
if (null != položkaVymazať && e.getSource() ==položkaVymazať){svet.vymaž();
if (nekresli) svet.prekresli();}
else if (null != položkaPrekresliť && e.getSource() ==položkaPrekresliť){svet.prekresli();}
else if (e.getSource() == položkaSkončiť){System.exit(0);}else if (null != počúvadlo){synchronized (zámokUdalostí){
počúvadlo.voľbaPoložkyPonuky();
počúvadlo.volbaPolozkyPonuky();}}}}};
public PoložkaPonuky(String text){super(text);
addActionListener(voľbaPoložkyPonuky);pridajDoHlavnejPonuky();}
public PoložkaPonuky(String text, int mnemonickáSkratka){super(text);
addActionListener(voľbaPoložkyPonuky);
setMnemonic(mnemonickáSkratka);pridajDoHlavnejPonuky();}
public PoložkaPonuky(String text, int mnemonickáSkratka, int klávesováSkratka){super(text);
addActionListener(voľbaPoložkyPonuky);
setAccelerator(KeyStroke.getKeyStroke(
klávesováSkratka, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
setMnemonic(mnemonickáSkratka);pridajDoHlavnejPonuky();}
private void pridajDoHlavnejPonuky(){
JMenuBar hlavnáPonuka = svet.getJMenuBar();if (inicializované&& null != hlavnáPonuka){JMenu položkaHlavnejPonuky =
hlavnáPonuka.getMenu(aktuálnaPonuka);
if (null != položkaHlavnejPonuky){if (ponukaVPôvodnomStave){ponukaVPôvodnomStave = false;položkaHlavnejPonuky.
insertSeparator(aktuálnaPoložka);}
položkaHlavnejPonuky.insert(this,aktuálnaPoložka++);if (!hlavnáPonuka.isVisible())hlavnáPonuka.setVisible(true);}}}
private boolean aktivovaná = false;
private void aktivovaná(boolean b) { aktivovaná = b; }
public boolean aktivovaná() { return aktivovaná; }
public boolean aktivovana() { return aktivovaná; }
public boolean zvolená() { return aktivovaná; }
public boolean zvolena() { return aktivovaná; }
public void ikona(String súbor) { setIcon(súborNaIkonu(súbor)); }}
public static class PolozkaPonuky extends PoložkaPonuky{
public PolozkaPonuky(String text) { super(text); }
public PolozkaPonuky(String text, int mnemonickáSkratka)
{ super(text, mnemonickáSkratka); }
public PolozkaPonuky(String text, int mnemonickáSkratka, int klávesováSkratka)
{ super(text, mnemonickáSkratka, klávesováSkratka);}}
public static class KontextováPonuka extends JPopupMenu{
private String pôvodnýPopis = null;private final JLabel popis;
private static String nahradiťHTMLEntity(String text){if (-1 != text.indexOf("<") ||-1 != text.indexOf(">") ||-1 != text.indexOf("&")){
text = text.replaceAll("&", "&amp;");
text = text.replaceAll("<", "&lt;");
text = text.replaceAll(">", "&gt;");}return text;}public KontextováPonuka(){super();this.popis = null;}
public KontextováPonuka(String popis){super();pôvodnýPopis = popis;
if (popis.startsWith("<html>"))
this.popis = new JLabel(popis);else
this.popis = new JLabel("<html><b>" +
nahradiťHTMLEntity(popis) + "</b></html>");
this.popis.setHorizontalAlignment(SwingConstants.CENTER);add(this.popis);addSeparator();}
public JMenuItem pridajPoložku(JMenuItem položka){ return add(položka); }
public JMenuItem pridajPolozku(JMenuItem položka){ return add(položka); }
public KontextováPoložka pridajPoložku(String text)
{ return (KontextováPoložka)add(text); }
public KontextováPoložka pridajPolozku(String text)
{ return (KontextováPoložka)add(text); }
public void pridajOddeľovač() { addSeparator(); }
public void pridajOddelovac() { addSeparator(); }
public JMenuItem pridajPonuku(String text, JMenuItem... položky)
{ return add(vytvorPonuku(text, položky)); }
public static JMenu vytvorPonuku(String text, JMenuItem... položky){
JMenu ponuka = new JMenu(text);
for (JMenuItem položka : položky){
if (null == položka) ponuka.addSeparator();else ponuka.add(položka);}return ponuka;}
public void popis(String text) { setLabel(text); }
public String popis() { return getLabel(); }public void zobraz(){
int x = poslednáUdalosťMyši.getX();
int y = poslednáUdalosťMyši.getY();
if (poslednáUdalosťMyši.getSource() instanceof Component)
show((Component)poslednáUdalosťMyši.getSource(), x, y);else show(hlavnýPanel, x, y);}
public void zobraz(double x, double y)
{ show(hlavnýPanel, (int)prepočítajX(x), (int)prepočítajY(y)); }
@Override public JMenuItem add(String text)
{ return add(new KontextováPoložka(text)); }
@Override public void setLabel(String text){if (null == popis) return;pôvodnýPopis = text;if (text.startsWith("<html>"))popis.setText(text);else popis.setText("<html><b>" +nahradiťHTMLEntity(text) +"</b></html>");}
@Override public String getLabel() { return pôvodnýPopis; }}
public static class KontextovaPonuka extends KontextováPonuka{
public KontextovaPonuka() { super(); }
public KontextovaPonuka(String text) { super(text); }}
public static class KontextováPoložka extends JMenuItem{
private final static ActionListener
voľbaKontextovejPoložky = new ActionListener(){
public void actionPerformed(ActionEvent e){
if (e.getSource() instanceof KontextováPoložka)poslednáKontextováPoložka =
(KontextováPoložka)e.getSource();else
poslednáKontextováPoložka = null;if (null != počúvadlo){synchronized (zámokUdalostí){
počúvadlo.voľbaKontextovejPoložky();
počúvadlo.volbaKontextovejPolozky();}}}};
public KontextováPoložka(String text){super(text);
addActionListener(voľbaKontextovejPoložky);}}
public static class KontextovaPolozka extends KontextováPoložka
{ public KontextovaPolozka(String text) { super(text); } }
public static class Tlačidlo extends JButton implements Poloha{
private int x, y, šírka, výška;private byte prilepenie = 0;
private boolean zálohaStavuOpaque;
private boolean zálohaStavuContentAreaFilled;
private boolean zálohaStavuBorderPainted;
private final static ActionListener voľbaTlačidla =new ActionListener(){
public void actionPerformed(ActionEvent e){
poslednéTlačidlo = (Tlačidlo)e.getSource();if (null != počúvadlo){synchronized (zámokUdalostí){počúvadlo.voľbaTlačidla();počúvadlo.volbaTlacidla();}}}};private void vytvor(){šírka = 108; výška = 32;x = (šírkaPlátna - šírka) / 2;y = (výškaPlátna - výška) / 2;hlavnýPanel.add(this, 0);hlavnýPanel.doLayout();
addActionListener(voľbaTlačidla);addKeyListener(udalostiOkna);
zálohaStavuOpaque = isOpaque();
zálohaStavuContentAreaFilled = isContentAreaFilled();
zálohaStavuBorderPainted = isBorderPainted();}
private void vytvor(int vlastnáŠírka, int vlastnáVýška){
šírka = vlastnáŠírka; výška = vlastnáVýška;x = (šírkaPlátna - šírka) / 2;y = (výškaPlátna - výška) / 2;hlavnýPanel.add(this, 0);hlavnýPanel.doLayout();
addActionListener(voľbaTlačidla);addKeyListener(udalostiOkna);
zálohaStavuOpaque = isOpaque();
zálohaStavuContentAreaFilled = isContentAreaFilled();
zálohaStavuBorderPainted = isBorderPainted();}
private void umiestni(int x1, int y1, int šírka1, int výška1){int x0 = x1 + x;int y0 = y1 + y;if (1 == (prilepenie & 3))
x0 += ((šírka - šírka1) / 2) - (šírka1 % 2);
else if (2 == (prilepenie & 3))x0 -= ((šírka - šírka1) / 2);if (4 == (prilepenie & 12))
y0 += ((výška - výška1) / 2) - (výška1 % 2);
else if (8 == (prilepenie & 12))y0 -= ((výška - výška1) / 2);
setBounds(x0, y0, šírka, výška);}public Tlačidlo(String text){super(text);vytvor();}
public Tlačidlo(Obrázok obrázok){super(new ImageIcon(obrázok));
vytvor(obrázok.šírka, obrázok.výška);zrušDekor();}
public Tlačidlo(Obrázok obrázok, Obrázok obrázokStlačeného){super(new ImageIcon(obrázok));if (null != obrázokStlačeného)
setPressedIcon(new ImageIcon(obrázokStlačeného));
vytvor(obrázok.šírka, obrázok.výška);zrušDekor();}
public Tlačidlo(Obrázok obrázok, String text){
super(text, new ImageIcon(obrázok));vytvor();}
public boolean aktivované() { return this == poslednéTlačidlo; }
public boolean aktivovane() { return aktivované(); }
public boolean zvolené() { return aktivované(); }
public boolean zvolene() { return aktivované(); }
public int mnemonickáSkratka() { return getMnemonic(); }
public int mnemonickaSkratka() { return getMnemonic(); }
public void mnemonickáSkratka(int mnemonickáSkratka)
{ setMnemonic(mnemonickáSkratka); }
public void mnemonickaSkratka(int mnemonickáSkratka)
{ setMnemonic(mnemonickáSkratka); }
public double polohaX() { return x - ((šírkaPlátna - šírka) / 2); }
public double polohaY() { return -y + ((výškaPlátna - výška) / 2); }
public void polohaX(double novéX){
x = ((šírkaPlátna - šírka) / 2) + (int)novéX;hlavnýPanel.doLayout();}
public void polohaY(double novéY){
y = ((výškaPlátna - výška) / 2) - (int)novéY;hlavnýPanel.doLayout();}
public void súradnicaX(double novéX) { polohaX(novéX); }
public void suradnicaX(double novéX) { polohaX(novéX); }
public void súradnicaY(double novéY) { polohaY(novéY); }
public void suradnicaY(double novéY) { polohaY(novéY); }
public double súradnicaX() { return polohaX(); }
public double súradnicaY() { return polohaY(); }
public double suradnicaX() { return polohaX(); }
public double suradnicaY() { return polohaY(); }
public void poloha(double x, double y){
this.x = ((šírkaPlátna - šírka) / 2) + (int)x;
this.y = ((výškaPlátna - výška) / 2) - (int)y;hlavnýPanel.doLayout();}
public void poloha(Point2D poloha){
this.x = ((šírkaPlátna - šírka) / 2) + (int)poloha.getX();
this.y = ((výškaPlátna - výška) / 2) - (int)poloha.getY();hlavnýPanel.doLayout();}
public void poloha(Poloha objekt){
poloha((int)objekt.polohaX(), (int)objekt.polohaY());}public Point2D.Double poloha(){
double x = this.x - ((šírkaPlátna - šírka) / 2.0);
double y = -this.y + ((výškaPlátna - výška) / 2.0);
return new Point2D.Double(x, y);}
public void skočNa(double x, double y) { poloha(x, y); }
public void skocNa(double x, double y) { poloha(x, y); }
public void skočNa(Poloha objekt)
{ poloha(objekt.polohaX(), objekt.polohaY()); }
public void skocNa(Poloha objekt)
{ poloha(objekt.polohaX(), objekt.polohaY()); }
public void skoč(double Δx, double Δy){this.x += Δx;this.y -= Δy;hlavnýPanel.doLayout();}
public void skoc(double Δx, double Δy) { skoč(Δx, Δy); }public void prilepVľavo(){prilepenie &= 12;prilepenie |= 1;hlavnýPanel.doLayout();}
public void prilepVlavo() { prilepVľavo(); }public void prilepVpravo(){prilepenie &= 12;prilepenie |= 2;hlavnýPanel.doLayout();}public void prilepHore(){prilepenie &= 3;prilepenie |= 4;hlavnýPanel.doLayout();}public void prilepDole(){prilepenie &= 3;prilepenie |= 8;hlavnýPanel.doLayout();}
public void odlep() { prilepenie = 0; }
public int šírka() { return šírka; }
public int sirka() { return šírka; }
public int výška() { return výška; }
public int vyska() { return výška; }
public void šírka(int nováŠírka){double ox = polohaX();šírka = nováŠírka;polohaX(ox);}
public void sirka(int nováŠírka) { šírka(nováŠírka); }
public void výška(int nováVýška){double oy = polohaY();výška = nováVýška;polohaY(oy);}
public void vyska(int nováVýška) { výška(nováVýška); }
public boolean aktívne() { return isEnabled(); }
public boolean aktivne() { return isEnabled(); }
public void aktivuj() { setEnabled(true); }
public void deaktivuj() { setEnabled(false); }
public boolean označené() { return isSelected(); }
public boolean oznacene() { return isSelected(); }
public void označ() { setSelected(true); }
public void oznac() { setSelected(true); }
public void odznač() { setSelected(false); }
public void odznac() { setSelected(false); }
public void zrušOznačenie() { setSelected(false); }
public void zrusOznacenie() { setSelected(false); }
public boolean viditeľné() { return isVisible(); }
public boolean viditelne() { return isVisible(); }
public boolean zobrazené() { return isVisible(); }
public boolean zobrazene() { return isVisible(); }
public void zobraz() { setVisible(true); }
public void skry() { setVisible(false); }
@Override public void setVisible(boolean visible){if (!visible)
hlavnýPanel.requestFocusInWindow();super.setVisible(visible);}
String text() { return getText(); }
void text(String text) { setText(text); }
public void obrázok(Obrázok obrázok){
if (null == obrázok) setIcon(null);
else setIcon(new ImageIcon(obrázok));}
public void obrazok(Obrázok obrázok) { obrázok(obrázok); }public Obrázok obrázok(){Icon icon = getIcon();
if (null != icon && icon instanceof ImageIcon){
Image image = ((ImageIcon)icon).getImage();
if (null != image && image instanceof Obrázok)return (Obrázok)image;}return null;}
public Obrázok obrazok() { return obrázok(); }
public void obrázokStlačeného(Obrázok obrázok){
if (null == obrázok) setPressedIcon(null);
else setPressedIcon(new ImageIcon(obrázok));}
public void obrazokStlaceneho(Obrázok obrázok) { obrázokStlačeného(obrázok); }
public Obrázok obrázokStlačeného(){Icon icon = getPressedIcon();
if (null != icon && icon instanceof ImageIcon){
Image image = ((ImageIcon)icon).getImage();
if (null != image && image instanceof Obrázok)return (Obrázok)image;}return null;}
public Obrázok obrazokStlaceneho() { return obrázokStlačeného(); }
public void obrázokDeaktivovaného(Obrázok obrázok){
if (null == obrázok) setDisabledIcon(null);
else setDisabledIcon(new ImageIcon(obrázok));}
public void obrazokDeaktivovaneho(Obrázok obrázok) { obrázokDeaktivovaného(obrázok); }
public Obrázok obrázokDeaktivovaného(){Icon icon = getDisabledIcon();
if (null != icon && icon instanceof ImageIcon){
Image image = ((ImageIcon)icon).getImage();
if (null != image && image instanceof Obrázok)return (Obrázok)image;}return null;}
public Obrázok obrazokDeaktivovaneho() { return obrázokDeaktivovaného(); }
public void obrázokOznačeného(Obrázok obrázok){
if (null == obrázok) setSelectedIcon(null);
else setSelectedIcon(new ImageIcon(obrázok));}
public void obrazokOznaceneho(Obrázok obrázok) { obrázokOznačeného(obrázok); }
public Obrázok obrázokOznačeného(){Icon icon = getSelectedIcon();
if (null != icon && icon instanceof ImageIcon){
Image image = ((ImageIcon)icon).getImage();
if (null != image && image instanceof Obrázok)return (Obrázok)image;}return null;}
public Obrázok obrazokOznaceneho() { return obrázokOznačeného(); }
public void obrázokDeaktivovanéhoOznačeného(Obrázok obrázok){
if (null == obrázok) setSelectedIcon(null);
else setSelectedIcon(new ImageIcon(obrázok));}
public void obrazokDeaktivovanehoOznaceneho(Obrázok obrázok) { obrázokDeaktivovanéhoOznačeného(obrázok); }
public void obrázokOznačenéhoDeaktivovaného(Obrázok obrázok) { obrázokDeaktivovanéhoOznačeného(obrázok); }
public void obrazokOznacenehoDeaktivovaneho(Obrázok obrázok) { obrázokDeaktivovanéhoOznačeného(obrázok); }
public Obrázok obrázokDeaktivovanéhoOznačeného(){Icon icon = getSelectedIcon();
if (null != icon && icon instanceof ImageIcon){
Image image = ((ImageIcon)icon).getImage();
if (null != image && image instanceof Obrázok)return (Obrázok)image;}return null;}
public Obrázok obrazokDeaktivovanehoOznaceneho() { return obrázokDeaktivovanéhoOznačeného(); }
public Obrázok obrázokOznačenéhoDeaktivovaného() { return obrázokDeaktivovanéhoOznačeného(); }
public Obrázok obrazokOznacenehoDeaktivovaneho() { return obrázokDeaktivovanéhoOznačeného(); }
public int medzeraMedziObrázkomATextom(){ return getIconTextGap(); }
public int medzeraMedziObrazkomATextom(){ return getIconTextGap(); }
public void medzeraMedziObrázkomATextom(int medzera){ setIconTextGap(medzera); }
public void medzeraMedziObrazkomATextom(int medzera){ setIconTextGap(medzera); }public void zrušDekor(){setOpaque(false);setContentAreaFilled(false);setBorderPainted(false);}
public void zrusDekor() { zrušDekor(); }public void obnovDekor(){setOpaque(zálohaStavuOpaque);
setContentAreaFilled(zálohaStavuContentAreaFilled);
setBorderPainted(zálohaStavuBorderPainted);}}
public static class Tlacidlo extends Tlačidlo
{ public Tlacidlo(String text) { super(text); }}
public static class Farba extends Color{Farba(Color c){
super(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha());}Farba(Farebnosť o){
super(o.farba().getRed(), o.farba().getGreen(),
o.farba().getBlue(), o.farba().getAlpha());}
Farba(ColorSpace cspace, float[] components, float alpha) { super(cspace, components, alpha); }
Farba(double r, double g, double b)
{ super((float)r, (float)g, (float)b); }
Farba(double r, double g, double b, double a)
{ super((float)r, (float)g, (float)b, (float)a); }Farba(int rgb) { super(rgb); }
Farba(int rgba, boolean hasalpha) { super(rgba, hasalpha); }
Farba(int r, int g, int b) { super(r, g, b); }
Farba(int r, int g, int b, int a) { super(r, g, b, a); }
public int červená() { return getRed(); }
public int cervena() { return getRed(); }
public int zelená() { return getGreen(); }
public int zelena() { return getGreen(); }
public int modrá() { return getBlue(); }
public int modra() { return getBlue(); }
public int priehľadnosť() { return getAlpha(); }
public int priehladnost() { return getAlpha(); }
private final static double faktor = 0.7;public Farba svetlejšia(){int r = getRed();int g = getGreen();int b = getBlue();
int i = (int)(1.0 / (1.0 - faktor));
if (r == 0 && g == 0 && b == 0)
return new Farba(i, i, i, getAlpha());if (r > 0 && r < i) r = i;if (g > 0 && g < i) g = i;if (b > 0 && b < i) b = i;
return new Farba(Math.min((int)(r / faktor), 255),
Math.min((int)(g / faktor), 255),
Math.min((int)(b / faktor), 255), getAlpha());}
public Farba svetlejsia() { return svetlejšia(); }
public Farba bledšia() { return svetlejšia(); }
public Farba bledsia() { return svetlejšia(); }public Farba tmavšia(){
return new Farba(Math.max((int)(getRed() * faktor), 0),
Math.max((int)(getGreen() * faktor), 0),
Math.max((int)(getBlue() * faktor), 0), getAlpha());}
public Farba tmavsia() { return tmavšia(); }public Farba priehľadnejšia(){
return new Farba(getRed(), getGreen(), getBlue(),
Math.max((int)(getAlpha() * faktor), 0));}
public Farba priehladnejsia() { return priehľadnejšia(); }
public Farba nepriehľadnejšia(){
int i = (int)(1.0 / (1.0 - faktor));int a = getAlpha();if (a > 0 && a < i)
return new Farba(getRed(), getGreen(), getBlue(), i);
return new Farba(getRed(), getGreen(), getBlue(),
Math.min((int)(a / faktor), 255));}
public Farba nepriehladnejsia() { return nepriehľadnejšia(); }
public Farba menejPriehľadná() { return nepriehľadnejšia(); }
public Farba menejPriehladna() { return nepriehľadnejšia(); }
public Farba svetlejšia(double faktor){int r = getRed();int g = getGreen();int b = getBlue();
int i = (int)(1.0 / (1.0 - faktor));
if (r == 0 && g == 0 && b == 0)
return new Farba(i, i, i, getAlpha());if (r > 0 && r < i) r = i;if (g > 0 && g < i) g = i;if (b > 0 && b < i) b = i;
return new Farba(Math.min((int)(r / faktor), 255),
Math.min((int)(g / faktor), 255),
Math.min((int)(b / faktor), 255), getAlpha());}
public Farba bledšia(double faktor) { return svetlejšia(faktor); }
public Farba bledsia(double faktor) { return svetlejšia(faktor); }
public Farba svetlejsia(double faktor) { return svetlejšia(faktor); }
public Farba tmavšia(double faktor){
return new Farba(Math.max((int)(getRed() * faktor), 0),
Math.max((int)(getGreen() * faktor), 0),
Math.max((int)(getBlue() * faktor), 0), getAlpha());}
public Farba tmavsia(double faktor) { return tmavšia(faktor); }
public Farba priehľadnejšia(double faktor){
return new Farba(getRed(), getGreen(), getBlue(),
Math.max((int)(getAlpha() * faktor), 0));}
public Farba priehladnejsia(double faktor) { return priehľadnejšia(faktor); }
public Farba nepriehľadnejšia(double faktor){
int i = (int)(1.0 / (1.0 - faktor));int a = getAlpha();if (a > 0 && a < i)
return new Farba(getRed(), getGreen(), getBlue(), i);
return new Farba(getRed(), getGreen(), getBlue(),
Math.min((int)(a / faktor), 255));}
public Farba nepriehladnejsia(double faktor) { return nepriehľadnejšia(faktor); }
public Farba menejPriehľadná(double faktor) { return nepriehľadnejšia(faktor); }
public Farba menejPriehladna(double faktor) { return nepriehľadnejšia(faktor); }
public static Farba vyberFarbu(){
Color farba = JColorChooser.showDialog(svet,
"Voľba farby", svet.farbaPozadia());
if (null == farba) return null;return new Farba(farba);}
public static Farba dialógVýberFarby() { return vyberFarbu(); }
public static Farba dialogVyberFarby() { return vyberFarbu(); }
public static Farba zvoľFarbu(){
Color farba = JColorChooser.showDialog(svet,
"Voľba farby", svet.farbaPozadia());
if (null == farba) return null;return new Farba(farba);}
public static Farba zvolFarbu() { return zvoľFarbu(); }
public static Farba dialógVoľbaFarby() { return zvoľFarbu(); }
public static Farba dialogVolbaFarby() { return zvoľFarbu(); }
public static Farba vyberFarbu(Farba počiatočnáFarba){
Color farba = JColorChooser.showDialog(svet,
"Voľba farby", počiatočnáFarba);
if (null == farba) return null;return new Farba(farba);}
public static Farba dialógVýberFarby(Farba počiatočnáFarba) { return vyberFarbu(počiatočnáFarba); }
public static Farba dialogVyberFarby(Farba počiatočnáFarba) { return vyberFarbu(počiatočnáFarba); }
public static Farba zvoľFarbu(Farba počiatočnáFarba){
Color farba = JColorChooser.showDialog(svet,
"Voľba farby", počiatočnáFarba);
if (null == farba) return null;return new Farba(farba);}
public static Farba zvolFarbu(Farba počiatočnáFarba) { return zvoľFarbu(počiatočnáFarba); }
public static Farba dialógVoľbaFarby(Farba počiatočnáFarba) { return zvoľFarbu(počiatočnáFarba); }
public static Farba dialogVolbaFarby(Farba počiatočnáFarba) { return zvoľFarbu(počiatočnáFarba); }
public static Farba vyberFarbu(String titulok){
Color farba = JColorChooser.showDialog(svet,titulok, svet.farbaPozadia());
if (null == farba) return null;return new Farba(farba);}
public static Farba dialógVýberFarby(String titulok) { return vyberFarbu(titulok); }
public static Farba dialogVyberFarby(String titulok) { return vyberFarbu(titulok); }
public static Farba zvoľFarbu(String titulok){
Color farba = JColorChooser.showDialog(svet,titulok, svet.farbaPozadia());
if (null == farba) return null;return new Farba(farba);}
public static Farba zvolFarbu(String titulok) { return zvoľFarbu(titulok); }
public static Farba dialógVoľbaFarby(String titulok) { return zvoľFarbu(titulok); }
public static Farba dialogVolbaFarby(String titulok) { return zvoľFarbu(titulok); }
public static Farba vyberFarbu(String titulok, Farba počiatočnáFarba){
Color farba = JColorChooser.showDialog(svet,titulok, počiatočnáFarba);
if (null == farba) return null;return new Farba(farba);}
public static Farba dialógVýberFarby(String titulok, Farba počiatočnáFarba) { return vyberFarbu(titulok, počiatočnáFarba); }
public static Farba dialogVyberFarby(String titulok, Farba počiatočnáFarba) { return vyberFarbu(titulok, počiatočnáFarba); }
public static Farba zvoľFarbu(String titulok, Farba počiatočnáFarba){
Color farba = JColorChooser.showDialog(svet,titulok, počiatočnáFarba);
if (null == farba) return null;return new Farba(farba);}
public static Farba zvolFarbu(String titulok, Farba počiatočnáFarba) { return zvoľFarbu(titulok, počiatočnáFarba); }
public static Farba dialógVoľbaFarby(String titulok, Farba počiatočnáFarba) { return zvoľFarbu(titulok, počiatočnáFarba); }
public static Farba dialogVolbaFarby(String titulok, Farba počiatočnáFarba) { return zvoľFarbu(titulok, počiatočnáFarba); }
public static double[] RGBtoHSB(int rgb){
float[] hsb = Color.RGBtoHSB((rgb >> 16) & 0xff,
(rgb >> 8) & 0xff, rgb & 0xff, null);
return new double[]{hsb[0], hsb[1], hsb[2]};}
public static void RGBtoHSB(int rgb, double[] hsb){float[] f_hsb = new float[3];
Color.RGBtoHSB((rgb >> 16) & 0xff,
(rgb >> 8) & 0xff, rgb & 0xff, f_hsb);
hsb[0] = f_hsb[0]; hsb[1] = f_hsb[1]; hsb[2] = f_hsb[2];}
public static int HSBtoRGB(double h, double s, double b){
return Color.HSBtoRGB((float)h, (float)s, (float)b);}
public static double[] RGBtoHSV(int rgb){
double r = (double)((rgb >> 16) & 0xff) / 255.0;
double g = (double)((rgb >>  8) & 0xff) / 255.0;
double b = (double)(rgb         & 0xff) / 255.0;double min = r;double max = r;if (g < min) min = g;if (b < min) min = b;if (g > max) max = g;if (b > max) max = b;double h, s, v = max;double chroma = max - min;if (max != 0){s = chroma / max;}else{s = 0;h = -1;return new double[]{h, s, v};}if (r == max)h = ((g - b) / chroma) % 6;else if (g == max)h = 2 + (b - r) / chroma;else h = 4 + (r - g) / chroma;return new double[]{h, s, v};}
public static void RGBtoHSV(int rgb, double[] hsv){
double r = (double)((rgb >> 16) & 0xff) / 255.0;
double g = (double)((rgb >>  8) & 0xff) / 255.0;
double b = (double)(rgb         & 0xff) / 255.0;double min = r;double max = r;if (g < min) min = g;if (b < min) min = b;if (g > max) max = g;if (b > max) max = b;hsv[2] = max;double chroma = max - min;if (max != 0){hsv[1] = chroma / max;if (r == max)
hsv[0] = ((g - b) / chroma) % 6;else if (g == max)hsv[0] = 2 + (b - r) / chroma;else hsv[0] = 4 + (r - g) / chroma;}else{hsv[1] = 0;hsv[0] = -1;}}
public static int HSVtoRGB(double h, double s, double v){double r, g, b; int i;
if (h > 1.0 || h < 0.0) h -= Math.floor(h);
if (s > 1.0 || s < 0.0) s -= Math.floor(s);
if (v > 1.0 || v < 0.0) v -= Math.floor(v);if (0 == s){r = g = b = v;}else{h *= 6;  i = (int)h;double fact = h - i;double p = v * (1 - s);double q = v * (1 - s * fact);
double t = v * (1 - s * (1 - fact));switch (i){
case  0: r = v; g = t; b = p; break;
case  1: r = q; g = v; b = p; break;
case  2: r = p; g = v; b = t; break;
case  3: r = p; g = q; b = v; break;
case  4: r = t; g = p; b = v; break;default: r = v; g = p; b = q;}}i = 0xff00 |  (int)(r * 255);i <<= 8; i |= (int)(g * 255);i <<= 8; i |= (int)(b * 255);return i;}}
public static class Písmo extends Font{
public final static int OBYČAJNÉ = Font.PLAIN;
public final static int OBYCAJNE = Font.PLAIN;
public final static int NORMÁLNE = Font.PLAIN;
public final static int NORMALNE = Font.PLAIN;
public final static int TUČNÉ = Font.BOLD;
public final static int TUCNE = Font.BOLD;
public final static int SILNÉ = Font.BOLD;
public final static int SILNE = Font.BOLD;
public final static int KURZÍVA = Font.ITALIC;
public final static int KURZIVA = Font.ITALIC;
public final static int ŠIKMÉ = Font.ITALIC;
public final static int SIKME = Font.ITALIC;
public Písmo(Font font) { super(font); }
public Písmo(Map<? extends java.text.AttributedCharacterIterator.Attribute, ?> attributes){ super(attributes); }
public Písmo(String názov, int štýl, int veľkosť)
{ super(názov, štýl, veľkosť); }
public int veľkosť() { return getSize(); }
public int velkost() { return getSize(); }
public boolean obyčajné() { return isPlain(); }
public boolean obycajne() { return isPlain(); }
public boolean normálne() { return isPlain(); }
public boolean normalne() { return isPlain(); }
public boolean tučné() { return isBold(); }
public boolean tucne() { return isBold(); }
public boolean silné() { return isBold(); }
public boolean silne() { return isBold(); }
public boolean kurzíva() { return isItalic(); }
public boolean kurziva() { return isItalic(); }
public boolean šikmé() { return isItalic(); }
public boolean sikme() { return isItalic(); }
public String názov() { return getFamily(); }
public String nazov() { return getFamily(); }}
public static class Pismo extends Písmo{
public Pismo(Font font) { super(font); }
public Pismo(Map<? extends java.text.AttributedCharacterIterator.Attribute, ?> attributes){ super(attributes); }
public Pismo(String názov, int štýl, int veľkosť)
{ super(názov, štýl, veľkosť); }}public static class Zvuk{private Clip klip;
private FloatControl hlasitosť = null;
private FloatControl váha = null;private Zvuk(Clip klip){this.klip = klip;}
private static Zvuk načítaj(URL url){Clip klip = null;AudioInputStream vstup = null;try{
vstup = AudioSystem.getAudioInputStream(url);}
catch (Exception e) { return null; }try{klip = AudioSystem.getClip();klip.open(vstup);}
catch (Exception e) { return null; }finally{try{vstup.close();}
catch (Exception e) { return null; }}return new Zvuk(klip);}public void zastav(){klip.stop();klip.setFramePosition(0);}public void prehraj(){klip.setFramePosition(0);klip.start();}public void prehrávaťDookola(){klip.setFramePosition(0);
klip.loop(Clip.LOOP_CONTINUOUSLY);}
public void prehravatDookola() { prehrávaťDookola(); }
public void opakovaťDookola() { prehrávaťDookola(); }
public void opakovatDookola() { prehrávaťDookola(); }
public void cyklickyOpakovať() { prehrávaťDookola(); }
public void cyklickyOpakovat() { prehrávaťDookola(); }
public void pozastav() { klip.stop(); }
public void pauza() { klip.stop(); }
public void pokračuj() { klip.start(); }
public void pokracuj() { klip.start(); }public double trvanie()
{ return (double)klip.getMicrosecondLength() / 1E6D; }
public void poloha(double poloha)
{ klip.setMicrosecondPosition((long)(poloha * 1E6D)); }public double poloha()
{ return (double)klip.getMicrosecondPosition() / 1E6D; }
public boolean prehrávaSa() { return klip.isActive(); }
public boolean prehravaSa() { return prehrávaSa(); }
public boolean hlasitosťNepodporovaná(){if (null == hlasitosť){
if (klip.isControlSupported(FloatControl.Type.MASTER_GAIN))hlasitosť = (FloatControl)
klip.getControl(FloatControl.Type.MASTER_GAIN);else return true;}return null == hlasitosť;}
public boolean hlasitostNepodporovana()
{ return hlasitosťNepodporovaná(); }public double hlasitosť(){
if (hlasitosťNepodporovaná()) return 1.0;
float dB = hlasitosť.getValue();
double miera = Math.pow(10.0, (double)dB / 20.0);return miera;}
public double hlasitost() { return hlasitosť(); }
public void hlasitosť(double miera){
if (hlasitosťNepodporovaná()) return;
float dB = (float)(Math.log10(miera) * 20.0);
if (dB > hlasitosť.getMaximum()) dB = hlasitosť.getMaximum();
if (dB < hlasitosť.getMinimum()) dB = hlasitosť.getMinimum();hlasitosť.setValue(dB);}
public void hlasitost(double miera) { hlasitosť(miera); }
public boolean váhaNepodporovaná(){if (null == váha){
if (klip.getFormat().getChannels() == 1 &&
klip.isControlSupported(FloatControl.Type.PAN))váha = (FloatControl)
klip.getControl(FloatControl.Type.PAN);
else if (klip.getFormat().getChannels() == 2 &&
klip.isControlSupported(FloatControl.Type.BALANCE))váha = (FloatControl)
klip.getControl(FloatControl.Type.BALANCE);else return true;}return null == váha;}
public boolean vahaNepodporovana() { return váhaNepodporovaná(); }public double váha(){
if (váhaNepodporovaná()) return 0.0;return váha.getValue();}
public double vaha() { return váha(); }public void váha(double miera){
if (váhaNepodporovaná()) return;
if (miera > váha.getMaximum()) miera = váha.getMaximum();
if (miera < váha.getMinimum()) miera = váha.getMinimum();váha.setValue((float)miera);}
public void vaha(double miera) { váha(miera); }}
public static class Zoznam<Typ> extends Vector<Typ>{private int index = 0;
private boolean prejdenýDokola = false;public Zoznam() { super(); }public Zoznam(Typ... prvky){super();
if (prvky.length > 10) ensureCapacity(prvky.length);
for (Typ prvok : prvky) super.add(prvok);}
public Zoznam(Collection<? extends Typ> c) { super(c); }
public Zoznam(int počiatočnáKapacita) { super(počiatočnáKapacita); }
public Zoznam(int počiatočnáKapacita, int prírastokKapacity)
{ super(počiatočnáKapacita, prírastokKapacity); }
public int kapacita() { return capacity(); }
public int veľkosť() { return size(); }
public int počet() { return size(); }
public int dĺžka() { return size(); }
public int velkost() { return size(); }
public int pocet() { return size(); }
public int dlzka() { return size(); }
public boolean prázdny() { return isEmpty(); }
public boolean prazdny() { return isEmpty(); }
public boolean jePrázdny() { return isEmpty(); }
public boolean jePrazdny() { return isEmpty(); }
public void pridaj(Typ prvok) { addElement(prvok); }
public void pridaj(Zoznam<Typ> inýZoznam){if (this == inýZoznam){
Zoznam<Typ> kópia = new Zoznam<Typ>(inýZoznam);addAll(kópia);}else addAll(inýZoznam);}
public void vlož(int kde, Typ prvok) { insertElementAt(prvok, kde); }
public void vloz(int kde, Typ prvok) { insertElementAt(prvok, kde); }
public void pridaj(int kde, Typ prvok) { insertElementAt(prvok, kde); }
public void prepíš(int kde, Typ prvok) { setElementAt(prvok, kde); }
public void prepis(int kde, Typ prvok) { setElementAt(prvok, kde); }
public void nastav(int kde, Typ prvok) { setElementAt(prvok, kde); }
public void nahraď(int kde, Typ prvok) { setElementAt(prvok, kde); }
public void nahrad(int kde, Typ prvok) { setElementAt(prvok, kde); }
public void vymaž() { removeAllElements(); }
public void vymaz() { removeAllElements(); }
public void odober(int kde) { removeElementAt(kde); }
public void vymaž(int kde) { removeElementAt(kde); }
public void vymaz(int kde) { removeElementAt(kde); }
public boolean odober(Typ prvok) { return remove(prvok); }
public boolean obsahuje(Typ prvok) { return contains(prvok); }
public int počítadlo() { return index; }
public int pocitadlo() { return index; }
public void počítadlo(int nováHodnota){
if (nováHodnota > size()) nováHodnota = size();
if (nováHodnota < -1) nováHodnota = -1;index = nováHodnota;}
public void pocitadlo(int nováHodnota) { počítadlo(index); }
public void počítadloNaZačiatok() { index = -1; }
public void pocitadloNaZaciatok() { index = -1; }
public void počítadloNaKoniec() { index = size(); }
public void pocitadloNaKoniec() { index = size(); }
public Typ daj(int kde) { return elementAt(kde); }
public Typ vráť(int kde) { return elementAt(kde); }
public Typ vrat(int kde) { return elementAt(kde); }
public Typ čítaj(int kde) { return elementAt(kde); }
public Typ citaj(int kde) { return elementAt(kde); }public Typ daj(){
if (0 == size()) throw new NoSuchElementException();
if (index >= size()) return firstElement();
if (index < 0) return lastElement();return elementAt(index);}
public Typ vráť() { return daj(); }
public Typ vrat() { return daj(); }
public Typ čítaj() { return daj(); }
public Typ citaj() { return daj(); }
public Typ prvý() { index = 0; return firstElement(); }
public Typ prvy() { return prvý(); }
public Typ prvýPrvok() { return prvý(); }
public Typ prvyPrvok() { return prvý(); }
public Typ posledný() { index = size() - 1; return lastElement(); }
public Typ posledny() { return posledný(); }
public Typ poslednýPrvok() { return posledný(); }
public Typ poslednyPrvok() { return posledný(); }public Typ ďalší(){
if (0 == size()) throw new NoSuchElementException();
if (++index >= size() || index < 0){prejdenýDokola = true;return prvý();}prejdenýDokola = false;return elementAt(index);}
public Typ dalsi() { return ďalší(); }
public Typ ďalšíPrvok() { return ďalší(); }
public Typ dalsiPrvok() { return ďalší(); }public Typ predošlý(){
if (0 == size()) throw new NoSuchElementException();
if (--index < 0 || index >= size()){prejdenýDokola = true;return posledný();}prejdenýDokola = false;return elementAt(index);}
public Typ predosly() { return predošlý(); }
public Typ predošlýPrvok() { return predošlý(); }
public Typ predoslyPrvok() { return predošlý(); }
public boolean prejdenýDokola() { return prejdenýDokola; }
public boolean prejdenyDokola() { return prejdenýDokola; }
public boolean bolPrejdenýDokola() { return prejdenýDokola; }
public boolean bolPrejdenyDokola() { return prejdenýDokola; }public Typ náhodný(){
if (0 == size()) throw new NoSuchElementException();
return elementAt(index = Math.abs(generátor.nextInt()) % size());}
public Typ nahodny() { return náhodný(); }
public Typ náhodnýPrvok() { return náhodný(); }
public Typ nahodnyPrvok() { return náhodný(); }
public int nájdi(Typ prvok) { return indexOf(prvok); }
public int najdi(Typ prvok) { return indexOf(prvok); }
public int hľadaj(Typ prvok) { return indexOf(prvok); }
public int hladaj(Typ prvok) { return indexOf(prvok); }
public int nájdi(Typ prvok, int začniOd) { return indexOf(prvok, začniOd); }
public int najdi(Typ prvok, int začniOd) { return indexOf(prvok, začniOd); }
public int hľadaj(Typ prvok, int začniOd)
{ return indexOf(prvok, začniOd); }
public int hladaj(Typ prvok, int začniOd)
{ return indexOf(prvok, začniOd); }
public int nájdiPosledný(Typ prvok) { return lastIndexOf(prvok); }
public int najdiPosledny(Typ prvok) { return lastIndexOf(prvok); }
public int hľadajOdzadu(Typ prvok) { return lastIndexOf(prvok); }
public int hladajOdzadu(Typ prvok) { return lastIndexOf(prvok); }
public int nájdiPosledný(Typ prvok, int začniOd) { return lastIndexOf(prvok, začniOd); }
public int najdiPosledny(Typ prvok, int začniOd) { return lastIndexOf(prvok, začniOd); }
public int hľadajOdzadu(Typ prvok, int začniOd)
{ return lastIndexOf(prvok, začniOd); }
public int hladajOdzadu(Typ prvok, int začniOd)
{ return lastIndexOf(prvok, začniOd); }
public void vymeň(int kde1, int kde2){if (kde1 == kde2) return;Typ prvok1 = elementAt(kde1);Typ prvok2 = elementAt(kde2);setElementAt(prvok2, kde1);setElementAt(prvok1, kde2);}
public void vymeň(int kde, Typ prvok){int i = indexOf(prvok);vymeň(kde, i);}
public void vymeň(Typ prvok, int kde){int i = indexOf(prvok);vymeň(i, kde);}
public void vymeň(Typ prvok1, Typ prvok2){int i = indexOf(prvok1);int j = indexOf(prvok2);vymeň(i, j);}
public void vymen(int kde1, int kde2) { vymeň(kde1, kde2); }
public void vymen(int kde, Typ prvok) { vymeň(kde, prvok); }
public void vymen(Typ prvok, int kde) { vymeň(prvok, kde); }
public void vymen(Typ prvok1, Typ prvok2) { vymeň(prvok1, prvok2); }}
public static class Kláves extends KeyEvent{
private Kláves() { super(null, 0, 0, 0, 0, ' '); }
public final static int VĽAVO = KeyEvent.VK_LEFT;
public final static int VLAVO = KeyEvent.VK_LEFT;
public final static int VPRAVO = KeyEvent.VK_RIGHT;
public final static int HORE = KeyEvent.VK_UP;
public final static int DOLE = KeyEvent.VK_DOWN;
public final static int MEDZERA = KeyEvent.VK_SPACE;
public final static int MEDZERNÍK = KeyEvent.VK_SPACE;
public final static int MEDZERNIK = KeyEvent.VK_SPACE;
public final static int PAGE_UP = KeyEvent.VK_PAGE_UP;
public final static int STRÁNKA_HORE = KeyEvent.VK_PAGE_UP;
public final static int STRANKA_HORE = KeyEvent.VK_PAGE_UP;
public final static int PAGE_DOWN = KeyEvent.VK_PAGE_DOWN;
public final static int STRÁNKA_DOLE = KeyEvent.VK_PAGE_DOWN;
public final static int STRANKA_DOLE = KeyEvent.VK_PAGE_DOWN;
public final static int TAB = KeyEvent.VK_TAB;
public final static int TABULÁTOR = KeyEvent.VK_TAB;
public final static int TABULATOR = KeyEvent.VK_TAB;
public final static int ENTER = KeyEvent.VK_ENTER;
public final static int ESCAPE = KeyEvent.VK_ESCAPE;
public final static int BACKSPACE = KeyEvent.VK_BACK_SPACE;
public final static int BACK_SPACE = KeyEvent.VK_BACK_SPACE;
public final static int DELETE = KeyEvent.VK_DELETE;}
public static class Klaves extends Kláves
{ private Klaves() { super(); } }public static class Schránka{
private static class ImageSelection implements Transferable{
private final static DataFlavor[] dataFlavors =
new DataFlavor[] { DataFlavor.imageFlavor };private Image image;
public ImageSelection(Image image) { this.image = image; }
public DataFlavor[] getTransferDataFlavors() { return dataFlavors; }
public boolean isDataFlavorSupported(DataFlavor flavor)
{ return DataFlavor.imageFlavor.equals(flavor); }
public Object getTransferData(DataFlavor flavor) throws
UnsupportedFlavorException, IOException{
if (!DataFlavor.imageFlavor.equals(flavor))
throw new UnsupportedFlavorException(flavor);return image;}}
private static class Poslucháč implements ClipboardOwner { public void
lostOwnership(Clipboard aClipboard, Transferable aContents) {}}
private static Poslucháč poslucháč = new Poslucháč();
private static Clipboard schránka = Toolkit.
getDefaultToolkit().getSystemClipboard();
private static Transferable obsahSchránky = null;private Schránka() {}public static String text(){String prevzatýText = null;
obsahSchránky = schránka.getContents(null);
if (null != obsahSchránky && obsahSchránky.
isDataFlavorSupported(DataFlavor.stringFlavor)){try{
prevzatýText = (String)obsahSchránky.getTransferData(DataFlavor.stringFlavor);}
catch (UnsupportedFlavorException e){vypíšChybovéHlásenia(e);}catch (IOException e){vypíšChybovéHlásenia(e);}}return prevzatýText;}
public static boolean text(String reťazec){
StringSelection textovýVýber = new StringSelection(reťazec);try{
schránka.setContents(textovýVýber, poslucháč);return true;}
catch (IllegalStateException e){vypíšChybovéHlásenia(e);}return false;}
public static Obrázok obrázok(){
Obrázok prevzatýObrázok = null;
obsahSchránky = schránka.getContents(null);
if (null != obsahSchránky && obsahSchránky.
isDataFlavorSupported(DataFlavor.imageFlavor)){try{
Image obrázok = (Image)obsahSchránky.
getTransferData(DataFlavor.imageFlavor);prevzatýObrázok = new Obrázok(
obrázok.getWidth(null), obrázok.getHeight(null));
prevzatýObrázok.grafika.translate(
-prevzatýObrázok.posunX, -prevzatýObrázok.posunY);
prevzatýObrázok.grafika.drawImage(obrázok, 0, 0, null);
prevzatýObrázok.grafika.translate(
prevzatýObrázok.posunX, prevzatýObrázok.posunY);}
catch (UnsupportedFlavorException e){vypíšChybovéHlásenia(e);}catch (IOException e){vypíšChybovéHlásenia(e);}}return prevzatýObrázok;}
public static BufferedImage obrazok() { return obrázok(); }
public static boolean obrázok(Image obrázok){
ImageSelection obrázkovýVýber = new ImageSelection(obrázok);try{
schránka.setContents(obrázkovýVýber, poslucháč);return true;}
catch (IllegalStateException e){vypíšChybovéHlásenia(e);}return false;}
public static boolean obrazok(Image obrázok){ return obrázok(obrázok); }}
public static class Schranka extends Schránka { private Schranka() {} }
public final static Schránka schránka = new Schránka();
public final static Schránka schranka = schránka;
public static class ÚdajeUdalostí{private ÚdajeUdalostí() {}
public static ActionEvent tik() { return poslednýTik; }
public static ComponentEvent okno() { return poslednáUdalosťOkna; }
public static PoložkaPonuky položkaPonuky() { return poslednáPoložkaPonuky; }
public static PolozkaPonuky polozkaPonuky() { return (PolozkaPonuky)poslednáPoložkaPonuky; }
public static KontextováPoložka kontextováPoložka() { return poslednáKontextováPoložka; }
public static KontextovaPolozka kontextovaPolozka() { return (KontextovaPolozka)poslednáKontextováPoložka; }
public static Tlačidlo tlačidlo() { return poslednéTlačidlo; }
public static Tlacidlo tlacidlo() { return (Tlacidlo)poslednéTlačidlo; }
public static KeyEvent klávesnica() { return poslednáUdalosťKlávesnice; }
public static KeyEvent klavesnica() { return poslednáUdalosťKlávesnice; }
public static boolean kláves(int kód)
{ return poslednáUdalosťKlávesnice.getKeyCode() == kód; }
public static boolean klaves(int kód)
{ return poslednáUdalosťKlávesnice.getKeyCode() == kód; }public static int kláves()
{ return poslednáUdalosťKlávesnice.getKeyCode(); }public static int klaves()
{ return poslednáUdalosťKlávesnice.getKeyCode(); }
public static boolean znak(char znak)
{ return poslednáUdalosťKlávesnice.getKeyChar() == znak; }public static char znak()
{ return poslednáUdalosťKlávesnice.getKeyChar(); }
public static MouseEvent myš() { return poslednáUdalosťMyši; }
public static MouseEvent mys() { return poslednáUdalosťMyši; }
public static MouseWheelEvent kolieskoMyši() { return poslednáUdalosťRolovania; }
public static MouseWheelEvent kolieskoMysi() { return poslednáUdalosťRolovania; }
public static int rolovanieKolieskomMyšiX(){synchronized (zámokMyši){
return rolovanieKolieskomMyšiX;}}
public static int rolovanieKolieskomMysiX() { return rolovanieKolieskomMyšiX(); }
public static int rolovanieKolieskomMyšiY(){synchronized (zámokMyši){
return rolovanieKolieskomMyšiY;}}
public static int rolovanieKolieskomMysiY() { return rolovanieKolieskomMyšiY(); }
public static double súradnicaMyšiX(){synchronized (zámokMyši){return súradnicaMyšiX;}}
public static double suradnicaMysiX() { return súradnicaMyšiX(); }
public static double súradnicaMyšiY(){synchronized (zámokMyši){return súradnicaMyšiY;}}
public static double suradnicaMysiY() { return súradnicaMyšiY(); }
public static double polohaMyšiX() { return súradnicaMyšiX(); }
public static double polohaMysiX() { return súradnicaMyšiX(); }
public static double polohaMyšiY() { return súradnicaMyšiY(); }
public static double polohaMysiY() { return súradnicaMyšiY(); }
public static boolean tlačidloMyši1(){synchronized (zámokMyši){return tlačidloMyši1;}}
public static boolean tlacidloMysi1() { return tlačidloMyši1(); }
public static boolean tlačidloMyši2(){synchronized (zámokMyši){return tlačidloMyši2;}}
public static boolean tlacidloMysi2() { return tlačidloMyši2(); }
public static boolean tlačidloMyši3(){synchronized (zámokMyši){return tlačidloMyši3;}}
public static boolean tlacidloMysi3() { return tlačidloMyši3(); }
public static boolean tlačidloMyšiDole(int ktoré){synchronized (zámokMyši){switch (ktoré){
case ĽAVÉ: return tlačidloMyši1;
case STREDNÉ: return tlačidloMyši2;
case PRAVÉ: return tlačidloMyši3;}}return false;}
public static boolean tlacidloMysiDole(int ktoré)
{ return tlačidloMyšiDole(ktoré); }
public static boolean tlačidloMyšiStlačené(int ktoré)
{ return tlačidloMyšiDole(ktoré); }
public static boolean tlacidloMysiStlacene(int ktoré)
{ return tlačidloMyšiDole(ktoré); }
public static boolean tlačidloMyšiHore(int ktoré){synchronized (zámokMyši){switch (ktoré){
case ĽAVÉ: return tlačidloMyši1;
case STREDNÉ: return tlačidloMyši2;
case PRAVÉ: return tlačidloMyši3;}}return true;}
public static boolean tlacidloMysiHore(int ktoré)
{ return tlačidloMyšiHore(ktoré); }
public static boolean tlačidloMyšiUvoľnené(int ktoré)
{ return tlačidloMyšiHore(ktoré); }
public static boolean tlacidloMysiUvolnene(int ktoré)
{ return tlačidloMyšiHore(ktoré); }
public static int tlačidloMyši(){synchronized (zámokMyši){return tlačidloMyši;}}
public static int tlacidloMysi(){ return tlačidloMyši(); }
public static boolean tlačidloMyši(int ktoré){synchronized (zámokMyši){return ktoré == tlačidloMyši;}}
public static boolean tlacidloMysi(int ktoré)
{ return tlačidloMyši(ktoré); }}
public static class UdajeUdalosti extends ÚdajeUdalostí{ private UdajeUdalosti() {} }
public final static ÚdajeUdalostí údajeUdalostí = new ÚdajeUdalostí();
public final static ÚdajeUdalostí udajeUdalosti = údajeUdalostí;
public static class ObsluhaUdalostí{
public final static ObsluhaUdalostí aktívna() { return počúvadlo; }
public final static ObsluhaUdalosti aktivna()
{ return (ObsluhaUdalosti)počúvadlo; }public ObsluhaUdalostí(){
if (viacnásobnáObsluhuUdalostíUmožnená){if (null == počúvadlo){počúvadlo = this;načítajVlastnúKonfiguráciu();}}else{if (null != počúvadlo)throw new RuntimeException(
"Obsluha udalostí už bola definovaná!");počúvadlo = this;načítajVlastnúKonfiguráciu();}}public void tik() {}public void klik() {}
public void voľbaPoložkyPonuky() {}
public void volbaPolozkyPonuky() {}
public void voľbaKontextovejPoložky() {}
public void volbaKontextovejPolozky() {}public void voľbaTlačidla() {}public void volbaTlacidla() {}public void vymazanie() {}public void prekreslenie() {}public void dokreslenie() {}
public void presunutieOkna() {}
public void zmenaVeľkostiOkna() {}
public void zmenaVelkostiOkna() {}public void ukončenie() {}public void ukoncenie() {}
public void potvrdenieÚdajov() {}
public void potvrdenieUdajov() {}
public void potvrdenieVstupu() {}
public void zrušenieÚdajov() {}
public void zrusenieUdajov() {}
public void zrušenieVstupu() {}
public void zrusenieVstupu() {}
public void stlačenieTlačidlaMyši() {}
public void stlacenieTlacidlaMysi() {}
public void uvoľnenieTlačidlaMyši() {}
public void uvolnenieTlacidlaMysi() {}public void pohybMyši() {}public void pohybMysi() {}public void ťahanieMyšou() {}public void tahanieMysou() {}
public void rolovanieKolieskomMyši() {}
public void rolovanieKolieskomMysi() {}
public void stlačenieKlávesu() {}
public void stlacenieKlavesu() {}
public void uvoľnenieKlávesu() {}
public void uvolnenieKlavesu() {}public void zadanieZnaku() {}
public boolean konfiguráciaZmenená() { return false; }
public boolean konfiguraciaZmenena() { return false; }
public void čítajKonfiguráciu(Súbor súbor) throws IOException {}
public void citajKonfiguraciu(Súbor subor) throws IOException {}
public void zapíšKonfiguráciu(Súbor súbor) throws IOException {}
public void zapisKonfiguraciu(Súbor subor) throws IOException {}}
public static class ObsluhaUdalosti extends ObsluhaUdalostí
{ public ObsluhaUdalosti() { super(); } }
public static class SpracovanieUdalostí extends ObsluhaUdalostí
{ public SpracovanieUdalostí() { super(); } }
public static class SpracovanieUdalosti extends ObsluhaUdalostí
{ public SpracovanieUdalosti() { super(); } }}interface Poloha{public double polohaX();public double polohaY();public double súradnicaX();public double suradnicaX();public double súradnicaY();public double suradnicaY();
public Point2D.Double poloha();}interface Smer{
public final static double VÝCHOD = 0.0;
public final static double VYCHOD = 0.0;
public final static double SEVEROVÝCHOD = 45.0;
public final static double SEVEROVYCHOD = 45.0;
public final static double SEVER = 90.0;
public final static double SEVEROZÁPAD = 135.0;
public final static double SEVEROZAPAD = 135.0;
public final static double ZÁPAD = 180.0;
public final static double ZAPAD = 180.0;
public final static double JUHOZÁPAD = 225.0;
public final static double JUHOZAPAD = 225.0;
public final static double JUH = 270.0;
public final static double JUHOVÝCHOD = 315.0;
public final static double JUHOVYCHOD = 315.0;public double uhol();public double smer();}interface Farebnosť{
public final static GRobot.Farba biela = new GRobot.Farba(255, 255, 255);
public final static GRobot.Farba svetlošedá = new GRobot.Farba(176, 176, 176);
public final static GRobot.Farba svetloseda = svetlošedá;
public final static GRobot.Farba šedá = new GRobot.Farba(144, 144, 144);
public final static GRobot.Farba seda = šedá;
public final static GRobot.Farba tmavošedá = new GRobot.Farba(96, 96, 96);
public final static GRobot.Farba tmavoseda = tmavošedá;
public final static GRobot.Farba čierna = new GRobot.Farba(0, 0, 0);
public final static GRobot.Farba cierna = čierna;
public final static GRobot.Farba svetločervená = new GRobot.Farba(224, 0, 0);
public final static GRobot.Farba svetlocervena = svetločervená;
public final static GRobot.Farba červená = new GRobot.Farba(176, 0, 0);
public final static GRobot.Farba cervena = červená;
public final static GRobot.Farba tmavočervená = new GRobot.Farba(144, 0, 0);
public final static GRobot.Farba tmavocervena = tmavočervená;
public final static GRobot.Farba svetlozelená = new GRobot.Farba(0, 224, 0);
public final static GRobot.Farba svetlozelena = svetlozelená;
public final static GRobot.Farba zelená = new GRobot.Farba(0, 176, 0);
public final static GRobot.Farba zelena = zelená;
public final static GRobot.Farba tmavozelená = new GRobot.Farba(0, 144, 0);
public final static GRobot.Farba tmavozelena = tmavozelená;
public final static GRobot.Farba svetlomodrá = new GRobot.Farba(0, 0, 224);
public final static GRobot.Farba svetlomodra = svetlomodrá;
public final static GRobot.Farba modrá = new GRobot.Farba(0, 0, 176);
public final static GRobot.Farba modra = modrá;
public final static GRobot.Farba tmavomodrá = new GRobot.Farba(0, 0, 144);
public final static GRobot.Farba tmavomodra = tmavomodrá;
public final static GRobot.Farba svetlotyrkysová = new GRobot.Farba(0, 224, 224);
public final static GRobot.Farba svetlotyrkysova = svetlotyrkysová;
public final static GRobot.Farba tyrkysová = new GRobot.Farba(0, 176, 176);
public final static GRobot.Farba tyrkysova = tyrkysová;
public final static GRobot.Farba tmavotyrkysová = new GRobot.Farba(0, 144, 144);
public final static GRobot.Farba tmavotyrkysova = tmavotyrkysová;
public final static GRobot.Farba svetlopurpurová = new GRobot.Farba(224, 0, 224);
public final static GRobot.Farba svetlopurpurova = svetlopurpurová;
public final static GRobot.Farba purpurová = new GRobot.Farba(176, 0, 176);
public final static GRobot.Farba purpurova = purpurová;
public final static GRobot.Farba tmavopurpurová = new GRobot.Farba(144, 0, 144);
public final static GRobot.Farba tmavopurpurova = tmavopurpurová;
public final static GRobot.Farba svetložltá = new GRobot.Farba(240, 240, 0);
public final static GRobot.Farba svetlozlta = svetložltá;
public final static GRobot.Farba žltá = new GRobot.Farba(224, 224, 0);
public final static GRobot.Farba zlta = žltá;
public final static GRobot.Farba tmavožltá = new GRobot.Farba(208, 208, 0);
public final static GRobot.Farba tmavozlta = tmavožltá;
public final static GRobot.Farba svetlohnedá = new GRobot.Farba(180, 96, 0);
public final static GRobot.Farba svetlohneda = svetlohnedá;
public final static GRobot.Farba hnedá = new GRobot.Farba(160, 80, 0);
public final static GRobot.Farba hneda = hnedá;
public final static GRobot.Farba tmavohnedá = new GRobot.Farba(140, 64, 0);
public final static GRobot.Farba tmavohneda = tmavohnedá;
public final static GRobot.Farba svetlooranžová = new GRobot.Farba(240, 180, 0);
public final static GRobot.Farba svetlooranzova = svetlooranžová;
public final static GRobot.Farba oranžová = new GRobot.Farba(220, 150, 0);
public final static GRobot.Farba oranzova = oranžová;
public final static GRobot.Farba tmavooranžová = new GRobot.Farba(200, 120, 0);
public final static GRobot.Farba tmavooranzova = tmavooranžová;
public final static GRobot.Farba svetloružová = new GRobot.Farba(255, 217, 217);
public final static GRobot.Farba svetloruzova = svetloružová;
public final static GRobot.Farba ružová = new GRobot.Farba(255, 179, 179);
public final static GRobot.Farba ruzova = ružová;
public final static GRobot.Farba tmavoružová = new GRobot.Farba(255, 140, 140);
public final static GRobot.Farba tmavoruzova = tmavoružová;public GRobot.Farba farba();}
interface Farebnost extends Farebnosť {}interface Priehľadnosť{
public final static float NEPRIEHĽADNÝ = 1.0f;
public final static float NEPRIEHLADNY = 1.0f;
public final static float NEPRIEHĽADNÁ = 1.0f;
public final static float NEPRIEHLADNA = 1.0f;
public final static float NEPRIEHĽADNÉ = 1.0f;
public final static float NEPRIEHLADNE = 1.0f;
public final static float NEVIDITEĽNÝ = 0.0f;
public final static float NEVIDITELNY = 0.0f;
public final static float NEVIDITEĽNÁ = 0.0f;
public final static float NEVIDITELNA = 0.0f;
public final static float NEVIDITEĽNÉ = 0.0f;
public final static float NEVIDITELNE = 0.0f;public double priehľadnosť();public double priehladnost();}
interface Priehladnost extends Priehľadnosť {}
